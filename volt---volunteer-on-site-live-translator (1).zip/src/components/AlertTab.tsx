import React, { useState, useEffect, useRef } from "react";
import { IncidentAlert, CrowdScriptResponse } from "../types";
import { AlertTriangle, Send, ShieldAlert, Megaphone, CheckCircle2, Clock, MapPin, Sparkles, Activity, FileText, RefreshCw } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export const STADIUM_ZONES = [
  {
    id: "nw",
    name: "North-West (Gate A/H)",
    sub: "Sec 124-127, Verizon/VIP Lobby",
    keywords: ["124", "125", "126", "127", "gate a", "gate h", "verizon", "executive", "vip"],
    restroom: "Sec 124, 125"
  },
  {
    id: "n",
    name: "North End",
    sub: "Sec 128-134, North Concourse",
    keywords: ["128", "129", "130", "131", "132", "133", "134", "north gate", "north"],
    restroom: "Sec 128, 129"
  },
  {
    id: "ne",
    name: "North-East (Gate B)",
    sub: "Sec 131-133, Hyland Gate",
    keywords: ["131", "132", "133", "gate b", "hyland"],
    restroom: "Sec 133"
  },
  {
    id: "w",
    name: "West Sideline (Gate F/G)",
    sub: "Sec 117-123, SAP/Amex Lobby",
    keywords: ["117", "118", "119", "120", "121", "122", "123", "gate f", "gate g", "sap", "amex", "west"],
    restroom: "Sec 118, 120, 122"
  },
  {
    id: "pitch",
    name: "Field / Pitch",
    sub: "Main Arena Playing Field",
    keywords: ["pitch", "field", "playing", "turf", "player", "bench", "grass"],
    restroom: "None"
  },
  {
    id: "e",
    name: "East Sideline (Gate C)",
    sub: "Sec 135-149, Pepsi Gate",
    keywords: ["135", "136", "137", "138", "139", "140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "gate c", "pepsi", "east"],
    restroom: "Sec 139, 143, 144"
  },
  {
    id: "sw",
    name: "South-West Plaza",
    sub: "Sec 110-116, Lower Corner",
    keywords: ["110", "111", "112", "113", "114", "115", "116"],
    restroom: "Sec 112, 116"
  },
  {
    id: "s",
    name: "South End",
    sub: "Sec 101-109, South Concourse",
    keywords: ["101", "102", "103", "104", "105", "106", "107", "108", "109", "south gate", "south"],
    restroom: "Sec 103, 107, 108"
  },
  {
    id: "se",
    name: "South-East (Gate D/E)",
    sub: "Sec 101-108, Bud/Corona Gate",
    keywords: ["gate d", "gate e", "bud light", "corona", "budlight"],
    restroom: "Sec 103, 112"
  }
];

export const getIncidentZoneId = (incident: IncidentAlert): string => {
  const loc = (incident.location || "").toLowerCase();
  const desc = (incident.what || "").toLowerCase();
  
  for (const zone of STADIUM_ZONES) {
    if (zone.id === "pitch") continue;
    for (const kw of zone.keywords) {
      if (loc.includes(kw)) {
        return zone.id;
      }
    }
  }

  const pitchZone = STADIUM_ZONES.find(z => z.id === "pitch");
  if (pitchZone) {
    for (const kw of pitchZone.keywords) {
      if (loc.includes(kw) || desc.includes(kw)) {
        return "pitch";
      }
    }
  }

  if (/\b(124|125|126|127)\b/.test(loc)) return "nw";
  if (/\b(128|129|130|134)\b/.test(loc)) return "n";
  if (/\b(131|132|133)\b/.test(loc)) return "ne";
  if (/\b(117|118|119|120|121|122|123)\b/.test(loc)) return "w";
  if (/\b(135|136|137|138|139|140|141|142|143|144|145|146|147|148|149)\b/.test(loc)) return "e";
  if (/\b(110|111|112|113|114|115|116)\b/.test(loc)) return "sw";
  if (/\b(101|102|103|104|105|106|107|108|109)\b/.test(loc)) return "s";

  return "pitch";
};

export default function AlertTab() {
  // Safety Strobe State
  const [isStrobeActive, setIsStrobeActive] = useState(false);
  const [strobeProgress, setStrobeProgress] = useState(0);
  const [isHolding, setIsHolding] = useState(false);
  const strobeRef = useRef<HTMLDivElement>(null);

  // Strobe effect to toggle white and cyan background directly on DOM ref for speed/responsiveness
  useEffect(() => {
    if (!isStrobeActive) return;
    let toggle = false;
    const interval = setInterval(() => {
      if (strobeRef.current) {
        strobeRef.current.style.backgroundColor = toggle ? "#ffffff" : "#06b6d4";
      }
      toggle = !toggle;
    }, 60);

    return () => {
      clearInterval(interval);
    };
  }, [isStrobeActive]);

  // Handle strobe charging hold timers
  useEffect(() => {
    let intervalId: any = null;
    if (isHolding && !isStrobeActive) {
      const startTime = Date.now();
      const duration = 1000; // 1 second hold to activate
      intervalId = setInterval(() => {
        const elapsed = Date.now() - startTime;
        const progress = Math.min((elapsed / duration) * 100, 100);
        setStrobeProgress(progress);
        if (progress >= 100) {
          setIsStrobeActive(true);
          setIsHolding(false);
          setStrobeProgress(0);
          clearInterval(intervalId);
        }
      }, 20);
    } else {
      setStrobeProgress(0);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [isHolding, isStrobeActive]);

  const startHolding = (e: React.MouseEvent | React.TouchEvent) => {
    setIsHolding(true);
  };

  const stopHolding = () => {
    setIsHolding(false);
  };

  // Incident Reporting State
  const [incidents, setIncidents] = useState<IncidentAlert[]>([]);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [selectedFilterZoneId, setSelectedFilterZoneId] = useState<string | null>(null);
  const [isSubmittingIncident, setIsSubmittingIncident] = useState(false);
  const [incidentCategory, setIncidentCategory] = useState<IncidentAlert["category"]>("medical");
  const [incidentLocation, setIncidentLocation] = useState("");
  const [incidentWho, setIncidentWho] = useState("");
  const [incidentWhat, setIncidentWhat] = useState("");
  const [incidentUrgency, setIncidentUrgency] = useState<IncidentAlert["urgency"]>("medium");
  const [incidentSuccessMessage, setIncidentSuccessMessage] = useState(false);

  // Megaphone Script State
  const [situationText, setSituationText] = useState("");
  const [isGeneratingScript, setIsGeneratingScript] = useState(false);
  const [generatedScript, setGeneratedScript] = useState<CrowdScriptResponse | null>(null);
  const [scriptError, setScriptError] = useState("");

  // Quick template for situation text to speed up megaphone scripting
  const QUICK_SITUATION_TEMPLATES = [
    "Gate C bottleneck, line stopped, fans getting pushy",
    "Section 112 main restroom has a leak, line is chaotic",
    "Section 118 elevator bank is jammed with wheelchairs, need order",
    "Severe delay at bag check Verizon Gate, need crowd to back up"
  ];

  // Fetch current incidents from backend on load
  const fetchIncidents = async () => {
    try {
      const response = await fetch("/api/incidents");
      if (response.ok) {
        const data = await response.json();
        setIncidents(data);
      }
    } catch (err) {
      console.error("Error fetching incidents:", err);
    }
  };

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    await fetchIncidents();
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  useEffect(() => {
    fetchIncidents();
    // Poll incidents every 10 seconds to simulate real-time coordination updates
    const interval = setInterval(fetchIncidents, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleEscalateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!incidentLocation || !incidentWho || !incidentWhat) {
      alert("Please fill in all incident details before escalating.");
      return;
    }

    setIsSubmittingIncident(true);
    try {
      const response = await fetch("/api/escalate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          category: incidentCategory,
          location: incidentLocation,
          who: incidentWho,
          what: incidentWhat,
          urgency: incidentUrgency
        })
      });

      if (response.ok) {
        setIncidentSuccessMessage(true);
        setIncidentLocation("");
        setIncidentWho("");
        setIncidentWhat("");
        fetchIncidents(); // Refresh log
        setTimeout(() => setIncidentSuccessMessage(false), 5000);
      } else {
        const errData = await response.json();
        alert(`Failed to escalate: ${errData.error || "Unknown error"}`);
      }
    } catch (err) {
      console.error("Incident escalation failed:", err);
      alert("Network error: failed to submit escalation.");
    } finally {
      setIsSubmittingIncident(false);
    }
  };

  const handleGenerateScript = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!situationText.trim()) {
      alert("Please enter a situation description first.");
      return;
    }

    setIsGeneratingScript(true);
    setScriptError("");
    setGeneratedScript(null);

    try {
      const response = await fetch("/api/crowd-script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ situation: situationText })
      });

      if (response.ok) {
        const data = await response.json();
        setGeneratedScript(data);
      } else {
        const errData = await response.json();
        setScriptError(errData.error || "Failed to generate megaphone scripts.");
      }
    } catch (err) {
      console.error("Script generation error:", err);
      setScriptError("Connection error. Ensure your server is active.");
    } finally {
      setIsGeneratingScript(false);
    }
  };

  return (
    <div className="space-y-8" id="alert-tab-container">
      {/* Stadium Zone Grid Heatmap */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden" id="stadium-blueprint-deck">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-emerald-500 to-red-500 opacity-60" />
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800/80 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950/40 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
              <Activity className="w-5.5 h-5.5 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-white">MetLife Stadium Blueprint Grid</h2>
              <p className="text-slate-400 text-xs mt-0.5">Real-time incident heatmap. Click a zone to filter the log below or pre-fill reporting coordinates.</p>
            </div>
          </div>
          {selectedFilterZoneId && (
            <button
              onClick={() => setSelectedFilterZoneId(null)}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-cyan-400 font-bold px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              Clear Filter ({STADIUM_ZONES.find(z => z.id === selectedFilterZoneId)?.name}) ×
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* 3x3 Grid Layout */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-3 gap-3">
              {STADIUM_ZONES.map((zone) => {
                const zoneIncidents = incidents.filter(
                  (inc) => getIncidentZoneId(inc) === zone.id && inc.status !== "resolved"
                );
                
                // Determine highest urgency level
                let highestUrgency: IncidentAlert["urgency"] | null = null;
                if (zoneIncidents.length > 0) {
                  if (zoneIncidents.some((inc) => inc.urgency === "critical")) {
                    highestUrgency = "critical";
                  } else if (zoneIncidents.some((inc) => inc.urgency === "high")) {
                    highestUrgency = "high";
                  } else if (zoneIncidents.some((inc) => inc.urgency === "medium")) {
                    highestUrgency = "medium";
                  } else {
                    highestUrgency = "low";
                  }
                }

                const isSelected = selectedFilterZoneId === zone.id;
                
                // Set color schemes according to highest active incident urgency
                let cardStyle = "bg-slate-950/50 border-slate-850 text-slate-400 hover:border-slate-700 hover:text-slate-200";
                let badgeStyle = "bg-slate-900 border-slate-800 text-slate-500";
                let pulseClass = "";

                if (highestUrgency === "critical") {
                  cardStyle = isSelected
                    ? "bg-red-950/80 border-red-500 text-red-100 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
                    : "bg-red-950/40 border-red-900/60 text-red-200 hover:bg-red-950/50";
                  badgeStyle = "bg-red-600 border-red-500 text-white font-black";
                  pulseClass = "animate-pulse ring-1 ring-red-500";
                } else if (highestUrgency === "high") {
                  cardStyle = isSelected
                    ? "bg-orange-950/80 border-orange-500 text-orange-100 shadow-[0_0_15px_rgba(249,115,22,0.2)]"
                    : "bg-orange-950/40 border-orange-900/60 text-orange-200 hover:bg-orange-950/50";
                  badgeStyle = "bg-orange-500 border-orange-400 text-black font-extrabold";
                  pulseClass = "ring-1 ring-orange-500";
                } else if (highestUrgency === "medium") {
                  cardStyle = isSelected
                    ? "bg-yellow-950/80 border-yellow-500 text-yellow-100 shadow-[0_0_15px_rgba(234,179,8,0.2)]"
                    : "bg-yellow-950/40 border-yellow-900/60 text-yellow-200 hover:bg-yellow-950/50";
                  badgeStyle = "bg-yellow-500 border-yellow-400 text-black font-bold";
                } else if (highestUrgency === "low") {
                  cardStyle = isSelected
                    ? "bg-cyan-950/80 border-cyan-500 text-cyan-100 shadow-[0_0_15px_rgba(6,182,212,0.2)]"
                    : "bg-cyan-950/40 border-cyan-900/60 text-cyan-200 hover:bg-cyan-950/50";
                  badgeStyle = "bg-cyan-500 border-cyan-400 text-black font-bold";
                } else if (isSelected) {
                  cardStyle = "bg-slate-900 border-cyan-500 text-cyan-200 shadow-[0_0_12px_rgba(6,182,212,0.15)]";
                }

                // Field/Pitch has a special icon or center layout style
                const isPitch = zone.id === "pitch";

                return (
                  <button
                    key={zone.id}
                    type="button"
                    onClick={() => {
                      if (selectedFilterZoneId === zone.id) {
                        setSelectedFilterZoneId(null);
                      } else {
                        setSelectedFilterZoneId(zone.id);
                        setIncidentLocation(zone.name);
                      }
                    }}
                    className={`p-3 rounded-xl border text-left transition-all min-h-[95px] flex flex-col justify-between cursor-pointer relative group ${cardStyle} ${pulseClass}`}
                    id={`blueprint-cell-${zone.id}`}
                  >
                    <div>
                      <div className="flex items-start justify-between gap-1.5">
                        <span className="text-[10px] font-black uppercase tracking-tight leading-tight group-hover:text-white transition-colors line-clamp-1">
                          {zone.name}
                        </span>
                        {zoneIncidents.length > 0 && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded-full border leading-none shrink-0 ${badgeStyle}`}>
                            {zoneIncidents.length}
                          </span>
                        )}
                      </div>
                      <p className="text-[9px] text-slate-500 mt-1 leading-normal line-clamp-2">
                        {zone.sub}
                      </p>
                    </div>

                    <div className="flex items-center justify-between text-[8px] border-t border-slate-900/30 pt-1.5 mt-2 text-slate-500">
                      <span>{zone.id === "pitch" ? "Field Area" : `Restroom: ${zone.restroom}`}</span>
                      <span className="text-cyan-400/80 font-mono font-bold uppercase tracking-wider scale-90 opacity-0 group-hover:opacity-100 transition-opacity">
                        {isSelected ? "Filter on" : "Filter"}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Side Info & Legends */}
          <div className="lg:col-span-4 flex flex-col justify-between bg-slate-950/40 border border-slate-850/80 rounded-xl p-4.5 space-y-4">
            <div>
              <span className="text-[9px] font-mono font-bold text-cyan-400 uppercase tracking-widest block mb-1">
                Visual Legend & Diagnostic
              </span>
              <h3 className="text-sm font-bold text-slate-200">
                {selectedFilterZoneId 
                  ? STADIUM_ZONES.find(z => z.id === selectedFilterZoneId)?.name 
                  : "All Sectors Monitored"}
              </h3>
              <p className="text-xs text-slate-400 leading-normal mt-1">
                {selectedFilterZoneId 
                  ? `Filtering shift logs for the ${STADIUM_ZONES.find(z => z.id === selectedFilterZoneId)?.name}. The report location input is automatically prefilled with this sector.`
                  : "Tap on any grid sector to isolate live incidents in that zone, or auto-fill coordinates to fast-track new dispatch reports."}
              </p>
            </div>

            {/* Urgency color legend */}
            <div className="space-y-2 border-t border-b border-slate-900 py-3">
              <span className="text-[9px] font-semibold text-slate-500 uppercase tracking-wider block">Urgency Status Color Heatmap</span>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="flex items-center gap-1.5 text-red-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse" />
                  <span>Critical Urgency</span>
                </div>
                <div className="flex items-center gap-1.5 text-orange-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-orange-500" />
                  <span>High Urgency</span>
                </div>
                <div className="flex items-center gap-1.5 text-yellow-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-yellow-500" />
                  <span>Medium Urgency</span>
                </div>
                <div className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                  <span className="w-2 h-2 rounded-full bg-cyan-500" />
                  <span>Low Urgency</span>
                </div>
              </div>
            </div>

            <div className="text-[10px] text-slate-500 bg-slate-900/30 p-2.5 rounded-lg border border-slate-900/80 leading-normal">
              <strong className="text-slate-400 block mb-0.5">Quick Automation:</strong>
              Double-click or click twice to clear filter. Click any zone to map your report instantly.
            </div>
          </div>
        </div>
      </div>

      {/* SECTION 1: Control Room Flagging */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden">
        {/* Glow border depending on urgency selection */}
        <div className={`absolute top-0 left-0 w-1.5 h-full ${
          incidentUrgency === "critical" ? "bg-red-500" :
          incidentUrgency === "high" ? "bg-orange-500" : "bg-cyan-500"
        }`} />

        <div className="flex items-center gap-3 border-b border-slate-800/80 pb-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-red-950/40 border border-red-900/50 flex items-center justify-center text-red-400">
            <ShieldAlert className="w-5.5 h-5.5" />
          </div>
          <div>
            <h2 className="text-lg font-bold font-display text-white">Flag to Control Room</h2>
            <p className="text-slate-400 text-xs mt-0.5">Direct link to stadium commanders for priority backup</p>
          </div>
        </div>

        <form onSubmit={handleEscalateSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Category Select */}
            <div>
              <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1.5">Incident Category</label>
              <div className="grid grid-cols-2 gap-2">
                {(["medical", "crowd", "safety", "aggressive_fan"] as const).map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => setIncidentCategory(cat)}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold capitalize transition-all ${
                      incidentCategory === cat
                        ? "bg-red-950/50 border-red-500 text-red-200 shadow-[0_0_12px_rgba(239,68,68,0.15)]"
                        : "bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700"
                    }`}
                    id={`cat-btn-${cat}`}
                  >
                    {cat.replace("_", " ")}
                  </button>
                ))}
              </div>
            </div>

            {/* Urgency Selection */}
            <div>
              <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1.5">Urgency Level</label>
              <div className="grid grid-cols-3 gap-2">
                {(["medium", "high", "critical"] as const).map((urg) => (
                  <button
                    key={urg}
                    type="button"
                    onClick={() => setIncidentUrgency(urg)}
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold capitalize transition-all ${
                      incidentUrgency === urg
                        ? urg === "critical"
                          ? "bg-red-950/80 border-red-500 text-red-200"
                          : urg === "high"
                          ? "bg-orange-950/60 border-orange-500 text-orange-200"
                          : "bg-cyan-950/60 border-cyan-500 text-cyan-200"
                        : "bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700"
                    }`}
                    id={`urg-btn-${urg}`}
                  >
                    {urg}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Location */}
            <div>
              <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1">Exact Location</label>
              <input
                type="text"
                value={incidentLocation}
                onChange={(e) => setIncidentLocation(e.target.value)}
                placeholder="E.g., Section 124, right outside main restroom"
                className="w-full bg-slate-950/80 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2.5 text-sm text-slate-200"
                id="incident-location-input"
              />
            </div>

            {/* Who is involved */}
            <div>
              <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1">Who is involved?</label>
              <input
                type="text"
                value={incidentWho}
                onChange={(e) => setIncidentWho(e.target.value)}
                placeholder="E.g., Female fan with 2 children, or Elderly gentleman"
                className="w-full bg-slate-950/80 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2.5 text-sm text-slate-200"
                id="incident-who-input"
              />
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1">What is happening?</label>
            <textarea
              value={incidentWhat}
              onChange={(e) => setIncidentWhat(e.target.value)}
              placeholder="Provide key details for response teams. Keep it direct and clear..."
              rows={3}
              className="w-full bg-slate-950/80 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2.5 text-sm text-slate-200 resize-none"
              id="incident-what-input"
            />
          </div>

          <div className="flex items-center justify-between pt-1">
            <AnimatePresence>
              {incidentSuccessMessage && (
                <motion.div
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  className="flex items-center gap-2 text-emerald-400 text-xs font-semibold"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Escalated to Command Center. Security/Medics dispatched.</span>
                </motion.div>
              )}
            </AnimatePresence>

            <button
              type="submit"
              disabled={isSubmittingIncident}
              className={`ml-auto flex items-center gap-2 px-5 py-3 rounded-xl font-bold font-display transition-all text-sm cursor-pointer ${
                incidentUrgency === "critical"
                  ? "bg-red-600 hover:bg-red-500 text-white shadow-[0_4px_16px_rgba(220,38,38,0.3)]"
                  : incidentUrgency === "high"
                  ? "bg-orange-600 hover:bg-orange-500 text-white"
                  : "bg-cyan-600 hover:bg-cyan-500 text-black font-extrabold"
              } disabled:opacity-50`}
              id="escalate-submit-btn"
            >
              {isSubmittingIncident ? (
                <>
                  <div className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                  <span>Flagging...</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Transmit Alert</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* SECTION 2: Megaphone Script Generator */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden">
        <div className="flex items-center gap-3 border-b border-slate-800/80 pb-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-cyan-950/40 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
            <Megaphone className="w-5.5 h-5.5" />
          </div>
          <div>
            <h2 className="text-lg font-bold font-display text-white">Megaphone Script Generator</h2>
            <p className="text-slate-400 text-xs mt-0.5">Quickly generate calming, authority instructions in 3 languages</p>
          </div>
        </div>

        <form onSubmit={handleGenerateScript} className="space-y-4">
          <div>
            <label className="block text-slate-500 text-[11px] font-bold uppercase tracking-wider mb-1.5">Describe current situation</label>
            <textarea
              value={situationText}
              onChange={(e) => setSituationText(e.target.value)}
              placeholder="What crowd bottleneck or block do you need to address? E.g. Gate B ticketing scanner is down, lines must split..."
              rows={2}
              className="w-full bg-slate-950/80 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2.5 text-sm text-slate-200 resize-none"
              id="situation-input"
            />
          </div>

          {/* Quick-select templates */}
          <div className="space-y-1.5">
            <span className="block text-slate-500 text-[10px] font-semibold uppercase tracking-wider">Quick Crowd Scenarios</span>
            <div className="flex flex-wrap gap-2">
              {QUICK_SITUATION_TEMPLATES.map((tpl, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setSituationText(tpl)}
                  className="text-[11px] font-medium bg-slate-950 border border-slate-800 hover:border-cyan-800 hover:text-cyan-400 text-slate-400 px-3 py-1.5 rounded-lg transition-colors"
                  id={`scenario-btn-${idx}`}
                >
                  {tpl.length > 40 ? `${tpl.substring(0, 37)}...` : tpl}
                </button>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-1">
            <button
              type="submit"
              disabled={isGeneratingScript || !situationText.trim()}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold font-display text-sm disabled:opacity-50 cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.2)]"
              id="generate-script-btn"
            >
              {isGeneratingScript ? (
                <>
                  <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>Drafting Announcements...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-950" />
                  <span>Compose Announcement</span>
                </>
              )}
            </button>
          </div>
        </form>

        {/* Display generated scripts */}
        {scriptError && (
          <div className="mt-4 bg-red-950/30 border border-red-900/60 p-3 rounded-xl text-xs text-red-400">
            {scriptError}
          </div>
        )}

        <AnimatePresence>
          {generatedScript && (
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              className="mt-6 border border-cyan-800/50 bg-cyan-950/20 rounded-2xl p-4.5 space-y-4"
              id="generated-script-display"
            >
              <div className="flex items-center justify-between border-b border-cyan-900/40 pb-2">
                <span className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                  <Megaphone className="w-3.5 h-3.5" />
                  Official Megaphone Announcement Scripts
                </span>
                <span className="text-[10px] text-slate-500 font-mono">FIFA-Grounded</span>
              </div>

              {/* Multi-language grids */}
              <div className="space-y-4">
                {/* English */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                    <span className="text-xs font-semibold text-slate-300">English (Slow & Direct)</span>
                  </div>
                  <p className="text-sm font-medium text-white pl-3 border-l border-cyan-900/80 leading-relaxed font-display italic">
                    "{generatedScript.englishAnnouncement}"
                  </p>
                </div>

                {/* Spanish */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-pink-500" />
                    <span className="text-xs font-semibold text-slate-300">Spanish / Español</span>
                  </div>
                  <p className="text-sm font-medium text-pink-100 pl-3 border-l border-pink-900/40 leading-relaxed font-display italic">
                    "{generatedScript.spanishAnnouncement}"
                  </p>
                </div>

                {/* Portuguese */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span className="text-xs font-semibold text-slate-300">Portuguese / Português</span>
                  </div>
                  <p className="text-sm font-medium text-emerald-100 pl-3 border-l border-emerald-900/40 leading-relaxed font-display italic">
                    "{generatedScript.portugueseAnnouncement}"
                  </p>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* SECTION 3: Tactical Safety Locator Beacon */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-950/40 border border-cyan-800/50 flex items-center justify-center text-cyan-400">
              <ShieldAlert className="w-5.5 h-5.5 text-pink-500 animate-pulse" />
            </div>
            <div>
              <h2 className="text-lg font-bold font-display text-white">Tactical Safety Beacon</h2>
              <p className="text-slate-400 text-xs mt-0.5">High-visibility signaling for emergencies & low light</p>
            </div>
          </div>
          <span className="text-[9px] font-mono font-bold bg-pink-950/50 text-pink-400 px-2 py-0.5 rounded border border-pink-900/40">
            SECURE BEACON
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
          <div className="space-y-2 text-slate-300 text-xs leading-relaxed">
            <p>
              If trapped, injured, or navigating stadium corridor blockages in low light, use the 
              <strong className="text-white"> Safety Strobe</strong> to signal first responders.
            </p>
            <p className="text-[10px] text-pink-400/90 font-semibold flex items-center gap-1.5 bg-pink-950/20 border border-pink-900/30 p-2 rounded-lg">
              <span>⚠ Warning: High-frequency flashing white and cyan strobe. Do not use if sensitive to flashing light.</span>
            </p>
          </div>

          {/* Big holding press target */}
          <div className="flex flex-col items-center justify-center p-3">
            <div 
              className="relative w-36 h-36 flex items-center justify-center cursor-pointer select-none"
              onMouseDown={startHolding}
              onMouseUp={stopHolding}
              onMouseLeave={stopHolding}
              onTouchStart={startHolding}
              onTouchEnd={stopHolding}
              id="safety-strobe-trigger"
            >
              {/* SVG Circular Progress Ring */}
              <svg className="absolute inset-0 w-full h-full transform -rotate-90">
                {/* Track ring */}
                <circle 
                  cx="72" 
                  cy="72" 
                  r="60" 
                  className="stroke-slate-950/80 fill-none" 
                  strokeWidth="6" 
                />
                {/* Progress ring */}
                <circle 
                  cx="72" 
                  cy="72" 
                  r="60" 
                  className="stroke-cyan-400 fill-none transition-all duration-75" 
                  strokeWidth="6" 
                  strokeDasharray={2 * Math.PI * 60}
                  strokeDashoffset={2 * Math.PI * 60 * (1 - strobeProgress / 100)}
                  strokeLinecap="round"
                />
              </svg>

              {/* Central Button Body */}
              <div className={`w-24 h-24 rounded-full flex flex-col items-center justify-center border transition-all text-center p-2.5 ${
                isHolding 
                  ? "bg-cyan-500/10 border-cyan-400 scale-95 shadow-[0_0_25px_rgba(6,182,212,0.4)] text-cyan-400" 
                  : "bg-slate-950 border-slate-850 text-slate-400 hover:border-cyan-800/80 hover:text-cyan-400"
              }`}>
                <ShieldAlert className={`w-7 h-7 mb-1 transition-transform ${isHolding ? "scale-110 animate-bounce text-cyan-400" : ""}`} />
                <span className="text-[9px] font-black uppercase tracking-wider leading-none">
                  {isHolding ? "HOLDING..." : "PRESS & HOLD"}
                </span>
                <span className="text-[8px] opacity-60 mt-0.5">FOR STROBE</span>
              </div>
            </div>
            
            {/* Percentage hint */}
            <span className="text-[10px] font-mono text-slate-500 font-bold mt-2">
              {strobeProgress > 0 ? `Charging Beacon: ${Math.round(strobeProgress)}%` : "Hold 1s to ignite locator strobe"}
            </span>
          </div>
        </div>
      </div>

      {/* SECTION 4: Live Incident Status Feed */}
      <div className="space-y-3">

      {/* Fullscreen Flashing Strobe Overlay */}
      <AnimatePresence>
        {isStrobeActive && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex flex-col justify-between p-6 select-none cursor-pointer"
            onClick={() => setIsStrobeActive(false)}
            ref={strobeRef}
            id="emergency-strobe-overlay"
          >
            <div className="flex justify-between items-center bg-black/90 text-white rounded-2xl px-4 py-3 border border-white/20">
              <span className="text-xs font-black uppercase tracking-widest flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
                VOLT EMERGENCY LOCATOR BEACON
              </span>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  setIsStrobeActive(false);
                }}
                className="px-3.5 py-1.5 bg-white text-black font-black uppercase text-[10px] rounded-lg border-2 border-black"
              >
                DISMISS
              </button>
            </div>

            <div className="flex-1 flex flex-col justify-center items-center text-center space-y-4 px-4">
              <div className="bg-black/95 p-6 sm:p-8 rounded-[2rem] border-4 border-white text-white shadow-2xl max-w-sm space-y-4">
                <ShieldAlert className="w-16 h-16 text-cyan-400 mx-auto animate-bounce" />
                <h2 className="text-2xl font-black uppercase tracking-tight leading-none font-display text-white">
                  STROBE SIGNAL ACTIVE
                </h2>
                <p className="text-xs text-neutral-300 leading-relaxed font-semibold">
                  This bright, high-frequency white/cyan strobe signal helps tactical emergency responders locate your exact coordinates in dark, crowded, or low-light stadium sectors.
                </p>
                <div className="bg-white/15 p-2.5 rounded-xl border border-white/15">
                  <p className="text-[10px] font-black uppercase text-cyan-300">
                    TAP ANYWHERE ON SCREEN TO STOP
                  </p>
                </div>
              </div>
            </div>

            <div className="text-center bg-black/90 text-neutral-400 py-2.5 px-4 rounded-xl text-[10px] uppercase font-bold border border-white/20">
              FIFA World Cup 2026 • Stadium Emergency Safety Operations
            </div>
          </motion.div>
        )}
      </AnimatePresence>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400">
            <Activity className="w-4 h-4 text-cyan-400" />
            <h3 className="text-xs font-bold uppercase tracking-wider">Active Incident Coordinates</h3>
          </div>
          <button 
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-xs text-cyan-400 font-extrabold transition-all cursor-pointer select-none active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
            id="refresh-feed-btn"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : "text-cyan-500"}`} />
            <span>{isRefreshing ? "Syncing..." : "Refresh Feed"}</span>
          </button>
        </div>

        <div className="space-y-3 max-h-[350px] overflow-y-auto pr-1">
          {(() => {
            const filteredIncidents = selectedFilterZoneId
              ? incidents.filter((inc) => getIncidentZoneId(inc) === selectedFilterZoneId)
              : incidents;

            if (filteredIncidents.length === 0) {
              return (
                <div className="bg-slate-950/60 border border-slate-900 rounded-xl p-6 text-center text-slate-500 text-xs animate-pulse">
                  {selectedFilterZoneId
                    ? `No active, unresolved incidents found in ${STADIUM_ZONES.find(z => z.id === selectedFilterZoneId)?.name}.`
                    : "No reported incidents on this shift quadrant."}
                </div>
              );
            }

            return filteredIncidents.map((inc) => (
              <div 
                key={inc.id}
                className="bg-slate-950 border border-slate-900 rounded-xl p-4 flex gap-3 relative"
                id={`incident-card-${inc.id}`}
              >
                {/* Left indicator bar based on urgency */}
                <div className={`absolute top-0 left-0 w-1 h-full rounded-l-xl ${
                  inc.urgency === "critical" ? "bg-red-500" :
                  inc.urgency === "high" ? "bg-orange-500" : "bg-cyan-500"
                }`} />

                <div className="space-y-2 flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-mono font-bold text-slate-300 flex items-center gap-1">
                      <FileText className="w-3 h-3 text-slate-500" />
                      {inc.id}
                    </span>
                    <span className={`inline-flex items-center gap-1 text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                      inc.status === "resolved" 
                        ? "bg-emerald-950 text-emerald-400 border border-emerald-900"
                        : inc.status === "dispatched"
                        ? "bg-orange-950 text-orange-400 border border-orange-900"
                        : "bg-yellow-950 text-yellow-500 border border-yellow-900"
                    }`}>
                      <span className={`w-1 h-1 rounded-full ${
                        inc.status === "resolved" ? "bg-emerald-400" : "bg-orange-400 animate-pulse"
                      }`} />
                      {inc.status}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <div className="flex items-center gap-1.5 text-xs text-slate-400">
                      <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <strong className="text-slate-300">{inc.location}</strong>
                    </div>
                    <p className="text-xs text-slate-400 font-medium pl-5">
                      <span className="text-slate-500">Involved:</span> {inc.who}
                    </p>
                    <p className="text-xs text-slate-400 pl-5 leading-normal">
                      <span className="text-slate-500">Details:</span> {inc.what}
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-900 text-[10px] text-slate-500">
                    <span>Incident Area: <span className="capitalize text-slate-400">{inc.category}</span></span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(inc.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              </div>
            ));
          })()}
        </div>
      </div>
    </div>
  );
}
