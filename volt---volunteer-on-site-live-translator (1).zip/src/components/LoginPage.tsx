import React, { useState } from "react";
import { User, ShieldAlert, Key, ArrowRight, ShieldCheck, Trophy, Sparkles } from "lucide-react";
import { motion } from "motion/react";
import AnimatedFootballerLogo from "./AnimatedFootballerLogo";

interface LoginPageProps {
  onLoginSuccess: (volunteerName: string) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [volId, setVolId] = useState("");
  const [passcode, setPasscode] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!volId.trim()) {
      setErrorMsg("Please enter your Volunteer Badge ID.");
      return;
    }
    
    // Accept 2026 or FIFA2026 as tactical passcode
    if (passcode !== "2026" && passcode !== "FIFA2026") {
      setErrorMsg("Invalid Tactical Passcode. (Try using: 2026)");
      return;
    }

    setErrorMsg("");
    setIsSubmitting(true);

    // Simulate cryptographic authorization check
    setTimeout(() => {
      setIsSubmitting(false);
      onLoginSuccess(volId.trim().toUpperCase());
    }, 1200);
  };

  const handleInstantBypass = () => {
    onLoginSuccess("VOLUNTEER CHRIS");
  };

  return (
    <div className="w-full max-w-md mx-auto px-4 py-8 flex flex-col items-center justify-center min-h-[80vh] relative z-20 font-sans" id="volt-login-page-container">
      
      {/* Decorative ambient background glows */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] h-[350px] bg-cyan-500/10 rounded-full filter blur-[80px] -z-10 pointer-events-none" />
      <div className="absolute top-1/3 left-1/3 w-[250px] h-[250px] bg-pink-500/5 rounded-full filter blur-[60px] -z-10 pointer-events-none" />

      {/* Cyber/Tactical Card Container */}
      <motion.div
        initial={{ opacity: 0, y: 25, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="w-full bg-slate-950/80 border border-slate-800/80 hover:border-cyan-500/30 rounded-2xl p-6 sm:p-8 backdrop-blur-md shadow-[0_20px_50px_rgba(0,0,0,0.8),_0_0_30px_rgba(6,182,212,0.05)] relative overflow-hidden transition-all duration-500"
        id="volt-login-card"
      >
        {/* Dynamic visual indicator strip on top */}
        <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-cyan-500 via-cyan-400 to-pink-500" />

        {/* Header Section */}
        <div className="flex flex-col items-center text-center space-y-4 mb-8">
          {/* Main Glowing Logo */}
          <AnimatedFootballerLogo />

          <div className="space-y-1.5 pt-2">
            <div className="flex items-center justify-center gap-2">
              <Trophy className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[10px] font-mono font-black uppercase tracking-[0.25em] text-slate-400">
                MetLife Stadium Hub
              </span>
            </div>
            <h2 className="text-2xl font-black font-display text-white tracking-wide">
              VOLT GATEWAY
            </h2>
            <p className="text-slate-400 text-xs max-w-xs mx-auto leading-relaxed">
              Volunteer On-site Live Translator • Secure Authorization Panel
            </p>
          </div>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleSubmitLogin} className="space-y-5">
          
          {/* Volunteer Badge ID Input */}
          <div className="space-y-2">
            <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest pl-1 block">
              Volunteer Badge ID
            </label>
            <div className="relative group">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-cyan-400 transition-colors" />
              <input
                type="text"
                value={volId}
                onChange={(e) => setVolId(e.target.value)}
                placeholder="e.g. VOL-2026"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900/60 border border-slate-800/80 focus:border-cyan-500 text-white text-xs outline-none transition-all placeholder:text-slate-600 font-bold tracking-wide focus:shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                required
                id="login-badge-input"
              />
            </div>
          </div>

          {/* Tactical Passcode Input */}
          <div className="space-y-2">
            <div className="flex justify-between items-center px-1">
              <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">
                Tactical Passcode
              </label>
              <span className="text-[9px] text-cyan-400 font-mono font-bold bg-cyan-950/50 border border-cyan-900/40 px-1.5 py-0.5 rounded">
                Hint: 2026
              </span>
            </div>
            <div className="relative group">
              <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500 group-focus-within:text-pink-400 transition-colors" />
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="••••"
                className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-900/60 border border-slate-800/80 focus:border-pink-500 text-white text-xs outline-none transition-all placeholder:text-slate-600 font-mono font-bold focus:shadow-[0_0_12px_rgba(236,72,153,0.15)]"
                required
                id="login-passcode-input"
              />
            </div>
          </div>

          {/* Error Alert Display */}
          {errorMsg && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3.5 rounded-xl bg-red-950/30 border border-red-900/40 text-[11px] font-semibold text-red-400 flex items-start gap-2"
              id="login-error-alert"
            >
              <ShieldAlert className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
              <span>{errorMsg}</span>
            </motion.div>
          )}

          {/* Submit Authorization Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-extrabold text-xs uppercase tracking-widest transition-all shadow-[0_4px_15px_rgba(6,182,212,0.25)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 select-none hover:scale-[1.01]"
            id="login-submit-btn"
          >
            {isSubmitting ? (
              <>
                <div className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>Decrypting Signals...</span>
              </>
            ) : (
              <>
                <span>Authorize Tactical Portal</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>

        </form>

        {/* Quick Simulation Bypass */}
        <div className="pt-5 mt-5 border-t border-slate-900/80 flex flex-col gap-2">
          <span className="text-[10px] text-slate-500 font-bold flex items-center gap-1.5 justify-center">
            <Sparkles className="w-3.5 h-3.5 text-cyan-500/80" />
            Testing or reviewing the simulator interface?
          </span>
          <button
            onClick={handleInstantBypass}
            className="w-full py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400 font-bold hover:bg-slate-850 hover:border-slate-700 transition-all cursor-pointer text-xs uppercase tracking-wider"
            id="login-bypass-btn"
          >
            Instant Simulator Entry
          </button>
        </div>

      </motion.div>

      {/* Trust Seal Footer */}
      <div className="mt-6 flex items-center gap-2 text-[9px] font-mono font-bold text-slate-600 tracking-wider">
        <ShieldCheck className="w-3.5 h-3.5 text-cyan-500/40" />
        <span>SECURE HANDSHAKE ACTIVE</span>
      </div>

    </div>
  );
}
