import React, { useState, useMemo } from "react";
import { Search, BookOpen, Shield, HelpCircle, Heart, Wind, UserCheck, PhoneCall, Copy, Check, FileText, AlertOctagon, X, Minimize2, ExternalLink } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ManualSection {
  id: string;
  title: string;
  category: "emergency" | "gates" | "facilities" | "conduct";
  lastUpdated: string;
  content: {
    subtitle: string;
    steps: string[];
    tips: string[];
    quickContact?: string;
  }[];
}

const MANUAL_DATA: ManualSection[] = [
  {
    id: "medical-emergency",
    title: "Medical Emergency Protocols (AED & Cardiac)",
    category: "emergency",
    lastUpdated: "June 2026",
    content: [
      {
        subtitle: "Immediate Defibrillator (AED) Response",
        steps: [
          "Locate nearest AED: AEDs are situated at every Guest Services kiosk (Sections 117, 124, 128, 142, 149) and at First Aid stations.",
          "Alert dispatch immediately: Call Medical Dispatch on Gate Ch. 2 or click the 'Send Dispatch Request' in the Gateway.",
          "Clear the space: Direct surrounding fans back 6 feet to ensure medical staff have immediate access upon arrival.",
          "Begin CPR if certified: Follow standard chest compression procedures (100-120 per min) until EMTs arrive."
        ],
        tips: [
          "Do not leave the patient unattended. Direct a passing fan or fellow volunteer to retrieve the nearest AED.",
          "Always state the precise Section, Concourse level, and closest Column number during radio dispatch."
        ],
        quickContact: "Medical Control: Radio Channel 2"
      },
      {
        subtitle: "Extreme Heat & Dehydration Plan",
        steps: [
          "Identify Symptoms: Dizziness, dry mouth, heavy sweating, or cold pale skin indicate heat exhaustion.",
          "Relocate to Shaded Hydration Hubs: Walk the fan to indoor air-conditioned concourses or the South Plaza canopy.",
          "Distribute electrolyte packs: Retrieve electrolyte water bottles from any Guest Services hub (free for distressed fans).",
          "Escalate to Medical: If the fan exhibits confusion, vomiting, or hot dry skin, flag as a Critical Medical Emergency."
        ],
        tips: [
          "MetLife Stadium has 8 public water-refilling stations located near Sections 104, 117, 128, 142.",
          "Always encourage fans to alternate alcohol/soda with free stadium tap water."
        ]
      }
    ]
  },
  {
    id: "severe-weather",
    title: "Severe Weather & Evacuation Plan",
    category: "emergency",
    lastUpdated: "May 2026",
    content: [
      {
        subtitle: "Lightning Warning (8-Mile Threshold)",
        steps: [
          "Monitor Alerts: Stadium operations flags yellow alert when lightning strikes within 10 miles, and red alert within 8 miles.",
          "Announce Suspension: Match announcer will issue stadium-wide shelter-in-place instructions.",
          "Direct Fans to Safety: Guide fans from open-air bowl seating into the covered wide concourses, suite lobbies, or vehicles.",
          "Clear Playing Pitch: Help clear the field level immediately. Players, coaches, and staff go to lockers."
        ],
        tips: [
          "Never allow fans to congregate near high steel gates or exterior light poles during active lightning warnings.",
          "Remain inside the concourse structure until Stadium Safety Operations officially broadcasts a 'Clear to Resume' on Radio Ch. 1."
        ],
        quickContact: "Safety Ops: Ch. 1"
      }
    ]
  },
  {
    id: "gate-policies",
    title: "Gate Admission & Security Clearance",
    category: "gates",
    lastUpdated: "July 2026",
    content: [
      {
        subtitle: "Clear Bag Policy Enforcement",
        steps: [
          "Inspect Bag Dimensions: Bags must be clear plastic, vinyl, or PVC, not exceeding 12\" x 6\" x 12\".",
          "Permitted Clutches: Non-clear small clutch purses up to 4.5\" x 6.5\" (hand-size) are allowed.",
          "Medical Exceptions: Diaper bags, oxygen tanks, or medically necessary devices undergo special security tagging.",
          "Rerouting Fans: Fans with non-compliant bags must be directed to the paid bag-check lockers outside Gates A and C."
        ],
        tips: [
          "Provide free clear plastic bags (available at VIP lobbies) to fans transferring items from oversized purses.",
          "Never hold or guard non-compliant bags for fans on-site."
        ]
      },
      {
        subtitle: "Turnstile Failure & Ticket Backup Plan",
        steps: [
          "Manual Scanning Mode: If digital turnstiles disconnect, deploy handheld scanners immediately.",
          "Validate NFC Ticketing: Ensure fans have NFC passes added to Apple Wallet or Google Wallet, which scan offline.",
          "Redirect Ticket Inquiries: Send fans with invalid QR codes or double-bookings to the main Box Office near Gate F2."
        ],
        tips: [
          "Do not manually let a fan through without a positive scan beep or supervisor approval.",
          "Gate supervisors hold Master Keycards to bypass turnstiles for ADA-approved escorts."
        ],
        quickContact: "Box Office Support: Ext 5100"
      }
    ]
  },
  {
    id: "facilities",
    title: "Stadium Facilities & Fan Amenities",
    category: "facilities",
    lastUpdated: "April 2026",
    content: [
      {
        subtitle: "Sensory & Family Spaces",
        steps: [
          "Sensory Room Access: MetLife Sensory Room is located at Concourse Section 134. It is quiet, padded, and has fidget toys.",
          "Lactation Rooms: Private rooms for nursing parents are located near Sections 117 (West) and 142 (East).",
          "Sensory Bag Check-out: Sensory bags (noise-canceling headphones, weighted lap pads) are available at Section 124."
        ],
        tips: [
          "The sensory room does not require advanced booking. Simply guide the family to the door and notify the staff on site.",
          "Noise-canceling headphones are free to rent but require a valid ID as a security deposit."
        ]
      },
      {
        subtitle: "Lost Companion & Child Handoff",
        steps: [
          "Keep the child calm: Reassure the child and do not separate from them.",
          "Broadcast descriptions securely: Do not announce the child's name over radio. Broadcast only clothing, age, and location.",
          "Escort to Section 124: Walk the child directly to Guest Services HQ at Section 124.",
          "Verify Guardian ID: Guest Services supervisors will coordinate with Security to cross-check missing reports and verify IDs."
        ],
        tips: [
          "Always have a second volunteer present when escorts involve minors.",
          "Provide the lost child with a FIFA Kid-ID wristband, available pre-game at all guest kiosks."
        ],
        quickContact: "Child Safety Desk: Ext 4220"
      }
    ]
  },
  {
    id: "conduct-conflict",
    title: "Conduct, Conflicts & Language Barriers",
    category: "conduct",
    lastUpdated: "June 2026",
    content: [
      {
        subtitle: "De-escalation of Rowdy Supporters",
        steps: [
          "Maintain Calm Decorum: Use a firm, respectful tone. Avoid matching the fan's volume or aggression.",
          "Keep Physical Distance: Stand at least 3 feet back. Do not touch or restrain fans under any circumstances.",
          "Avoid Taking Sides: Acknowledge their frustration without promising exceptions to official FIFA policy.",
          "Trigger Security Escalation: If a fan threatens violence, refuses clear directions, or uses pyrotechnics, radio Security."
        ],
        tips: [
          "Your safety is paramount. Retreat if a fan becomes physically hostile.",
          "Take mental notes of jersey numbers, gate entries, or physical descriptions for incident reports."
        ],
        quickContact: "Stadium Security Force: Ch. 9"
      },
      {
        subtitle: "Severe Language Barrier Guidance",
        steps: [
          "Utilize the VOLT Gateway app: Swap instantly to the Translate Tab, press and hold the mic, and speak your direction.",
          "Enable 'Show to Fan' mode: Render the translated text in big visual card mode so they can read it instantly.",
          "Deploy Universal Pictograms: Point to stadium directional signage (restroom, exit, gate icons).",
          "Patience & Respect: Ensure the fan understands completely before concluding the interaction."
        ],
        tips: [
          "Speak slowly and clearly. Avoid slang or complex technical terms (e.g., use 'Entrance' instead of 'Turnstile ingress').",
          "When directing fans to gates, write the gate letter ('Gate C') in large letters on their phone screen or a slip of paper."
        ]
      }
    ]
  }
];

interface VolunteerManualProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function VolunteerManual({ isOpen, onClose }: VolunteerManualProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<"all" | "emergency" | "gates" | "facilities" | "conduct">("all");
  const [expandedSection, setExpandedSection] = useState<string | null>("medical-emergency");
  const [copiedText, setCopiedText] = useState<string | null>(null);

  // Filter and search manual sections
  const filteredManual = useMemo(() => {
    return MANUAL_DATA.filter((section) => {
      const matchesCategory = selectedCategory === "all" || section.category === selectedCategory;
      
      if (!matchesCategory) return false;
      
      if (!searchQuery.trim()) return true;
      
      const query = searchQuery.toLowerCase();
      const matchesTitle = section.title.toLowerCase().includes(query);
      
      const matchesContent = section.content.some((block) => {
        const matchesSubtitle = block.subtitle.toLowerCase().includes(query);
        const matchesSteps = block.steps.some(step => step.toLowerCase().includes(query));
        const matchesTips = block.tips.some(tip => tip.toLowerCase().includes(query));
        return matchesSubtitle || matchesSteps || matchesTips;
      });

      return matchesTitle || matchesContent;
    });
  }, [selectedCategory, searchQuery]);

  const handleCopyText = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div 
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto"
        id="manual-modal-overlay"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ type: "spring", duration: 0.4 }}
          className="w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-[0_24px_50px_rgba(0,0,0,0.9)] overflow-hidden flex flex-col max-h-[90vh]"
          id="volunteer-manual-modal-card"
        >
          {/* Header strip */}
          <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <BookOpen className="w-5.5 h-5.5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[9px] font-mono font-black tracking-widest text-cyan-400 bg-cyan-950 px-2 py-0.5 rounded border border-cyan-900/50">
                    FIFA 2026 STADIUM STANDARD
                  </span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[9px] font-mono font-bold text-emerald-400 uppercase tracking-wide">Secure Sync</span>
                </div>
                <h2 className="text-base font-extrabold text-white tracking-wide mt-0.5">
                  VOLT Tactical Volunteer Manual
                </h2>
              </div>
            </div>
            
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer border border-slate-800"
              id="close-manual-modal-top-btn"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Interactive Search bar */}
          <div className="bg-slate-950/40 border-b border-slate-800/60 p-4 flex flex-col md:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search manual (e.g., AED, lightning, clear bag, crowd de-escalation)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-850 focus:border-cyan-500 focus:outline-none rounded-xl pl-11 pr-4 py-2.5 text-xs text-slate-200 placeholder-slate-500 transition-colors"
                id="manual-search-box-input"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-300 font-bold"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Quick category selectors */}
            <div className="flex gap-1.5 overflow-x-auto scrollbar-none pb-1 md:pb-0">
              {([
                { id: "all", label: "All Chapters" },
                { id: "emergency", label: "Emergency" },
                { id: "gates", label: "Gate & Bags" },
                { id: "facilities", label: "Facilities" },
                { id: "conduct", label: "Conduct & Lang" }
              ] as const).map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition-all border whitespace-nowrap cursor-pointer ${
                    selectedCategory === cat.id
                      ? "bg-cyan-500 border-cyan-400 text-black shadow-[0_0_8px_rgba(6,182,212,0.15)]"
                      : "bg-slate-900 border-slate-850 text-slate-400 hover:border-slate-750 hover:text-white"
                  }`}
                  id={`manual-cat-tab-${cat.id}`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Core content scrolling block */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-slate-900/20" id="manual-scrollable-body">
            {filteredManual.length === 0 ? (
              <div className="py-12 text-center bg-slate-950/40 border border-slate-850/60 rounded-2xl">
                <HelpCircle className="w-12 h-12 text-slate-600 mx-auto mb-3 stroke-1" />
                <h3 className="text-sm font-bold text-slate-300">No Manual Procedures Match Your Search</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
                  Try simpler keywords or click on one of the tactical chapter filters above to browse general procedures.
                </p>
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("all");
                  }}
                  className="mt-4 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-cyan-400 font-bold text-xs cursor-pointer transition-all"
                >
                  Reset Manual Filters
                </button>
              </div>
            ) : (
              filteredManual.map((section) => {
                const isExpanded = expandedSection === section.id;
                
                return (
                  <div
                    key={section.id}
                    className={`border rounded-2xl transition-all overflow-hidden ${
                      isExpanded 
                        ? "bg-slate-950/90 border-cyan-500/30 shadow-[0_4px_25px_rgba(0,0,0,0.5)]" 
                        : "bg-slate-950/40 border-slate-800/80 hover:border-slate-700 hover:bg-slate-950/60"
                    }`}
                    id={`manual-section-${section.id}`}
                  >
                    {/* Header trigger */}
                    <button
                      onClick={() => setExpandedSection(isExpanded ? null : section.id)}
                      className="w-full px-5 py-4 flex items-center justify-between text-left cursor-pointer transition-colors"
                    >
                      <div className="space-y-1 pr-4">
                        <div className="flex items-center gap-2">
                          <span className={`text-[9px] font-mono font-black uppercase tracking-widest px-2 py-0.5 rounded leading-none ${
                            section.category === "emergency"
                              ? "bg-red-950 text-red-400 border border-red-900/30"
                              : section.category === "gates"
                              ? "bg-amber-950 text-amber-400 border border-amber-900/30"
                              : section.category === "facilities"
                              ? "bg-purple-950 text-purple-400 border border-purple-900/30"
                              : "bg-blue-950 text-blue-400 border border-blue-900/30"
                          }`}>
                            {section.category}
                          </span>
                          <span className="text-[9px] font-mono text-slate-500">Rev: {section.lastUpdated}</span>
                        </div>
                        <h3 className="text-sm font-black text-white tracking-wide mt-1 group-hover:text-cyan-400 transition-colors">
                          {section.title}
                        </h3>
                      </div>

                      <div className="shrink-0 flex items-center gap-2">
                        <span className="text-[10px] font-bold font-mono text-cyan-500/80 uppercase hidden sm:inline">
                          {isExpanded ? "Collapse" : "Expand"}
                        </span>
                        <div className={`w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 transition-transform duration-300 ${isExpanded ? "rotate-180 text-cyan-400 border-cyan-500/30" : ""}`}>
                          <Minimize2 className="w-4 h-4 scale-75" />
                        </div>
                      </div>
                    </button>

                    {/* Content Section */}
                    {isExpanded && (
                      <div className="px-5 pb-5 pt-1 border-t border-slate-900 space-y-5 animate-fadeIn">
                        {section.content.map((block, bIdx) => (
                          <div key={bIdx} className="space-y-3">
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-2">
                              <h4 className="text-xs font-bold text-cyan-400 flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                                {block.subtitle}
                              </h4>
                              {block.quickContact && (
                                <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-2.5 py-1 rounded-lg">
                                  <PhoneCall className="w-3 h-3 text-emerald-400" />
                                  <span className="text-[10px] font-mono font-bold text-slate-300">{block.quickContact}</span>
                                  <button
                                    onClick={() => handleCopyText(block.quickContact || "")}
                                    className="p-1 text-slate-500 hover:text-cyan-400 transition-colors cursor-pointer"
                                    title="Copy Contact Details"
                                  >
                                    {copiedText === block.quickContact ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                </div>
                              )}
                            </div>

                            {/* Step-by-Step Procedure */}
                            <div className="space-y-2">
                              <span className="text-[9px] font-mono font-black uppercase text-slate-500 tracking-wider">
                                Tactical Actions Sequence
                              </span>
                              <div className="space-y-2">
                                {block.steps.map((step, sIdx) => {
                                  // Style the keyword if colon is present
                                  const parts = step.split(":");
                                  const keyword = parts[0];
                                  const desc = parts.slice(1).join(":");

                                  return (
                                    <div key={sIdx} className="flex gap-3 text-xs leading-relaxed text-slate-300">
                                      <span className="font-mono font-bold text-cyan-500/80 bg-slate-900 border border-slate-850 px-1.5 py-0.5 rounded leading-none shrink-0 select-none h-fit">
                                        {sIdx + 1}
                                      </span>
                                      <p>
                                        {desc ? (
                                          <>
                                            <strong className="text-slate-100 font-extrabold">{keyword}:</strong>
                                            {desc}
                                          </>
                                        ) : (
                                          step
                                        )}
                                      </p>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>

                            {/* Guarded Tips */}
                            {block.tips && block.tips.length > 0 && (
                              <div className="p-3.5 bg-slate-900/30 border border-slate-900 rounded-xl space-y-1.5 mt-2">
                                <span className="text-[9px] font-extrabold uppercase tracking-widest text-emerald-400 flex items-center gap-1.5">
                                  <Shield className="w-3.5 h-3.5" />
                                  Guardian Tactical Field Tip
                                </span>
                                <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px] leading-relaxed">
                                  {block.tips.map((tip, tIdx) => (
                                    <li key={tIdx} className="marker:text-emerald-500/60">
                                      {tip}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Bottom Help-desk Action strip */}
          <div className="bg-slate-950 p-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px]">
            <div className="flex items-center gap-2 text-slate-400">
              <AlertOctagon className="w-4 h-4 text-cyan-400 shrink-0" />
              <span>Need high-level emergency authorization? Escalate through <strong>VOLT Channels</strong> immediately.</span>
            </div>
            
            <div className="flex items-center gap-3 w-full sm:w-auto shrink-0 justify-end">
              <button
                onClick={onClose}
                className="w-full sm:w-auto px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold uppercase text-[10px] tracking-wider transition-colors cursor-pointer text-center"
                id="close-manual-modal-footer-btn"
              >
                Close Handbook
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
