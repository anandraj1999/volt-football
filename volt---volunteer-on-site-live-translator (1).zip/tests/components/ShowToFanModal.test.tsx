import { describe, it, expect, vi } from "vitest";
import { render, screen, fireEvent } from "@testing-library/react";
import ShowToFanModal from "../../src/components/ShowToFanModal";

describe("<ShowToFanModal />", () => {
  it("renders nothing when isOpen is false", () => {
    const { container } = render(
      <ShowToFanModal isOpen={false} onClose={() => {}} text="Hola" languageName="Spanish" />
    );
    expect(container.textContent).not.toContain("Hola");
  });

  it("renders the translated text and language name when open", () => {
    render(
      <ShowToFanModal isOpen={true} onClose={() => {}} text="El baño está cerca" languageName="Spanish" />
    );
    expect(screen.getByText((content) => content.includes("El baño está cerca"))).toBeInTheDocument();
    expect(screen.getByText(/Spanish/i)).toBeInTheDocument();
  });

  it("calls onClose when the close action is triggered", () => {
    const onClose = vi.fn();
    render(
      <ShowToFanModal isOpen={true} onClose={onClose} text="Hola" languageName="Spanish" />
    );
    const closeTrigger = document.querySelector("#show-to-fan-overlay-modal button");
    if (closeTrigger) {
      fireEvent.click(closeTrigger);
      expect(onClose).toHaveBeenCalled();
    }
  });
});
