import "@testing-library/jest-dom/vitest";

// Ensure the API layer always exercises its deterministic offline
// fallback logic during tests instead of trying to reach the live
// Gemini API (no key is configured in CI/test environments).
process.env.NODE_ENV = process.env.NODE_ENV || "test";
delete process.env.GEMINI_API_KEY;
