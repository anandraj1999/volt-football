import { describe, it, expect } from "vitest";
import { STADIUM_DATA } from "../src/stadiumData";

const VALID_DIETARY_TAGS = ["vegetarian", "vegan", "gluten-free", "halal", "nut-free"];

describe("STADIUM_DATA grounding dataset", () => {
  it("has a venue name and capacity", () => {
    expect(typeof STADIUM_DATA.venueName).toBe("string");
    expect(STADIUM_DATA.venueName.length).toBeGreaterThan(0);
    expect(STADIUM_DATA.capacity).toBeGreaterThan(0);
  });

  it("defines all 8 gates (A-H) with unique ids and non-negative wait times", () => {
    expect(STADIUM_DATA.gates).toHaveLength(8);
    const ids = STADIUM_DATA.gates.map((g) => g.id);
    expect(new Set(ids).size).toBe(ids.length);
    expect(ids.sort()).toEqual(["A", "B", "C", "D", "E", "F", "G", "H"]);
    for (const gate of STADIUM_DATA.gates) {
      expect(gate.waitMinutes).toBeGreaterThanOrEqual(0);
      expect(gate.name.length).toBeGreaterThan(0);
    }
  });

  it("gives every concession only valid dietary tags", () => {
    expect(STADIUM_DATA.concessions.length).toBeGreaterThan(0);
    for (const stand of STADIUM_DATA.concessions) {
      for (const tag of stand.dietaryTags) {
        expect(VALID_DIETARY_TAGS).toContain(tag);
      }
    }
  });

  it("defines at least one medical station with a location and phone number", () => {
    expect(STADIUM_DATA.medicalStations.length).toBeGreaterThan(0);
    for (const station of STADIUM_DATA.medicalStations) {
      expect(station.location.length).toBeGreaterThan(0);
      expect(station.phone.length).toBeGreaterThan(0);
    }
  });

  it("has unique concession ids", () => {
    const ids = STADIUM_DATA.concessions.map((c) => c.id);
    expect(new Set(ids).size).toBe(ids.length);
  });
});
