import { describe, it, expect, beforeAll } from "vitest";
import request from "supertest";
import { createApp } from "../server";
import { STADIUM_DATA } from "../src/stadiumData";

let app: ReturnType<typeof createApp>;

beforeAll(() => {
  app = createApp();
});

describe("GET /api/health", () => {
  it("returns 200 with an ok status and the venue name", async () => {
    const res = await request(app).get("/api/health");
    expect(res.status).toBe(200);
    expect(res.body.status).toBe("ok");
    expect(res.body.venue).toBe(STADIUM_DATA.venueName);
    expect(res.body).toHaveProperty("timestamp");
    expect(res.body).toHaveProperty("apiConfigured");
  });
});

describe("GET /api/incidents", () => {
  it("returns an array seeded with the starting simulation incidents", async () => {
    const res = await request(app).get("/api/incidents");
    expect(res.status).toBe(200);
    expect(Array.isArray(res.body)).toBe(true);
    expect(res.body.length).toBeGreaterThanOrEqual(2);
    const ids = res.body.map((i: any) => i.id);
    expect(ids).toContain("INC-9102");
    expect(ids).toContain("INC-9103");
  });
});

describe("POST /api/escalate", () => {
  it("rejects a request missing required fields", async () => {
    const res = await request(app)
      .post("/api/escalate")
      .send({ category: "medical", location: "Section 104" }); // missing who/what/urgency
    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("error");
  });

  it("creates a new incident and prepends it to the feed", async () => {
    const payload = {
      category: "safety",
      location: "Gate D Concourse",
      who: "Volunteer report",
      what: "Spilled drink creating a slip hazard near the turnstiles",
      urgency: "high",
    };

    const createRes = await request(app).post("/api/escalate").send(payload);
    expect(createRes.status).toBe(201);
    expect(createRes.body.success).toBe(true);
    expect(createRes.body.incident).toMatchObject(payload);
    expect(createRes.body.incident.id).toMatch(/^INC-\d{4}$/);
    expect(createRes.body.incident.status).toBe("pending");

    const listRes = await request(app).get("/api/incidents");
    expect(listRes.body[0].id).toBe(createRes.body.incident.id);
  });
});

describe("POST /api/crowd-script", () => {
  it("rejects a request with no situation description", async () => {
    const res = await request(app).post("/api/crowd-script").send({});
    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("error");
  });

  it("falls back to a deterministic offline megaphone script when Gemini is unavailable", async () => {
    const res = await request(app)
      .post("/api/crowd-script")
      .send({ situation: "Heavy crowd bottleneck building up at Gate C" });

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("englishAnnouncement");
    expect(res.body).toHaveProperty("spanishAnnouncement");
    expect(res.body).toHaveProperty("portugueseAnnouncement");
    expect(res.body.englishAnnouncement.length).toBeGreaterThan(0);
  });
});

describe("POST /api/translate", () => {
  it("rejects an empty translation request", async () => {
    const res = await request(app).post("/api/translate").send({ text: "" });
    expect(res.status).toBe(400);
    expect(res.body).toHaveProperty("error");
  });

  it("grounds a food-related query to the correct intent and section via the offline fallback", async () => {
    const res = await request(app)
      .post("/api/translate")
      .send({ text: "Tengo hambre, donde hay comida", languageCode: "es" });

    expect(res.status).toBe(200);
    expect(res.body.detectedIntent).toBe("food");
    expect(res.body.detectedLanguage).toBe("Spanish");
    expect(res.body.fanResponse).toMatch(/116/);
  });

  it("grounds a medical-related query to the medical intent", async () => {
    const res = await request(app)
      .post("/api/translate")
      .send({ text: "I need medical help, someone is hurt", languageCode: "en" });

    expect(res.status).toBe(200);
    expect(res.body.detectedIntent).toBe("medical");
    expect(res.body.fanResponse).toMatch(/142/);
  });

  it("grounds an accessibility query for a wheelchair/elevator request", async () => {
    const res = await request(app)
      .post("/api/translate")
      .send({ text: "Where is the elevator for wheelchair access", languageCode: "en" });

    expect(res.status).toBe(200);
    expect(res.body.detectedIntent).toBe("accessibility");
  });

  it("falls back to the general intent for an out-of-scope question", async () => {
    const res = await request(app)
      .post("/api/translate")
      .send({ text: "asdkjaslkdj random gibberish", languageCode: "en" });

    expect(res.status).toBe(200);
    expect(res.body.detectedIntent).toBe("general");
    expect(res.body.groundingReference).toMatch(/124/);
  });
});
