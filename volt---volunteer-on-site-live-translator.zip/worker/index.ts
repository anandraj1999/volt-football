// Cloudflare Worker entry point for VOLT (Volunteer On-site Live Translator)
// This file mirrors the server.ts logic for deployment to Cloudflare Workers.

export interface Env {
  GEMINI_API_KEY: string;
}

export default {
  async fetch(request: Request, env: Env, ctx: any): Promise<Response> {
    const url = new URL(request.url);

    // Cors headers
    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization",
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { headers: corsHeaders });
    }

    // Route: /api/health
    if (url.pathname === "/api/health") {
      return new Response(JSON.stringify({
        status: "ok",
        platform: "Cloudflare Worker",
        timestamp: new Date().toISOString()
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    // Route: /api/translate
    if (url.pathname === "/api/translate" && request.method === "POST") {
      try {
        const body: any = await request.json();
        const { text, languageCode } = body;

        if (!text) {
          return new Response(JSON.stringify({ error: "Missing text to translate" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" }
          });
        }

        // Call Gemini API using the env secret
        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
        
        // Build systemic prompt
        const systemInstruction = `You are VOLT (Volunteer On-site Live Translator), an assistant for stadium volunteers at FIFA World Cup 2026. Keep it grounded.`;

        const geminiRequest = {
          contents: [{ parts: [{ text: `Translate and resolve: "${text}". Hint: ${languageCode || 'autoDetect'}` }] }],
          systemInstruction: { parts: [{ text: systemInstruction }] },
          generationConfig: {
            responseMimeType: "application/json"
          }
        };

        const res = await fetch(geminiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(geminiRequest)
        });

        const data: any = await res.json();
        const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";

        return new Response(responseText, {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });

      } catch (err: any) {
        return new Response(JSON.stringify({ error: err.message }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
    }

    // Route: /api/crowd-script
    if (url.pathname === "/api/crowd-script" && request.method === "POST") {
      try {
        const body: any = await request.json();
        const { situation } = body;

        const geminiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=${env.GEMINI_API_KEY}`;
        
        const prompt = `Generate a calm crowd control megaphone announcement script (English, Spanish, Portuguese) for: "${situation}"`;

        const res = await fetch(geminiUrl, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: prompt }] }],
            generationConfig: { responseMimeType: "application/json" }
          })
        });

        const data: any = await res.json();
        const responseText = data.candidates?.[0]?.content?.parts?.[0]?.text || "{}";

        return new Response(responseText, {
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      } catch (err: any) {
        return new Response(JSON.stringify({ error: err.message }), {
          status: 500,
          headers: { ...corsHeaders, "Content-Type": "application/json" }
        });
      }
    }

    return new Response(JSON.stringify({ error: "Not Found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" }
    });
  }
};
