import React, { useState } from "react";
import { STADIUM_DATA, Gate, Concession, MedicalStation } from "../stadiumData";
import { Search, Compass, Utensils, Accessibility, AlertCircle, HelpCircle, Clock, BookOpen, Globe, RefreshCw, ArrowUpDown } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ShowToFanModal from "./ShowToFanModal";

interface QuickAnswer {
  question: string;
  category: "gate" | "food" | "seating" | "restroom" | "medical" | "lost_found" | "policy";
  answer: string;
  groundingRef: string;
}

const QUICK_QUESTIONS: QuickAnswer[] = [
  {
    question: "Where is the nearest gluten-free food option?",
    category: "food",
    answer: "Tacocita at Concourse Section 104 is a 100% Gluten-Free Mexican street taco stand. Additionally, Global Greens at Section 116 offers gluten-free wraps, and Gluten-Free Oasis is at Section 130.",
    groundingRef: "Concessions Section 104, 116, 130"
  },
  {
    question: "Where is the nearest Halal certified food stand?",
    category: "food",
    answer: "Halal Corner is located at Concourse Section 142 (Chicken Shawarma, Falafel) and South Plaza Halal & Vegan is at Section 109 (Beyond Burger, French Fries).",
    groundingRef: "Concessions Section 142, Section 109"
  },
  {
    question: "Where is the nearest all-gender / family restroom?",
    category: "restroom",
    answer: "Family/All-Gender Restrooms are available near Section 129 (North), Section 144 (East), Section 108 (South), Section 120 (West), and in the ADA Suite corridor at Section 116.",
    groundingRef: "Restrooms database Zones 100"
  },
  {
    question: "Can I leave the stadium to get something from my car and come back?",
    category: "policy",
    answer: "No, re-entry is strictly prohibited. Once a fan exits through any gate turnstile, their digital ticket is permanently deactivated, and they cannot be readmitted.",
    groundingRef: "Stadium Re-entry Policy"
  },
  {
    question: "What is the maximum allowed bag size?",
    category: "policy",
    answer: "Only clear bags not exceeding 12\" x 6\" x 12\" are permitted. Small clutches up to 4.5\" x 6.5\" are allowed. Medical/diaper bags undergo detailed x-ray check at Gates A or C.",
    groundingRef: "Stadium Clear Bag Policy"
  },
  {
    question: "How does a fan request wheelchair escort or assistance?",
    category: "seating",
    answer: "Fans can request a wheelchair escort at any Gate plaza or Guest Services desk (near Sections 117, 124, 142). A volunteer with a designated stadium wheelchair will wheel them directly to their seats.",
    groundingRef: "Accessible Seating Assistance Process"
  },
  {
    question: "Where is the main Lost & Found center?",
    category: "lost_found",
    answer: "Guest Services Plaza Headquarters near Concourse Section 124 (West). Lost companions or children should also be directed here immediately.",
    groundingRef: "Lost & Found Section 124"
  },
  {
    question: "Which gate currently has the shortest waiting queue?",
    category: "gate",
    answer: `Gate D (Bud Light Gate) currently has the shortest queue with a wait time of only 4 minutes. Gate H (Executive) is 3 minutes but requires VIP/Suite tickets.`,
    groundingRef: "Gates Live Wait times"
  }
];

export default function QuickAnswersTab() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  
  // Translation drafting state
  const [activeTranslatingItem, setActiveTranslatingItem] = useState<string | null>(null);
  const [draftedTranslation, setDraftedTranslation] = useState<{
    detectedLanguage: string;
    fanResponse: string;
    phoneticSpelling: string;
  } | null>(null);
  const [translationLanguage, setTranslationLanguage] = useState<"es" | "pt" | "fr">("es");
  const [translationError, setTranslationError] = useState("");
  const [showToFanMode, setShowToFanMode] = useState(false);

  const handleSpeakAloud = (text: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = translationLanguage === "es" ? "es-ES" : translationLanguage === "pt" ? "pt-BR" : "fr-FR";
      window.speechSynthesis.speak(utterance);
    }
  };

  const handleDraftTranslation = async (answerText: string) => {
    setActiveTranslatingItem(answerText);
    setTranslationError("");
    setDraftedTranslation(null);

    try {
      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: `Translate this stadium answer to ${
            translationLanguage === "es" ? "Spanish" : translationLanguage === "pt" ? "Portuguese" : "French"
          }: "${answerText}"`,
          languageCode: translationLanguage
        })
      });

      if (response.ok) {
        const data = await response.json();
        setDraftedTranslation({
          detectedLanguage: data.detectedLanguage || "Translated",
          fanResponse: data.fanResponse,
          phoneticSpelling: data.phoneticSpelling
        });
      } else {
        const errData = await response.json();
        setTranslationError(errData.error || "Translation failed.");
      }
    } catch (err) {
      console.error("Error drafting quick translation:", err);
      setTranslationError("Connection error. Ensure your server is active.");
    } finally {
      setActiveTranslatingItem(null);
    }
  };

  const filteredQuestions = QUICK_QUESTIONS.filter((item) => {
    const matchesSearch = item.question.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "all" || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: "all", name: "All FAQs", icon: HelpCircle },
    { id: "gate", name: "Gates", icon: Compass },
    { id: "food", name: "Concessions", icon: Utensils },
    { id: "seating", name: "Accessibility", icon: Accessibility },
    { id: "restroom", name: "Restrooms", icon: HelpCircle },
    { id: "lost_found", name: "Lost & Found", icon: AlertCircle },
    { id: "policy", name: "Policies", icon: BookOpen }
  ];

  return (
    <div className="space-y-6" id="quick-answers-container">
      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-3.5 top-3.5 h-4.5 w-4.5 text-slate-500" />
        <input
          type="text"
          placeholder="Search stadium rules, food tags, or gates..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full bg-slate-900/80 border border-slate-800/80 focus:border-cyan-500 focus:outline-none rounded-2xl pl-11 pr-4 py-3 text-sm text-slate-200 placeholder-slate-500 transition-colors"
          id="quick-search-input"
        />
      </div>

      {/* Category Pills Strip */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                setDraftedTranslation(null);
                setTranslationError("");
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-full text-xs font-semibold shrink-0 border transition-all ${
                selectedCategory === cat.id
                  ? "bg-cyan-500 border-cyan-400 text-black shadow-[0_0_10px_rgba(6,182,212,0.2)]"
                  : "bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
              id={`cat-pill-${cat.id}`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Questions list */}
      <div className="space-y-4">
        {filteredQuestions.length === 0 ? (
          <div className="bg-slate-900/40 border border-slate-800/80 rounded-2xl p-8 text-center text-slate-500 text-xs">
            No matching grounded stadium answers found. Try general keywords like "gluten", "escort", "clear bag".
          </div>
        ) : (
          filteredQuestions.map((item, idx) => (
            <div
              key={idx}
              className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-sm space-y-3 relative overflow-hidden"
              id={`qa-item-${idx}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-widest bg-cyan-950/40 border border-cyan-800/30 px-2 py-0.5 rounded-md">
                    {item.category.replace("_", " ")}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-1.5 leading-snug">{item.question}</h3>
                </div>
                <span className="text-[10px] text-slate-500 font-medium whitespace-nowrap mt-1">Ref: {item.groundingRef}</span>
              </div>

              <p className="text-slate-300 text-xs leading-relaxed pl-3 border-l-2 border-slate-800">{item.answer}</p>

              {/* Action row to translate instantly */}
              <div className="flex items-center justify-between pt-2 mt-2 border-t border-slate-800/60">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase">Translate Answer:</span>
                  <div className="flex rounded-md overflow-hidden bg-slate-950 border border-slate-800">
                    {(["es", "pt", "fr"] as const).map((lang) => (
                      <button
                        key={lang}
                        onClick={() => setTranslationLanguage(lang)}
                        className={`px-2 py-0.5 text-[10px] font-bold uppercase transition-colors ${
                          translationLanguage === lang
                            ? "bg-cyan-950 text-cyan-400 border-r border-slate-800 last:border-0"
                            : "text-slate-500 hover:text-slate-300 border-r border-slate-800 last:border-0"
                        }`}
                        id={`qa-lang-${idx}-${lang}`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => handleDraftTranslation(item.answer)}
                  disabled={activeTranslatingItem === item.answer}
                  className="flex items-center gap-1.5 text-[11px] font-bold text-cyan-400 hover:text-cyan-300 transition-colors disabled:opacity-50 cursor-pointer"
                  id={`qa-translate-btn-${idx}`}
                >
                  {activeTranslatingItem === item.answer ? (
                    <>
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      <span>Drafting...</span>
                    </>
                  ) : (
                    <>
                      <Globe className="w-3 h-3" />
                      <span>Draft translated script</span>
                    </>
                  )}
                </button>
              </div>

              {/* If translation output is available for this item */}
              {draftedTranslation && activeTranslatingItem === null && (
                <AnimatePresence>
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mt-3 bg-cyan-950/10 border border-cyan-800/40 rounded-xl p-3 space-y-2.5"
                    id={`qa-translation-box-${idx}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1">
                        <Globe className="w-3.5 h-3.5" />
                        Scripted {translationLanguage === "es" ? "Spanish" : translationLanguage === "pt" ? "Portuguese" : "French"} Translation
                      </span>
                      <button 
                        onClick={() => setDraftedTranslation(null)}
                        className="text-[10px] text-slate-500 hover:text-slate-300"
                        id="close-qa-translation-btn"
                      >
                        Clear
                      </button>
                    </div>

                    <div className="space-y-1.5">
                      <p className="text-xs font-semibold text-slate-200 leading-normal bg-slate-950/40 p-2.5 rounded-lg border border-slate-900 font-display italic">
                        "{draftedTranslation.fanResponse}"
                      </p>
                      
                      <div className="p-2.5 bg-slate-950/60 rounded-lg border border-slate-900/50 space-y-0.5">
                        <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block">Phonetic Speaking Guide:</span>
                        <p className="text-xs font-medium text-cyan-300/90 font-mono">
                          {draftedTranslation.phoneticSpelling}
                        </p>
                      </div>

                      {/* Show to Fan triggering for FAQs */}
                      <button
                        onClick={() => setShowToFanMode(true)}
                        className="w-full flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-cyan-500 text-black font-extrabold font-display text-xs cursor-pointer hover:bg-cyan-400 transition-colors"
                        id="faq-show-to-fan-btn"
                      >
                        <ArrowUpDown className="w-3.5 h-3.5" />
                        <span>Show to Fan (Big Glare Card)</span>
                      </button>
                    </div>
                  </motion.div>
                </AnimatePresence>
              )}

              {translationError && (
                <div className="bg-red-950/30 border border-red-900/40 text-red-400 text-[11px] p-2 rounded-xl mt-2">
                  {translationError}
                </div>
              )}
            </div>
          ))
        )}
      </div>

      <ShowToFanModal
        isOpen={showToFanMode}
        onClose={() => setShowToFanMode(false)}
        text={draftedTranslation?.fanResponse || ""}
        languageName={
          translationLanguage === "es"
            ? "Español"
            : translationLanguage === "pt"
            ? "Português"
            : "Français"
        }
        onSpeak={draftedTranslation ? () => handleSpeakAloud(draftedTranslation.fanResponse) : undefined}
      />
    </div>
  );
}
