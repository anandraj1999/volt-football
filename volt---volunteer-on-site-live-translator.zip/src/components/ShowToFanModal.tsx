import React from "react";
import { X, Volume2, Globe, ShieldCheck, CornerDownLeft } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ShowToFanModalProps {
  isOpen: boolean;
  onClose: () => void;
  text: string;
  languageName: string;
  onSpeak?: () => void;
}

export default function ShowToFanModal({
  isOpen,
  onClose,
  text,
  languageName,
  onSpeak,
}: ShowToFanModalProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          className="fixed inset-0 bg-white z-50 flex flex-col justify-between overflow-y-auto"
          id="show-to-fan-overlay-modal"
          style={{ colorScheme: "light" }} // Enforce light color scheme
        >
          {/* HIGH-CONTRAST TOP ACTIONS STATUS BAR */}
          <div className="bg-neutral-100 border-b-4 border-black px-6 py-4 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-3">
              <Globe className="w-6 h-6 text-black shrink-0" />
              <div>
                <span className="text-[11px] font-black uppercase tracking-widest text-neutral-600 block leading-none">
                  FIFA World Cup 2026 Volunteer Help
                </span>
                <span className="text-sm font-black text-black uppercase tracking-wider">
                  Translation to: <span className="underline decoration-2">{languageName}</span>
                </span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="flex items-center gap-1 bg-black text-white hover:bg-neutral-800 px-4 py-2.5 rounded-xl font-black text-xs uppercase border-2 border-black transition-colors cursor-pointer"
              id="show-to-fan-close-btn-top"
              aria-label="Exit Translation Screen"
            >
              <X className="w-4 h-4" />
              <span>Close</span>
            </button>
          </div>

          {/* ULTRA READABLE GIANT VIEWPORT */}
          <div className="flex-1 flex flex-col justify-center px-6 py-8 md:px-12 max-w-3xl mx-auto w-full text-center space-y-8">
            {/* Header Hint for Fan */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 bg-black text-white px-3 py-1.5 rounded-full text-xs font-black uppercase tracking-wider">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Verified Stadium Information</span>
              </div>
              <p className="text-xs font-bold text-neutral-600 uppercase tracking-widest">
                Please Read the directions below
              </p>
            </div>

            {/* Giant Sunlight-Readable Typography Container */}
            <div className="bg-white border-8 border-black p-6 sm:p-10 rounded-[2.5rem] shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] text-left relative min-h-[220px] flex flex-col justify-between">
              {onSpeak && (
                <button
                  onClick={onSpeak}
                  className="absolute right-6 top-6 p-4 rounded-full bg-black text-white hover:bg-neutral-800 transition-colors cursor-pointer shadow-lg"
                  title="Listen to translation"
                  id="show-to-fan-tts-btn"
                >
                  <Volume2 className="w-7 h-7" />
                </button>
              )}

              <p 
                className="text-3xl sm:text-5xl font-black text-black leading-tight tracking-tight font-sans pr-12 break-words pt-4 pb-6"
                id="show-to-fan-text-content"
              >
                "{text}"
              </p>

              <div className="border-t-4 border-black pt-4 flex items-center justify-between text-[11px] font-black uppercase tracking-wider text-neutral-700">
                <span>Gate, Corridor, and Queue Info Grounded Live</span>
                {onSpeak && (
                  <button 
                    onClick={onSpeak}
                    className="text-black hover:underline flex items-center gap-1 text-[11px] font-black"
                  >
                    <span>Tap speaker to listen</span>
                  </button>
                )}
              </div>
            </div>

            {/* Language-specific return instructions */}
            <div className="bg-neutral-100 border-2 border-black rounded-2xl p-4 flex items-center gap-3 text-left">
              <CornerDownLeft className="w-6 h-6 text-black shrink-0 animate-bounce" />
              <div>
                <p className="text-xs font-black text-black uppercase tracking-wide">
                  Instructions for the Fan:
                </p>
                <p className="text-xs text-neutral-700 font-bold">
                  After reading, please hand this device back to the World Cup Volunteer. Thank you!
                </p>
              </div>
            </div>
          </div>

          {/* MASSIVE TAP TARGET AT THE BOTTOM */}
          <div className="p-6 bg-neutral-100 border-t-4 border-black shrink-0">
            <button
              onClick={onClose}
              className="w-full py-5 bg-black hover:bg-neutral-800 text-white font-black uppercase text-lg sm:text-xl tracking-widest rounded-2xl border-4 border-black transition-all cursor-pointer shadow-[6px_6px_0px_0px_rgba(163,163,163,1)] flex items-center justify-center gap-2"
              id="show-to-fan-close-btn-bottom"
            >
              <span>Done • Return to App</span>
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
