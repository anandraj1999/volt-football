import React from "react";
import { motion } from "motion/react";
// @ts-ignore
import kickerLogo from "../assets/images/kicking_footballer_logo_1784195731129.jpg";

export default function AnimatedFootballerLogo() {
  return (
    <div className="relative w-11 h-11 flex items-center justify-center select-none" id="animated-footballer-logo-container">
      {/* External rotating cyberpunk ring */}
      <motion.div
        className="absolute inset-0 rounded-full border border-cyan-500/40 border-dashed"
        animate={{ rotate: 360 }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
      />
      
      {/* Outer pulsing glow */}
      <motion.div
        className="absolute inset-0.5 rounded-full bg-cyan-500/20 filter blur-sm"
        animate={{
          scale: [1, 1.15, 1],
          opacity: [0.5, 0.8, 0.5],
        }}
        transition={{
          duration: 2.5,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      />

      {/* Main interactive circular logo container */}
      <motion.div
        className="relative w-9 h-9 rounded-full overflow-hidden border-2 border-cyan-400 bg-slate-950 shadow-[0_0_12px_rgba(6,182,212,0.5)] z-10 flex items-center justify-center"
        whileHover={{ scale: 1.12 }}
        whileTap={{ scale: 0.92 }}
        animate={{
          y: [-1, 1, -1],
        }}
        transition={{
          duration: 2,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        {/* Real Kicking Footballer Generated Image */}
        <img
          src={kickerLogo}
          alt="Kicking Footballer Logo"
          className="w-full h-full object-cover scale-110 filter brightness-110 contrast-105"
          referrerPolicy="no-referrer"
        />

        {/* Shimmer overlay effect */}
        <motion.div
          className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -translate-x-full"
          animate={{
            translateX: ["100%", "-100%"],
          }}
          transition={{
            duration: 2.8,
            repeat: Infinity,
            ease: "easeInOut",
          }}
        />
      </motion.div>

      {/* Mini orbiting glowing soccer ball indicator */}
      <motion.div
        className="absolute w-2.5 h-2.5 bg-white rounded-full border border-slate-950 shadow-[0_0_8px_rgba(6,182,212,1)] z-20"
        animate={{
          rotate: [0, 360],
          x: [18 * Math.cos(0), 18 * Math.cos(2 * Math.PI)],
          y: [18 * Math.sin(0), 18 * Math.sin(2 * Math.PI)],
        }}
        style={{
          transformOrigin: "center",
        }}
        transition={{
          rotate: { duration: 4, repeat: Infinity, ease: "linear" },
          x: { duration: 4, repeat: Infinity, ease: "linear" },
          y: { duration: 4, repeat: Infinity, ease: "linear" },
        }}
      >
        <div className="w-full h-full rounded-full bg-gradient-to-tr from-cyan-400 to-white" />
      </motion.div>
    </div>
  );
}
