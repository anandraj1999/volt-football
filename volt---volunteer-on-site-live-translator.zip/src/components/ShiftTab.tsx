import React, { useState, useEffect } from "react";
import { STADIUM_DATA } from "../stadiumData";
import { VolunteerShift } from "../types";
import { Shield, Clock, Phone, MapPin, Compass, AlertCircle, RefreshCw, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const INITIAL_SHIFT: VolunteerShift = {
  volunteerName: "Alex Mercer",
  role: "Stadium Gate Operations & Fan Mobility Assistant",
  assignedZone: "Zone 100 West (Verizon Plaza)",
  assignedGate: "Gate A (Verizon Gate)",
  shiftStart: "14:00 (2:00 PM)",
  shiftEnd: "22:00 (10:00 PM)",
  supervisorName: "Captain Samantha Rodriguez",
  supervisorContact: "+1 (201) 555-0199"
};

const SHIFT_TIPS = [
  {
    title: "Sensory Room Access",
    text: "The main Stadium Sensory Relief Suite is located near Section 117A on the lower level. Quiet bags can also be checked out there."
  },
  {
    title: "Medication Cold Storage",
    text: "First Aid Station 4 (Section 117) offers refrigeration units for fans who need to store temperature-sensitive medication during the match."
  },
  {
    title: "Diaper Bag Security Exception",
    text: "While we enforce the Clear Bag Policy strictly, medical and diaper bags are allowed. Send them to Verizon Gate A or Pepsi Gate C for x-ray check."
  },
  {
    title: "Re-Entry Protocol",
    text: "Re-entry is strictly prohibited. If a fan exits, their digital ticket is permanently deactivated. No exceptions unless authorized by Samantha."
  },
  {
    title: "Wheelchair Assistance Pick-up",
    text: "Our stadium golf-carts stop at Gate G (Amex Gate) every 3 minutes to carry mobility-impaired fans to the outer parking structures."
  }
];

export default function ShiftTab() {
  const [shift, setShift] = useState<VolunteerShift>(INITIAL_SHIFT);
  const [tipIndex, setTipIndex] = useState(0);
  const [isEditingSupervisor, setIsEditingSupervisor] = useState(false);
  const [tempSupervisorName, setTempSupervisorName] = useState(shift.supervisorName);
  const [tempSupervisorContact, setTempSupervisorContact] = useState(shift.supervisorContact);

  // Auto rotate tips every 15 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setTipIndex((prev) => (prev + 1) % SHIFT_TIPS.length);
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  const handleSaveSupervisor = () => {
    setShift(prev => ({
      ...prev,
      supervisorName: tempSupervisorName,
      supervisorContact: tempSupervisorContact
    }));
    setIsEditingSupervisor(false);
  };

  // Find assigned gate details from database to ground real data
  const gateDetails = STADIUM_DATA.gates.find(g => g.name.toLowerCase().includes(shift.assignedGate.toLowerCase()) || g.id === "A");

  return (
    <div className="space-y-6" id="shift-tab-container">
      {/* Header Profile */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md relative overflow-hidden">
        {/* Background glow */}
        <div className="absolute top-0 right-0 w-36 h-36 bg-cyan-500/10 rounded-full filter blur-3xl -z-10" />
        
        <div className="flex items-start justify-between">
          <div>
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-950 text-cyan-400 border border-cyan-800/60 mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse" />
              On Duty • FIFA World Cup 2026
            </span>
            <h2 className="text-2xl font-bold font-display text-white tracking-tight">{shift.volunteerName}</h2>
            <p className="text-slate-400 text-sm mt-0.5">{shift.role}</p>
          </div>
          <div className="w-12 h-12 rounded-full bg-slate-800 border border-slate-700 flex items-center justify-center font-bold text-lg text-cyan-400 font-display">
            AM
          </div>
        </div>
      </div>

      {/* Shift Time and Location Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Assigned post */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md flex gap-4">
          <div className="w-11 h-11 rounded-xl bg-cyan-950/80 border border-cyan-800/50 flex items-center justify-center text-cyan-400 shrink-0">
            <MapPin className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Assigned Gate & Zone</span>
            <h3 className="font-semibold text-slate-200">{shift.assignedGate}</h3>
            <p className="text-slate-400 text-xs">{shift.assignedZone}</p>
            {gateDetails && (
              <div className="mt-3 pt-2.5 border-t border-slate-800/80 space-y-1">
                <div className="flex items-center gap-1.5 text-xs text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Current Wait: <strong>{gateDetails.waitMinutes} mins</strong></span>
                </div>
                <p className="text-[11px] text-slate-500 leading-normal">{gateDetails.accessibilityNotes}</p>
              </div>
            )}
          </div>
        </div>

        {/* Shift hours */}
        <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md flex gap-4">
          <div className="w-11 h-11 rounded-xl bg-magenta-950/30 border border-pink-900/40 flex items-center justify-center text-pink-400 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Active Shift Hours</span>
            <h3 className="font-semibold text-slate-200">{shift.shiftStart} – {shift.shiftEnd}</h3>
            <p className="text-slate-400 text-xs">Today's Match: USA vs. England (Group Stage)</p>
            <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center gap-1.5 text-xs text-slate-400">
              <Compass className="w-3.5 h-3.5 text-pink-400" />
              <span>Report to Verizon Gate Plaza by 13:45</span>
            </div>
          </div>
        </div>
      </div>

      {/* Rotating Did you know / Tactical safety tip */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-2 text-cyan-500/20">
          <Sparkles className="w-10 h-10" />
        </div>
        <div className="flex items-start gap-3">
          <div className="w-8 h-8 rounded-lg bg-cyan-950/60 border border-cyan-800/50 flex items-center justify-center text-cyan-400 shrink-0 mt-0.5">
            <Shield className="w-4 h-4" />
          </div>
          <div className="space-y-1.5 flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-cyan-400 tracking-wider uppercase">Zone A Tactical Tip</span>
              <button 
                onClick={() => setTipIndex((prev) => (prev + 1) % SHIFT_TIPS.length)}
                className="text-slate-500 hover:text-cyan-400 p-1 rounded-md hover:bg-slate-900 transition-colors"
                title="Next Tip"
                id="next-tip-btn"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
            
            <div className="relative min-h-[4rem]">
              <AnimatePresence mode="wait">
                <motion.div
                  key={tipIndex}
                  initial={{ opacity: 0, x: 10 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -10 }}
                  transition={{ duration: 0.2 }}
                  className="space-y-1 absolute inset-0"
                >
                  <h4 className="text-sm font-semibold text-slate-200">{SHIFT_TIPS[tipIndex].title}</h4>
                  <p className="text-slate-400 text-xs leading-relaxed">{SHIFT_TIPS[tipIndex].text}</p>
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>

      {/* Supervisor and Emergency Escapes */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-pink-500" />
            <h3 className="font-semibold text-slate-200 font-display">Supervisor Contact</h3>
          </div>
          <button 
            onClick={() => {
              if (isEditingSupervisor) {
                handleSaveSupervisor();
              } else {
                setTempSupervisorName(shift.supervisorName);
                setTempSupervisorContact(shift.supervisorContact);
                setIsEditingSupervisor(true);
              }
            }}
            className="text-xs font-medium text-cyan-400 hover:text-cyan-300 px-2.5 py-1 rounded-md hover:bg-slate-800 transition-colors"
            id="edit-supervisor-btn"
          >
            {isEditingSupervisor ? "Save" : "Change Supervisor"}
          </button>
        </div>

        {isEditingSupervisor ? (
          <div className="space-y-3 pt-1">
            <div>
              <label className="block text-slate-500 text-[11px] font-semibold uppercase tracking-wider mb-1">Supervisor Name</label>
              <input
                type="text"
                value={tempSupervisorName}
                onChange={(e) => setTempSupervisorName(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2 text-sm text-slate-200"
                id="supervisor-name-input"
              />
            </div>
            <div>
              <label className="block text-slate-500 text-[11px] font-semibold uppercase tracking-wider mb-1">Supervisor Phone</label>
              <input
                type="text"
                value={tempSupervisorContact}
                onChange={(e) => setTempSupervisorContact(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3 py-2 text-sm text-slate-200"
                id="supervisor-phone-input"
              />
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-between">
            <div className="space-y-1">
              <h4 className="text-sm font-semibold text-slate-300">{shift.supervisorName}</h4>
              <p className="text-slate-500 text-xs">Section Commander (West Quad)</p>
            </div>
            <a 
              href={`tel:${shift.supervisorContact}`} 
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-slate-200 hover:text-white transition-all text-xs font-semibold"
              id="call-supervisor-link"
            >
              <Phone className="w-3.5 h-3.5 text-cyan-400" />
              <span>Call Samantha</span>
            </a>
          </div>
        )}

        <div className="bg-red-950/20 border border-red-900/40 rounded-xl p-3.5 flex gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-red-400 uppercase tracking-wider">In Case of Evacuation</h4>
            <p className="text-[11px] text-slate-400 leading-normal">
              Direct all Zone A/Verizon Plaza crowds south-west towards Lot G. Clear emergency vehicles passage first. Do not use passenger elevators.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
