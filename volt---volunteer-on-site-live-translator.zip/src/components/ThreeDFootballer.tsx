import React, { useEffect, useRef, useState } from "react";
import { Play, Sparkles, RefreshCw, Zap } from "lucide-react";

type PlayMode = "dribble" | "juggle" | "shoot";
type SkinTheme = "cyber-cyan" | "neon-pink" | "hyper-gold";

export default function ThreeDFootballer() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [playMode, setPlayMode] = useState<PlayMode>("dribble");
  const [skinTheme, setSkinTheme] = useState<SkinTheme>("cyber-cyan");
  const [actionLabel, setActionLabel] = useState("AI AUTO-PLAY ACTIVE");
  const [kickIntensity, setKickIntensity] = useState(0);

  // Trigger specialized action
  const triggerBicycleKickRef = useRef<boolean>(false);
  const triggerPowerShotRef = useRef<boolean>(false);

  const handleBicycleKick = () => {
    triggerBicycleKickRef.current = true;
    setActionLabel("BICYCLE KICK EXECUTED!");
    setKickIntensity(100);
    setTimeout(() => {
      setActionLabel(playMode === "dribble" ? "DRIBBLE PRACTICE" : playMode === "juggle" ? "JUGGLING DRILL" : "SHOOTING MODE");
      setKickIntensity(0);
    }, 1500);
  };

  const handlePowerShot = () => {
    triggerPowerShotRef.current = true;
    setActionLabel("POWER VOLLEY TRIGGERED!");
    setKickIntensity(100);
    setTimeout(() => {
      setActionLabel(playMode === "dribble" ? "DRIBBLE PRACTICE" : playMode === "juggle" ? "JUGGLING DRILL" : "SHOOTING MODE");
      setKickIntensity(0);
    }, 1500);
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let time = 0;

    // Simulation settings & dimensions
    const width = 360;
    const height = 320;
    canvas.width = width;
    canvas.height = height;

    const groundY = height - 50;

    // Ball Physics Model
    let ball = {
      x: 180,
      y: 120,
      vx: 3,
      vy: 0,
      radius: 12,
      rotation: 0,
      gravity: 0.35,
      bounce: 0.78,
      friction: 0.985,
    };

    // Robot Kinematic Model
    let robot = {
      x: 130,
      y: groundY - 60, // Hip level
      targetX: 130,
      speed: 2.8,
      state: "idle", // idle, running, jumping, kick, flip
      flipAngle: 0,
      flipSpeed: 0,
      kickProgress: 0,
      colorMain: "#06b6d2",
      colorAccent: "#38bdf8",
    };

    // Particles for impact sparks
    interface Particle {
      x: number;
      y: number;
      vx: number;
      vy: number;
      life: number;
      maxLife: number;
      color: string;
      size: number;
    }
    let particles: Particle[] = [];

    const createSparks = (x: number, y: number, color: string, count = 12) => {
      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const speed = 1.5 + Math.random() * 4;
        particles.push({
          x,
          y,
          vx: Math.cos(angle) * speed,
          vy: Math.sin(angle) * speed,
          life: 1.0,
          maxLife: 20 + Math.random() * 30,
          color,
          size: 1.5 + Math.random() * 2,
        });
      }
    };

    // Setup target goal for shoot mode
    const goal = {
      x: width - 35,
      y: groundY - 100,
      w: 25,
      h: 100,
      targetY: groundY - 50,
      targetDir: 1,
    };

    // Theme color mapping
    const getColors = () => {
      switch (skinTheme) {
        case "neon-pink":
          return { main: "#ec4899", accent: "#f472b6", neon: "rgba(236,72,153,0.6)" };
        case "hyper-gold":
          return { main: "#eab308", accent: "#fde047", neon: "rgba(234,179,8,0.6)" };
        case "cyber-cyan":
        default:
          return { main: "#06b6d2", accent: "#22d3ee", neon: "rgba(6,182,210,0.6)" };
      }
    };

    const updatePhysics = () => {
      time += 0.05;
      const themeColors = getColors();

      // Determine behavior state based on playMode
      if (playMode === "dribble") {
        // Dribble practice: robot pursues ball back and forth
        // Keep within safe horizontal margins
        robot.targetX = ball.x - 22;
        if (robot.targetX < 40) robot.targetX = 40;
        if (robot.targetX > width - 110) robot.targetX = width - 110;

        // Move robot to target
        const dx = robot.targetX - robot.x;
        if (Math.abs(dx) > 4) {
          robot.x += Math.sign(dx) * robot.speed;
          robot.state = "running";
        } else {
          robot.state = "idle";
        }

        // Standard ball update with gravity
        ball.vy += ball.gravity;
        ball.x += ball.vx;
        ball.y += ball.vy;
        ball.rotation += ball.vx * 0.06;

        // Pitch Boundary Collisions (floor and walls)
        if (ball.y + ball.radius > groundY) {
          ball.y = groundY - ball.radius;
          ball.vy = -ball.vy * ball.bounce;
          ball.vx *= ball.friction;
        }
        if (ball.x - ball.radius < 20) {
          ball.x = ball.radius + 20;
          ball.vx = -ball.vx * ball.bounce;
        }
        if (ball.x + ball.radius > width - 20) {
          ball.x = width - 20 - ball.radius;
          ball.vx = -ball.vx * ball.bounce;
        }

        // Robot automatic dribble kick interaction
        const distToBallX = ball.x - (robot.x + 15);
        const distToBallY = ball.y - (robot.y + 40);
        const distance = Math.hypot(distToBallX, distToBallY);

        if (distance < 35 && ball.x > robot.x) {
          // Playful nudge or dynamic dribble touch
          ball.vx = 2.5 + Math.random() * 2.5;
          ball.vy = -(1.5 + Math.random() * 2.5);
          robot.kickProgress = 1.0; // Trigger visual leg swing
          createSparks(ball.x, ball.y, themeColors.main, 6);
        }
      }

      else if (playMode === "juggle") {
        // Juggling Drill: Robot stays near center, juggles with legs/head
        robot.targetX = 160;
        const dx = robot.targetX - robot.x;
        robot.x += dx * 0.1;
        robot.state = Math.abs(dx) > 10 ? "running" : "idle";

        ball.vy += ball.gravity * 0.8; // slightly floaty for awesome dynamic juggling
        ball.x += ball.vx;
        ball.y += ball.vy;
        ball.rotation += ball.vx * 0.04;

        // Bound to prevent ball escaping sides easily
        if (ball.x < 50) { ball.x = 50; ball.vx = -ball.vx; }
        if (ball.x > width - 50) { ball.x = width - 50; ball.vx = -ball.vx; }

        if (ball.y + ball.radius > groundY) {
          // If drops, auto kick it up slightly
          ball.y = groundY - ball.radius;
          ball.vy = -6;
          ball.vx = (Math.random() - 0.5) * 3;
        }

        // Collision with Robot's Juggling range (Hips/Foot zone)
        const rx = robot.x + 15;
        const distToRobotX = ball.x - rx;
        const distToFootY = ball.y - (robot.y + 45); // close to knee/foot height

        if (Math.abs(distToRobotX) < 32 && distToFootY > 0 && distToFootY < 25 && ball.vy > 0) {
          ball.vy = -(5.5 + Math.random() * 3);
          ball.vx = distToRobotX * 0.18 + (Math.random() - 0.5) * 1.5;
          robot.kickProgress = 1.0;
          createSparks(ball.x, ball.y, themeColors.accent, 8);
        }

        // Header collision
        const distToHeadY = ball.y - (robot.y - 25);
        if (Math.abs(distToRobotX) < 22 && Math.abs(distToHeadY) < 18 && ball.vy > 0) {
          ball.vy = -5;
          ball.vx = distToRobotX * 0.25;
          createSparks(ball.x, ball.y, "#ffffff", 5);
        }
      }

      else if (playMode === "shoot") {
        // Shooting training mode: Goal post on right
        // Robot runs to ball and shoots it towards the target
        robot.targetX = ball.x - 45;
        if (robot.targetX < 20) robot.targetX = 20;
        if (robot.targetX > width - 150) robot.targetX = width - 150;

        const dx = robot.targetX - robot.x;
        if (Math.abs(dx) > 5) {
          robot.x += Math.sign(dx) * robot.speed * 1.2;
          robot.state = "running";
        } else {
          robot.state = "idle";
        }

        // Move goal target
        goal.targetY += goal.targetDir * 1.2;
        if (goal.targetY > groundY - 15 || goal.targetY < groundY - 85) {
          goal.targetDir *= -1;
        }

        ball.vy += ball.gravity;
        ball.x += ball.vx;
        ball.y += ball.vy;
        ball.rotation += ball.vx * 0.05;

        // Bounce back from left wall
        if (ball.x - ball.radius < 20) {
          ball.x = 20 + ball.radius;
          ball.vx = Math.abs(ball.vx) * 0.8;
        }

        // Return the ball back to the center if it goes behind the goal
        if (ball.x > width + 40 || (ball.vx === 0 && ball.x > width - 100)) {
          ball.x = 40;
          ball.y = 100;
          ball.vx = 4;
          ball.vy = -2;
        }

        // Dynamic strike when robot reaches the ball
        const rx = robot.x + 15;
        const distToBallX = ball.x - rx;
        const distToBallY = ball.y - (robot.y + 40);

        if (distToBallX > 0 && distToBallX < 45 && Math.abs(distToBallY) < 40) {
          // Calculate vector towards goal target
          const targetX = goal.x;
          const targetY = goal.targetY;
          const angle = Math.atan2(targetY - ball.y, targetX - ball.x);
          const speed = 7.5 + Math.random() * 4;

          ball.vx = Math.cos(angle) * speed;
          ball.vy = Math.sin(angle) * speed;
          robot.kickProgress = 1.0;
          createSparks(ball.x, ball.y, themeColors.main, 14);
        }

        // Goal Post target hit validation
        if (ball.x + ball.radius >= goal.x && ball.x - ball.radius <= goal.x + goal.w) {
          if (ball.y >= groundY - 100 && ball.y <= groundY) {
            // Check if hit virtual flashing target point
            const distToTarget = Math.abs(ball.y - goal.targetY);
            if (distToTarget < 22) {
              createSparks(goal.x, goal.targetY, "#eab308", 25); // Gold explosion!
              // Deflect ball high in celebration
              ball.vx = -4 - Math.random() * 3;
              ball.vy = -6 - Math.random() * 4;
              setActionLabel("🚀 TARGET HIT! GOOOOOAL!");
              setTimeout(() => {
                setActionLabel("SHOOTING MODE");
              }, 1200);
            } else {
              // Standard goal net collision
              ball.vx = -ball.vx * 0.4;
              createSparks(ball.x, ball.y, "#ffffff", 6);
            }
          }
        }

        // Ground check
        if (ball.y + ball.radius > groundY) {
          ball.y = groundY - ball.radius;
          ball.vy = -ball.vy * ball.bounce;
          ball.vx *= ball.friction;
        }
      }

      // Handle Manual Trigger: POWER VOLLEY
      if (triggerPowerShotRef.current) {
        triggerPowerShotRef.current = false;
        // Lift ball in front of robot and blast it
        ball.x = robot.x + 40;
        ball.y = robot.y + 10;
        ball.vx = 12;
        ball.vy = -4;
        robot.kickProgress = 1.0;
        createSparks(ball.x, ball.y, "#f43f5e", 20);
      }

      // Handle Manual Trigger: BICYCLE KICK
      if (triggerBicycleKickRef.current) {
        triggerBicycleKickRef.current = false;
        robot.state = "flip";
        robot.flipAngle = 0;
        robot.flipSpeed = 0.28; // rapid 360 rotation speed

        // Pop ball up perfectly so robot strikes it mid air
        ball.x = robot.x + 15;
        ball.y = robot.y - 30;
        ball.vy = -8;
        ball.vx = 6;
        
        createSparks(robot.x + 15, robot.y - 20, themeColors.accent, 12);
      }

      // Handle robot rotation during bicycle flips
      if (robot.state === "flip") {
        robot.flipAngle += robot.flipSpeed;
        // Trigger impact strike at highest point of flip (around Pi radians / 180 deg)
        if (robot.flipAngle >= Math.PI && robot.flipAngle - robot.flipSpeed < Math.PI) {
          ball.vx = 9.5;
          ball.vy = -3;
          ball.y = robot.y - 40;
          createSparks(ball.x, ball.y, "#ffffff", 25);
          createSparks(ball.x, ball.y, themeColors.main, 15);
        }

        if (robot.flipAngle >= Math.PI * 2) {
          robot.state = "idle";
          robot.flipAngle = 0;
          robot.flipSpeed = 0;
        }
      }

      // Decay leg kick swing transition back to 0
      if (robot.kickProgress > 0) {
        robot.kickProgress -= 0.12;
      }

      // Update particle lifetimes
      particles = particles.filter(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.life -= 1 / p.maxLife;
        return p.life > 0;
      });
    };

    const draw = () => {
      if (!ctx) return;
      ctx.clearRect(0, 0, width, height);
      const themeColors = getColors();

      // Draw futuristic pitch background lines
      ctx.strokeStyle = "rgba(15, 23, 42, 0.6)";
      ctx.lineWidth = 1;
      // Grid mesh lines to represent 3D depth
      for (let i = 0; i < width; i += 30) {
        ctx.beginPath();
        ctx.moveTo(i, groundY);
        ctx.lineTo(i + (i - width / 2) * 0.4, height);
        ctx.stroke();
      }

      // Draw real grass/stadium boundary floor line
      ctx.strokeStyle = "rgba(6,182,212,0.15)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, groundY);
      ctx.lineTo(width, groundY);
      ctx.stroke();

      // Pitch glowing center circle lines
      ctx.strokeStyle = "rgba(6,182,212,0.06)";
      ctx.beginPath();
      ctx.ellipse(width / 2, groundY + 15, 80, 20, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Draw Goal Post Net in Shoot Mode
      if (playMode === "shoot") {
        // Neon Goal Frame
        ctx.strokeStyle = "rgba(71, 85, 105, 0.5)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(goal.x, groundY);
        ctx.lineTo(goal.x, groundY - 100);
        ctx.lineTo(goal.x + goal.w, groundY - 100);
        ctx.lineTo(goal.x + goal.w, groundY);
        ctx.stroke();

        // Goal Net Grid Mesh
        ctx.strokeStyle = "rgba(71, 85, 105, 0.2)";
        ctx.lineWidth = 1;
        for (let ny = groundY - 100; ny < groundY; ny += 10) {
          ctx.beginPath();
          ctx.moveTo(goal.x, ny);
          ctx.lineTo(goal.x + goal.w, ny);
          ctx.stroke();
        }
        for (let nx = goal.x; nx < goal.x + goal.w; nx += 10) {
          ctx.beginPath();
          ctx.moveTo(nx, groundY - 100);
          ctx.lineTo(nx, groundY);
          ctx.stroke();
        }

        // Glowing Target point inside goal
        const targetGlow = ctx.createRadialGradient(goal.x, goal.targetY, 2, goal.x, goal.targetY, 15);
        targetGlow.addColorStop(0, "#eab308");
        targetGlow.addColorStop(0.5, "rgba(234,179,8,0.4)");
        targetGlow.addColorStop(1, "rgba(234,179,8,0)");
        ctx.fillStyle = targetGlow;
        ctx.beginPath();
        ctx.arc(goal.x, goal.targetY, 15, 0, Math.PI * 2);
        ctx.fill();

        // Target center bullseye
        ctx.fillStyle = "#ffffff";
        ctx.beginPath();
        ctx.arc(goal.x, goal.targetY, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#eab308";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(goal.x, goal.targetY, 8, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Render Particles
      particles.forEach(p => {
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1.0; // Reset alpha

      // Draw Ball Shadow on pitch
      const shadowSize = Math.max(4, ball.radius * (1 - (groundY - ball.y) / 180));
      const shadowOpacity = Math.max(0.1, 0.65 - (groundY - ball.y) / 200);
      ctx.fillStyle = `rgba(0, 0, 0, ${shadowOpacity})`;
      ctx.beginPath();
      ctx.ellipse(ball.x, groundY + 4, shadowSize * 1.5, shadowSize * 0.4, 0, 0, Math.PI * 2);
      ctx.fill();

      // Draw Robot Shadow on pitch
      const robShadowSize = 22;
      ctx.fillStyle = "rgba(0, 0, 0, 0.45)";
      ctx.beginPath();
      ctx.ellipse(robot.x + 10, groundY + 4, robShadowSize, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      // Draw 3D ROBOT FOOTBALLER via procedural segments
      ctx.save();
      
      // Move origin to robot body center for proper flips
      const rx = robot.x + 15;
      const ry = robot.y + 25; // center of gravity
      ctx.translate(rx, ry);
      if (robot.state === "flip") {
        ctx.rotate(-robot.flipAngle); // Do backward somersault flip animation
      }

      // Calculate Running swing factors
      const swing = robot.state === "running" ? Math.sin(time * 8) : 0;
      const swingLegLeft = swing * 25;
      const swingLegRight = -swing * 25;
      const swingArmLeft = -swing * 30;
      const swingArmRight = swing * 30;

      // Draw robotic joints
      // --- BACK ARM ---
      ctx.strokeStyle = "rgba(71, 85, 105, 0.8)";
      ctx.lineWidth = 4;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-5, -15); // shoulder
      const armBackX = -12 + Math.sin(time * 5) * 8 + swingArmLeft * 0.5;
      const armBackY = -5 + Math.cos(time * 5) * 4;
      ctx.lineTo(armBackX, armBackY); // elbow
      ctx.lineTo(armBackX + 5, armBackY + 12); // hand
      ctx.stroke();

      // --- BACK LEG ---
      ctx.strokeStyle = "rgba(30, 41, 59, 0.9)";
      ctx.lineWidth = 5.5;
      ctx.beginPath();
      ctx.moveTo(-5, 10); // hip
      const kneeBackX = -10 + swingLegLeft * 0.4;
      const kneeBackY = 25 + (swing > 0 ? swing * 6 : 0);
      ctx.lineTo(kneeBackX, kneeBackY); // knee
      ctx.lineTo(kneeBackX + (swingLegLeft > 0 ? 8 : -3), kneeBackY + 16); // foot
      ctx.stroke();

      // --- TORSO CORE (Metallic Cyber armor plate) ---
      const gradientTorso = ctx.createLinearGradient(-15, -25, 15, 15);
      gradientTorso.addColorStop(0, "#0f172a");
      gradientTorso.addColorStop(0.5, "#1e293b");
      gradientTorso.addColorStop(1, "#334155");
      ctx.fillStyle = gradientTorso;
      ctx.strokeStyle = themeColors.main;
      ctx.lineWidth = 2;
      
      ctx.beginPath();
      ctx.roundRect(-12, -22, 24, 34, [8, 8, 4, 4]);
      ctx.fill();
      ctx.stroke();

      // Glowing Power Core Badge on chest
      ctx.fillStyle = themeColors.accent;
      ctx.shadowColor = themeColors.accent;
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(-4, -12);
      ctx.lineTo(4, -12);
      ctx.lineTo(6, -6);
      ctx.lineTo(0, 2);
      ctx.lineTo(-6, -6);
      ctx.closePath();
      ctx.fill();
      ctx.shadowBlur = 0; // reset

      // --- CYBER VISOR HEAD ---
      ctx.fillStyle = "#1e293b";
      ctx.strokeStyle = "#475569";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, -32, 10, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Head Antenna
      ctx.strokeStyle = "#475569";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -42);
      ctx.lineTo(3, -48);
      ctx.stroke();
      ctx.fillStyle = themeColors.main;
      ctx.beginPath();
      ctx.arc(3, -48, 2, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Neon Visor bar
      ctx.strokeStyle = themeColors.main;
      ctx.shadowColor = themeColors.main;
      ctx.shadowBlur = 8;
      ctx.lineWidth = 3;
      ctx.beginPath();
      // Look towards soccer ball direction
      const lookDir = ball.x > (robot.x + 15) ? 1 : -1;
      ctx.moveTo(lookDir * 1, -34);
      ctx.lineTo(lookDir * 8, -34);
      ctx.stroke();
      ctx.shadowBlur = 0; // reset

      // --- FORE ARM ---
      ctx.strokeStyle = themeColors.main;
      ctx.lineWidth = 4.5;
      ctx.beginPath();
      ctx.moveTo(5, -15); // shoulder
      const armForeX = 12 + swingArmRight * 0.4;
      const armForeY = -3 + swingArmRight * 0.2;
      ctx.lineTo(armForeX, armForeY); // elbow
      ctx.lineTo(armForeX + 8, armForeY + 10); // cyber hand
      ctx.stroke();

      // --- FORE LEG (Kicking Leg) ---
      // Swing further if in kick animation
      const kickSwing = robot.kickProgress * 42;
      ctx.strokeStyle = themeColors.accent;
      ctx.lineWidth = 6;
      ctx.beginPath();
      ctx.moveTo(5, 10); // Hip joint

      // Knee kinematics
      const kneeForeX = 10 + swingLegRight * 0.4 + kickSwing * 0.8;
      const kneeForeY = 25 - kickSwing * 0.4;
      ctx.lineTo(kneeForeX, kneeForeY);

      // Foot joint
      const footForeX = kneeForeX + 6 + (swingLegRight > 0 ? 5 : -4) + kickSwing * 0.6;
      const footForeY = kneeForeY + 16 - kickSwing * 0.5;
      ctx.lineTo(footForeX, footForeY);
      ctx.stroke();

      // Cyber Glowing Cleat/Boot
      ctx.fillStyle = themeColors.main;
      ctx.shadowColor = themeColors.main;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(footForeX, footForeY, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.restore(); // Restore transform grid

      // Draw real football / Soccer Ball with spinning texture
      ctx.save();
      ctx.translate(ball.x, ball.y);
      ctx.rotate(ball.rotation);

      // Outer glow and base color
      ctx.fillStyle = "#ffffff";
      ctx.strokeStyle = "#0f172a";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Classic Soccer pentagons / hex segments drawn inside the ball
      ctx.fillStyle = "rgba(15, 23, 42, 0.85)";
      ctx.strokeStyle = "rgba(15, 23, 42, 0.4)";
      ctx.lineWidth = 1;

      // Center pentagon
      ctx.beginPath();
      for (let j = 0; j < 5; j++) {
        const angle = (j * Math.PI * 2) / 5 - Math.PI / 2;
        const px = Math.cos(angle) * (ball.radius * 0.45);
        const py = Math.sin(angle) * (ball.radius * 0.45);
        if (j === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.closePath();
      ctx.fill();

      // Pentagonal spoke seams radiating outwards to create the 3D sphere look
      for (let j = 0; j < 5; j++) {
        const angle = (j * Math.PI * 2) / 5 - Math.PI / 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(angle) * (ball.radius * 0.45), Math.sin(angle) * (ball.radius * 0.45));
        ctx.lineTo(Math.cos(angle) * ball.radius, Math.sin(angle) * ball.radius);
        ctx.stroke();
      }

      // Ball gloss highlight overlay
      const radialGloss = ctx.createRadialGradient(-3, -3, 2, 0, 0, ball.radius);
      radialGloss.addColorStop(0, "rgba(255, 255, 255, 0.6)");
      radialGloss.addColorStop(0.5, "rgba(255, 255, 255, 0.15)");
      radialGloss.addColorStop(1, "rgba(0, 0, 0, 0.45)");
      ctx.fillStyle = radialGloss;
      ctx.beginPath();
      ctx.arc(0, 0, ball.radius, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
    };

    const tick = () => {
      updatePhysics();
      draw();
      animationFrameId = requestAnimationFrame(tick);
    };

    tick();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [playMode, skinTheme]);

  return (
    <div className="w-full flex flex-col items-center select-none" id="robo-footballer-widget">
      
      {/* Dynamic Status Indicator */}
      <div className="w-full max-w-sm flex justify-between items-center px-4 py-2 bg-slate-950/80 border border-slate-800/80 rounded-t-2xl font-mono text-xs">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-slate-400 font-bold uppercase tracking-wider text-[10px]">
            {actionLabel}
          </span>
        </div>
        <div className="flex items-center gap-1.5 text-[9px] font-black text-cyan-400">
          <Zap className="w-3.5 h-3.5" />
          <span>ROBO-STRIKER V2.6</span>
        </div>
      </div>

      {/* Physics Interactive Canvas Viewport */}
      <div className="relative w-full max-w-sm bg-slate-950 border-x border-slate-800/80 p-0 overflow-hidden flex justify-center items-center">
        
        {/* Holographic grid target overlay background */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_40%,_black_95%)] pointer-events-none" />
        <div 
          className="absolute inset-0 bg-[linear-gradient(rgba(6,182,212,0.03)_1px,_transparent_1px),_linear-gradient(90deg,_rgba(6,182,212,0.03)_1px,_transparent_1px)] bg-[size:16px_16px] pointer-events-none"
        />

        <canvas 
          ref={canvasRef} 
          className="block w-full aspect-[360/320] cursor-pointer"
          title="Click to spark ball!"
        />

        {/* Floating action hint over canvas */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 pointer-events-none">
          <span className="text-[9px] bg-slate-900/90 border border-slate-800 text-slate-400 px-2.5 py-1 rounded-full font-bold uppercase tracking-widest flex items-center gap-1 shadow-lg">
            <Sparkles className="w-3 h-3 text-cyan-400 animate-bounce" />
            Use controls below to interact
          </span>
        </div>
      </div>

      {/* Control Console Portlet */}
      <div className="w-full max-w-sm bg-slate-900/80 border border-t-0 border-slate-800/80 rounded-b-2xl p-3.5 space-y-3.5">
        
        {/* Play drills selectors */}
        <div className="grid grid-cols-3 gap-1.5">
          <button
            onClick={() => {
              setPlayMode("dribble");
              setActionLabel("DRIBBLE PRACTICE");
            }}
            className={`py-2 px-1 rounded-xl font-bold font-mono text-[9px] uppercase tracking-wider transition-all cursor-pointer text-center ${
              playMode === "dribble"
                ? "bg-cyan-500 text-black shadow-[0_0_12px_rgba(6,182,212,0.4)]"
                : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white"
            }`}
          >
            🏃 Dribbling
          </button>
          
          <button
            onClick={() => {
              setPlayMode("juggle");
              setActionLabel("JUGGLING DRILL");
            }}
            className={`py-2 px-1 rounded-xl font-bold font-mono text-[9px] uppercase tracking-wider transition-all cursor-pointer text-center ${
              playMode === "juggle"
                ? "bg-cyan-500 text-black shadow-[0_0_12px_rgba(6,182,212,0.4)]"
                : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white"
            }`}
          >
            🤹 Juggling
          </button>

          <button
            onClick={() => {
              setPlayMode("shoot");
              setActionLabel("SHOOTING MODE");
            }}
            className={`py-2 px-1 rounded-xl font-bold font-mono text-[9px] uppercase tracking-wider transition-all cursor-pointer text-center ${
              playMode === "shoot"
                ? "bg-cyan-500 text-black shadow-[0_0_12px_rgba(6,182,212,0.4)]"
                : "bg-slate-950 text-slate-400 border border-slate-800 hover:text-white"
            }`}
          >
            🎯 Goal Shoot
          </button>
        </div>

        {/* Action Triggers Grid */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={handlePowerShot}
            className="py-2 px-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 font-bold text-xs uppercase tracking-wider hover:border-cyan-500/50 hover:text-cyan-400 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            id="power-volley-btn"
          >
            <Play className="w-3.5 h-3.5 fill-current text-cyan-400" />
            Power Volley
          </button>

          <button
            onClick={handleBicycleKick}
            className="py-2 px-3 rounded-xl bg-gradient-to-r from-pink-500/20 to-pink-500/10 border border-pink-500/30 text-pink-400 font-black text-xs uppercase tracking-wider hover:from-pink-500/30 hover:border-pink-500 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            id="bicycle-kick-btn"
          >
            <RefreshCw className="w-3.5 h-3.5 text-pink-400" />
            Bicycle Kick
          </button>
        </div>

        {/* Robo-Skins Theme Customizer */}
        <div className="flex items-center justify-between pt-1 text-[10px] font-mono text-slate-500">
          <span className="font-bold uppercase tracking-wider">Robot Chassis Finish:</span>
          <div className="flex gap-2">
            <button 
              onClick={() => setSkinTheme("cyber-cyan")}
              title="Cyan Finish"
              className={`w-4.5 h-4.5 rounded-full bg-cyan-500 border-2 transition-all cursor-pointer ${skinTheme === "cyber-cyan" ? "border-white scale-110 shadow-md" : "border-transparent"}`}
            />
            <button 
              onClick={() => setSkinTheme("neon-pink")}
              title="Pink Finish"
              className={`w-4.5 h-4.5 rounded-full bg-pink-500 border-2 transition-all cursor-pointer ${skinTheme === "neon-pink" ? "border-white scale-110 shadow-md" : "border-transparent"}`}
            />
            <button 
              onClick={() => setSkinTheme("hyper-gold")}
              title="Gold Finish"
              className={`w-4.5 h-4.5 rounded-full bg-yellow-400 border-2 transition-all cursor-pointer ${skinTheme === "hyper-gold" ? "border-white scale-110 shadow-md" : "border-transparent"}`}
            />
          </div>
        </div>

      </div>
    </div>
  );
}
