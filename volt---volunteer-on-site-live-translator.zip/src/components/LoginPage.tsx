import React, { useState } from "react";
import { ShieldCheck, User, Key, ArrowRight, HelpCircle, Sparkles, ChevronRight, Trophy, Sparkle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
// @ts-ignore
import legendsCollage from "../assets/images/football_legends_collage_1784195194243.jpg";
import AnimatedFootballerLogo from "./AnimatedFootballerLogo";

interface LoginPageProps {
  onLoginSuccess: (volunteerName: string) => void;
}

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [volId, setVolId] = useState("");
  const [passcode, setPasscode] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!volId.trim()) {
      setErrorMsg("Please enter your Volunteer Badge ID.");
      return;
    }
    if (passcode !== "2026" && passcode !== "FIFA2026") {
      setErrorMsg("Invalid Tactical Passcode. (Try using: 2026)");
      return;
    }

    setErrorMsg("");
    setIsSubmitting(true);
    
    // Simulate tactical login verification delay
    setTimeout(() => {
      setIsSubmitting(false);
      onLoginSuccess(volId.trim().toUpperCase());
    }, 1200);
  };

  const handleInstantBypass = () => {
    onLoginSuccess("VOLUNTEER CHRIS");
  };

  return (
    <div className="min-h-screen w-full flex flex-col justify-center items-center px-4 py-12 relative overflow-hidden" id="login-page-container">
      {/* Background ambient lighting */}
      <div className="absolute top-10 left-10 w-[450px] h-[450px] bg-cyan-500/10 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-[450px] h-[450px] bg-purple-500/15 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-500/5 rounded-full filter blur-[150px] pointer-events-none" />

      {/* Main content grid: Side-by-side Showcase & Login */}
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
        
        {/* Left Column: Highly-polished Phone/Poster Showcase resembling the exact UI Image */}
        <div className="lg:col-span-6 flex flex-col items-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 15 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="relative w-full max-w-[340px] aspect-[9/19] rounded-[40px] border-[10px] border-slate-950 bg-[#070b12] overflow-hidden shadow-[0_25px_60px_rgba(0,0,0,0.8),0_0_40px_rgba(168,85,247,0.15)] flex flex-col group"
            id="playmate-smartphone-showcase"
          >
            {/* Phone Speaker notch */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-32 h-6 bg-slate-950 rounded-b-2xl z-40 flex items-center justify-center">
              <div className="w-12 h-1 bg-slate-800 rounded-full mb-1" />
            </div>

            {/* Cinematic Collage Image */}
            <div className="absolute inset-0 z-0">
              <img
                src={legendsCollage}
                alt="Football Legends Spectacular"
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              {/* Overlay gradient mirroring the image’s dark dramatic bottom fade & cosmic glow */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-black/40 z-10" />
              <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/95 z-10" />
              <div className="absolute inset-0 bg-purple-500/10 mix-blend-color z-10" />
            </div>

            {/* Text Overlay & Bouncing Purple Button Content */}
            <div className="relative mt-auto w-full p-6 text-center z-20 flex flex-col items-center space-y-4">
              <div className="space-y-1.5">
                <h3 className="text-2xl font-black tracking-tight text-white leading-tight">
                  Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 font-extrabold drop-shadow-[0_0_15px_rgba(168,85,247,0.5)]">VoltPortal</span>
                </h3>
                <p className="text-slate-400 text-xs font-medium tracking-wide">
                  Football Volunteer Assistant
                </p>
              </div>

              {/* Bouncing Purple Right-Chevron Action Button exactly like the image */}
              <motion.button
                onClick={handleInstantBypass}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
                className="w-14 h-14 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-500 text-white flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.6)] cursor-pointer hover:from-purple-500 hover:to-indigo-400"
                id="playmate-interactive-chevron-btn"
                title="Instant entry bypass"
              >
                <ChevronRight className="w-7 h-7 stroke-[2.5]" />
              </motion.button>
            </div>
            
            {/* Ambient neon decorative corner */}
            <div className="absolute top-12 left-4 z-20 opacity-80">
              <span className="text-[9px] font-mono font-bold bg-purple-950/90 text-purple-300 border border-purple-800/50 px-2 py-0.5 rounded">
                LIVE SPECTACULAR
              </span>
            </div>
          </motion.div>
        </div>

        {/* Right Column: FIFA World Cup Branding & Tactical Login Form Card */}
        <div className="lg:col-span-6 flex flex-col justify-center space-y-8">
          
          {/* Header & FIFA World Cup Branding Banner */}
          <div className="text-center lg:text-left space-y-4 pl-1">
            <div className="flex items-center justify-center lg:justify-start gap-2">
              <div className="p-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
                <Trophy className="w-5 h-5 animate-bounce" />
              </div>
              <span className="text-xs font-mono font-black uppercase tracking-widest text-amber-400">
                FIFA World Cup 2026™
              </span>
            </div>
            
            <div className="flex flex-col sm:flex-row items-center lg:items-center justify-center lg:justify-start gap-4">
              <AnimatedFootballerLogo />
              <h1 className="text-4xl sm:text-5xl font-black font-display tracking-tight text-white leading-none">
                VOLT <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-500">PORTAL</span>
              </h1>
            </div>
            
            <p className="text-slate-400 text-sm max-w-md mx-auto lg:mx-0">
              The high-performance tactical interface for stadiums, logistics support, translators, and immediate incident coordination.
            </p>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="w-full max-w-md bg-slate-900/70 border border-slate-800/80 rounded-3xl p-6 sm:p-8 backdrop-blur-xl relative overflow-hidden shadow-[0_20px_50px_rgba(0,0,0,0.5)] mx-auto lg:mx-0"
            id="login-card"
          >
            {/* Top design highlight strip */}
            <div className="absolute top-0 left-0 right-0 h-[3px] bg-gradient-to-r from-purple-500 via-pink-500 to-cyan-500" />
            
            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-cyan-400" />
                  <span className="text-xs font-black uppercase tracking-widest text-slate-400">VOLUNTEER SIGN IN</span>
                </div>
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse" />
              </div>
              <h2 className="text-xl font-bold font-display text-white">Unlock Tactical Dashboard</h2>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Volunteer ID Input */}
              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider pl-1 block">
                  Volunteer Badge ID
                </label>
                <div className="relative">
                  <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={volId}
                    onChange={(e) => setVolId(e.target.value)}
                    placeholder="e.g. VOL-2026"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500 text-white text-sm outline-none transition-all placeholder:text-slate-600 font-bold"
                    required
                  />
                </div>
              </div>

              {/* Passcode Input */}
              <div className="space-y-1.5">
                <div className="flex justify-between items-center px-1">
                  <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                    Tactical Passcode
                  </label>
                  <span className="text-[9px] text-pink-400 font-mono">Hint: 2026</span>
                </div>
                <div className="relative">
                  <Key className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="••••"
                    className="w-full pl-10 pr-4 py-3 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500 text-white text-sm outline-none transition-all placeholder:text-slate-600 font-mono font-bold"
                    required
                  />
                </div>
              </div>

              {/* Error block */}
              <AnimatePresence mode="wait">
                {errorMsg && (
                  <motion.div
                    initial={{ opacity: 0, y: -5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -5 }}
                    className="p-3 rounded-xl bg-pink-950/40 border border-pink-900/50 text-xs font-semibold text-pink-400 flex items-center gap-2"
                  >
                    <span>⚠️</span>
                    <span>{errorMsg}</span>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Sign in Button */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-black font-extrabold text-sm tracking-wide transition-all shadow-[0_4px_20px_rgba(6,182,212,0.25)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
                id="submit-login-btn"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>AUTHENTICATING LOGISTICAL PORT...</span>
                  </>
                ) : (
                  <>
                    <span>UNLOCK DASHBOARD</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Simulator Bypass */}
            <div className="mt-6 pt-5 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
              <span className="flex items-center gap-1.5 font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                Want instant simulation access?
              </span>
              <button
                onClick={handleInstantBypass}
                className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-cyan-400 font-bold hover:bg-slate-900 transition-all cursor-pointer text-[11px]"
                id="bypass-login-btn"
              >
                Instant Simulator Entry
              </button>
            </div>
          </motion.div>
        </div>

      </div>
    </div>
  );
}
