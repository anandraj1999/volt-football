import React, { useState, useEffect, useRef } from "react";
import { TranslateResponse } from "../types";
import { Mic, MicOff, Send, Volume2, Globe, ArrowUpDown, ChevronDown, Check, HelpCircle, Sun, Moon, Search } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import ShowToFanModal from "./ShowToFanModal";

const ALL_SPECIFIC_LANGUAGES = [
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "pt", name: "Português", flag: "🇧🇷" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "ar", name: "العربية", flag: "🇸🇦" },
  { code: "ko", name: "한국어", flag: "🇰🇷" },
];

const AUTO_LANG = { code: "auto", name: "Auto Detect", flag: "🌐" };

// Pre-recorded simulator templates for voice/iframe environments
const DEMO_SPEAK_TEMPLATES = [
  { text: "Hola, ¿dónde está el elevador para personas con silla de ruedas?", lang: "es", label: "Spanish: Wheelchair elevator query" },
  { text: "Oi! Onde posso encontrar comida vegetariana perto do portão B?", lang: "pt", label: "Portuguese: Vegetarian food query" },
  { text: "Excusez-moi, où se trouve le poste de secours le plus proche?", lang: "fr", label: "French: First Aid query" },
  { text: "My bag is not clear. Is it allowed inside Gate Verizon?", lang: "en", label: "English: Clear bag policy query" },
  { text: "Hallo, ¿can I exit the stadium to get a jacket?", lang: "de", label: "German: Re-entry query" }
];

export default function TranslateTab() {
  const [inputText, setInputText] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("auto");
  const [showMoreLanguages, setShowMoreLanguages] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translationResult, setTranslationResult] = useState<TranslateResponse | null>(null);
  const [errorText, setErrorText] = useState("");

  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const [recentLanguages, setRecentLanguages] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem("volt_recent_languages");
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.slice(0, 3);
        }
      }
    } catch (e) {
      console.warn("Failed to load recent languages", e);
    }
    return ["es", "pt", "fr"]; // Default top 3
  });

  const handleSelectLanguage = (code: string) => {
    setSelectedLanguage(code);
    setTranslationResult(null);

    if (code !== "auto") {
      setRecentLanguages((prev) => {
        const filtered = prev.filter((c) => c !== code);
        const updated = [code, ...filtered].slice(0, 3);
        try {
          localStorage.setItem("volt_recent_languages", JSON.stringify(updated));
        } catch (e) {
          console.warn("Failed to save recent languages", e);
        }
        return updated;
      });
    }
  };

  // Voice Speech Recognition State
  const [isListening, setIsListening] = useState(false);
  const [isSpeechSupported, setIsSpeechSupported] = useState(false);
  const [showDemoSimulator, setShowDemoSimulator] = useState(false);
  
  // Show to Fan mode
  const [showToFanMode, setShowToFanMode] = useState(false);
  const [fanCardHighContrast, setFanCardHighContrast] = useState(true); // White bg, black text for glare reading
  const [isSpeaking, setIsSpeaking] = useState(false);

  // Stop any active speech on unmount
  useEffect(() => {
    return () => {
      if ("speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Web Speech API Reference
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check for browser speech recognition support
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      setIsSpeechSupported(true);
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = selectedLanguage === "auto" ? "es-ES" : selectedLanguage; // Default to ES or selected
      
      rec.onstart = () => {
        setIsListening(true);
      };

      rec.onresult = (event: any) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };

      rec.onerror = (e: any) => {
        console.error("Speech recognition error:", e);
        setIsListening(false);
        // Fall back to showing the interactive simulation bar in iframe
        setShowDemoSimulator(true);
      };

      rec.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = rec;
    } else {
      // No browser support (common in strict sandboxed iframes). Show demo prompts
      setIsSpeechSupported(false);
      setShowDemoSimulator(true);
    }
  }, [selectedLanguage]);

  const handleMicToggle = () => {
    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
    } else {
      if (isSpeechSupported && recognitionRef.current) {
        recognitionRef.current.lang = selectedLanguage === "auto" ? "es-ES" : selectedLanguage;
        try {
          recognitionRef.current.start();
        } catch (e) {
          console.warn("Speech API failed to start. Using simulation mode.", e);
          setIsListening(true);
          // Auto fill with a template after 2.5s to simulate speaking
          setTimeout(() => {
            const randomTpl = DEMO_SPEAK_TEMPLATES[Math.floor(Math.random() * DEMO_SPEAK_TEMPLATES.length)];
            setInputText(randomTpl.text);
            if (selectedLanguage === "auto") {
              handleSelectLanguage(randomTpl.lang);
            }
            setIsListening(false);
          }, 2500);
        }
      } else {
        // Simulation voice capture
        setIsListening(true);
        setTimeout(() => {
          const randomTpl = DEMO_SPEAK_TEMPLATES[Math.floor(Math.random() * DEMO_SPEAK_TEMPLATES.length)];
          setInputText(randomTpl.text);
          setIsListening(false);
        }, 1800);
      }
    }
  };

  const getOfflineTranslation = (queryText: string, langCode: string): TranslateResponse => {
    const text = queryText.toLowerCase().trim();
    let detectedIntent: "gate" | "seating" | "accessibility" | "food" | "medical" | "lost_found" | "restroom" | "general" = "general";
    let detectedLanguage = "Spanish"; // Default
    let englishSummary = "Wants general info";
    let fanResponse = "Hi! We are currently operating in offline stadium mode. How can I help you today?";
    let phoneticSpelling = "Hi! Wee are kur-rently op-er-ating in off-line sta-dee-um mode. How can I help you too-day?";
    let groundingReference = "Local Static Database";

    // Language detection
    if (text.includes("hola") || text.includes("dónde") || text.includes("puerta") || text.includes("baño") || text.includes("comida")) {
      detectedLanguage = "Spanish";
    } else if (text.includes("oi") || text.includes("portão") || text.includes("onde") || text.includes("comida") || text.includes("por favor")) {
      detectedLanguage = "Portuguese";
    } else if (text.includes("excusez") || text.includes("où") || text.includes("secours") || text.includes("sac")) {
      detectedLanguage = "French";
    } else if (text.includes("hallo") || text.includes("ausgang") || text.includes("tasche")) {
      detectedLanguage = "German";
    }

    if (langCode && langCode !== "auto") {
      const match = ALL_SPECIFIC_LANGUAGES.find(l => l.code === langCode);
      if (match) detectedLanguage = match.name;
    }

    if (text.includes("bag") || text.includes("backpack") || text.includes("bolsa") || text.includes("mochila") || text.includes("sac") || text.includes("tasche")) {
      detectedIntent = "accessibility";
      englishSummary = "Bag policy rules query";
      groundingReference = "Policies - Bag Policy";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] Solamente se permiten bolsas de plástico transparentes de menos de 12" x 6" x 12". Los bolsos pequeños de menos de 4.5" x 6.5" están permitidos. Los equipos médicos se examinan en la Puerta A o C.`;
        phoneticSpelling = "Soh-lah-men-teh seh per-mee-ten bohl-sahs deh plahs-tee-coh trahns-pah-ren-tehs. Bol-sohspeh-keh-nyohs per-mee-tee-dohs.";
      } else if (detectedLanguage === "Portuguese" || langCode === "pt") {
        fanResponse = `[Offline Local] Apenas bolsas plásticas transparentes de no máximo 12" x 6" x 12" são permitidas. Pequenas bolsas de até 4.5" x 6.5" são autorizadas. Bolsas médicas são revistadas nos Portões A ou C.`;
        phoneticSpelling = "Ah-peh-nahs bohl-sahs plahs-tee-cahs trahns-pah-ren-tehs sah-oh per-mee-tee-dahs.";
      } else {
        fanResponse = `[Offline Local] Only clear plastic bags under 12" x 6" x 12" are allowed. Small clutches under 4.5" x 6.5" are permitted. Medical bags are screened at Gates A or C.`;
        phoneticSpelling = "Ohn-lee kleer plas-tik bags un-der twelve by six by twelve are al-lowed.";
      }
    } 
    else if (text.includes("taco") || text.includes("tacocita") || text.includes("gluten") || text.includes("celiac")) {
      detectedIntent = "food";
      englishSummary = "Wants gluten-free food";
      groundingReference = "Concession C3 - Tacocita (Sec 104)";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] ¡Sí! "Tacocita" en la Sección 104 del Concourse es 100% libre de gluten. Sirven tacos de carne asada y carnitas con tortillas de maíz.`;
        phoneticSpelling = "See! Tah-coh-see-tah en lah sek-see-ohn syehn-toh kwah-troh es syehn por syehn-toh lee-breh deh gloo-ten.";
      } else {
        fanResponse = `[Offline Local] Yes! "Tacocita" at Concourse Section 104 is 100% certified gluten-free. They serve carne asada and carnitas street tacos with corn tortillas.`;
        phoneticSpelling = "Yes! Tah-co-see-tah at Con-course Sec-tion one-oh-four is one hun-dred per-cent glu-ten free.";
      }
    }
    else if (text.includes("food") || text.includes("eat") || text.includes("comida") || text.includes("vegetariana") || text.includes("vegan") || text.includes("halal") || text.includes("pizza") || text.includes("kosher")) {
      detectedIntent = "food";
      englishSummary = "Food concession directions";
      groundingReference = "Concessions Database - Sections 104/109/116/142";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] Comida vegetariana y vegana disponible en "Global Greens" (Sección 116) y "South Plaza Halal" (Sección 109). Comida Halal en Sección 142. Pizza en Sección 112.`;
        phoneticSpelling = "Coh-mee-dah veh-heh-tah-ryah-nah dee-spoh-nee-bleh en Gloh-bahl Greens, sek-see-ohn syehn-toh dyeh-see-seh-ees.";
      } else if (detectedLanguage === "Portuguese" || langCode === "pt") {
        fanResponse = `[Offline Local] Comida vegetariana e vegana está disponível em "Global Greens" (Seção 116) e "South Plaza Halal" (Seção 109). Pratos Halal estão na Seção 142.`;
        phoneticSpelling = "Coh-mee-dah veh-jeh-tah-ryah-nah eh vee-gahn-ah ehs-tah dee-spoh-nee-vel ehn Gloh-bahl Greens.";
      } else {
        fanResponse = `[Offline Local] Vegetarian and vegan food is at "Global Greens" (Section 116) and "South Plaza Halal" (Section 109). Halal dishes are at "Halal Corner" (Section 142).`;
        phoneticSpelling = "Veh-jeh-tair-ee-an and vee-gan food is available at Glo-bal Greens, Sec-tion one-six-teen.";
      }
    }
    else if (text.includes("elevator") || text.includes("ascensor") || text.includes("elevador") || text.includes("wheelchair") || text.includes("silla de ruedas") || text.includes("cadeira de rodas")) {
      detectedIntent = "accessibility";
      englishSummary = "Wants wheelchair elevator assistance";
      groundingReference = "Accessible Seating & Elevators 1-5";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] El elevador principal más cercano es el Elevador #1 en el Vestíbulo de Verizon (Sección 124). El personal de servicios puede prestarle una silla de ruedas en la Sección 124 o 117.`;
        phoneticSpelling = "El eh-leh-vah-dor preen-see-pahl mahs ser-kah-noh es el eh-leh-vah-dor oo-noh en el ves-tee-boo-loh deh Veh-rye-zohn.";
      } else if (detectedLanguage === "Portuguese" || langCode === "pt") {
        fanResponse = `[Offline Local] O elevador mais próximo é o Elevador #1 no Saguão Verizon (Seção 124). Cadeiras de rodas de empréstimo estão disponíveis no balcão de atendimento Seção 124.`;
        phoneticSpelling = "Oo eh-leh-vah-dor mais proh-see-moh eh oo eh-leh-vah-dor oom no sah-gwah-oo Verizon.";
      } else {
        fanResponse = `[Offline Local] The nearest main elevator is Elevator #1 inside the Verizon Lobby (Section 124). Free wheelchair escorts and loaners are at Guest Services Section 124.`;
        phoneticSpelling = "The near-est e-le-vay-tor is E-le-vay-tor one in the Ve-ri-zon Lob-by, near Sec-tion one-twen-ty-four.";
      }
    }
    else if (text.includes("first aid") || text.includes("medical") || text.includes("médico") || text.includes("enfermero") || text.includes("socours") || text.includes("sick") || text.includes("hurt") || text.includes("dolor") || text.includes("enfermo") || text.includes("ambulancia")) {
      detectedIntent = "medical";
      englishSummary = "Medical emergency / First Aid query";
      groundingReference = "Medical Station 1 / 4 (Sections 128 / 117)";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] ¡Mantenga la calma! El puesto de primeros auxilios más cercano está en la Sección 128 (junto a la Puerta A) o la clínica de servicio completo en la Sección 117.`;
        phoneticSpelling = "Mahn-ten-gah lah kahl-mah! El pwes-toh deh pree-meh-rohs ah-ooh-see-lyohs mahs ser-kah-noh es-tah en lah sek-see-ohn syehn-toh veyn-tee-oh-choh.";
      } else {
        fanResponse = `[Offline Local] Please stay calm! The nearest First Aid station is located at Section 128 (near Gate A) and a full medical clinic is located at Section 117.`;
        phoneticSpelling = "Pleeze stay kahm! The near-est First Aid is at Sec-tion one-twen-ty-eight.";
      }
    }
    else if (text.includes("restroom") || text.includes("toilet") || text.includes("bathroom") || text.includes("wc") || text.includes("baño") || text.includes("banheiro") || text.includes("toilette")) {
      detectedIntent = "restroom";
      englishSummary = "Nearest restroom directions";
      groundingReference = "Restrooms Database - Zone 100 North / West";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] Los sanitarios más cercanos están en la Sección 124 y Sección 128 (ambos accesibles para silla de ruedas). Baño familiar sin género en la Sección 129.`;
        phoneticSpelling = "Lohs sah-nee-tah-ryohs mahs ser-kah-nohs es-tahn en lah sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Local] The nearest restrooms are at Section 124 and Section 128 (ADA Accessible). Family gender-neutral restroom is at Section 129.`;
        phoneticSpelling = "The near-est rest-rooms are at Sec-tion one-twen-ty-four and one-twen-ty-eight.";
      }
    }
    else if (text.includes("gate") || text.includes("entrance") || text.includes("puerta") || text.includes("portão") || text.includes("entrada")) {
      detectedIntent = "gate";
      englishSummary = "Gate location & wait-time";
      groundingReference = "Gates - A/B/C/D/E/F/G/H database";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] Puerta A (Verizon) está en la Sección 124 (8 min de espera). Puerta B (Hyland) en Sec 131. Puerta D (Bud Light) en Sec 101 tiene la espera más corta (4 min).`;
        phoneticSpelling = "Pwer-tah Ah es-tah en lah sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else if (detectedLanguage === "Portuguese" || langCode === "pt") {
        fanResponse = `[Offline Local] Portão A (Verizon) está na Seção 124 (8 min de espera). Portão D (Bud Light) na Seção 101 é o mais rápido hoje (4 min).`;
        phoneticSpelling = "Por-tah-oo Ah es-tah nah seh-sah-oo syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Local] Gate A (Verizon) is at Section 124 (8m wait). Gate D (Bud Light) at Section 101 has the shortest wait time currently (only 4 minutes).`;
        phoneticSpelling = "Gate A is at Sec-tion one-twen-ty-four, and Gate D is at Sec-tion one-oh-one.";
      }
    }
    else if (text.includes("lost") || text.includes("found") || text.includes("perdido") || text.includes("objeto") || text.includes("carteira") || text.includes("wallet")) {
      detectedIntent = "lost_found";
      englishSummary = "Lost and Found instructions";
      groundingReference = "Lost & Found Guest Services (Sec 124)";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] La oficina de objetos perdidos está en Guest Services, Sección 124. Si perdió un niño o acompañante, acompáñeme de inmediato a la Sección 124 para alertar a control.`;
        phoneticSpelling = "La oh-fee-see-nah deh ob-heh-tohs per-dee-dohs es-tah en Guest Ser-vee-ses sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Local] Lost & Found is located at Guest Services near Section 124. If a child or companion is separated, please come with me immediately to Section 124.`;
        phoneticSpelling = "Lost and Found is lo-cay-ted at Guest Ser-vi-ces near Sec-tion one-twen-ty-four.";
      }
    }
    else if (text.includes("reentry") || text.includes("re-entry") || text.includes("salir") || text.includes("exit") || text.includes("reentrar") || text.includes("saída")) {
      detectedIntent = "general";
      englishSummary = "Re-entry policy query";
      groundingReference = "Policies - Re-Entry Prohibited";
      if (detectedLanguage === "Spanish" || langCode === "es") {
        fanResponse = `[Offline Local] El reingreso está estrictamente prohibido. Si sale del estadio, su boleto digital quedará inhabilitado permanentemente y no podrá volver a entrar.`;
        phoneticSpelling = "El reh-een-greh-soh es-tah es-treck-tah-men-teh proh-ee-bee-doh.";
      } else if (detectedLanguage === "Portuguese" || langCode === "pt") {
        fanResponse = `[Offline Local] A reentrada é estritamente proibida. Uma vez que sair do estádio, o seu bilhete digital será permanentemente desativado.`;
        phoneticSpelling = "Ah reh-en-trah-dah eh es-tree-tah-men-teh proh-ee-bee-dah.";
      } else {
        fanResponse = `[Offline Local] Re-entry is strictly prohibited. Once you exit the stadium gates, your digital ticket is permanently deactivated and cannot be reused.`;
        phoneticSpelling = "Ree-en-tree is strick-ly pro-hib-i-ted.";
      }
    }

    return {
      detectedLanguage: `${detectedLanguage} (Local)`,
      detectedIntent,
      englishSummary: `[Offline Local] ${englishSummary}`,
      fanResponse,
      phoneticSpelling,
      groundingReference: `Offline Cache: ${groundingReference}`
    };
  };

  const handleTranslateSubmit = async (textToTranslate = inputText) => {
    const finalQuery = textToTranslate.trim();
    if (!finalQuery) return;

    setIsTranslating(true);
    setErrorText("");
    setTranslationResult(null);

    try {
      const response = await fetch("/api/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          text: finalQuery,
          languageCode: selectedLanguage
        })
      });

      if (response.ok) {
        const data = await response.json();
        setTranslationResult(data);
      } else {
        // Fallback to local translation on status error
        console.warn("Translation server returned error status, falling back to local...");
        const offlineData = getOfflineTranslation(finalQuery, selectedLanguage);
        setTranslationResult(offlineData);
      }
    } catch (err) {
      console.warn("Translation network error, falling back to local on-device database:", err);
      // Generate instant offline local translation using our on-device database
      const offlineData = getOfflineTranslation(finalQuery, selectedLanguage);
      setTranslationResult(offlineData);
    } finally {
      setIsTranslating(false);
    }
  };

  const handleSpeakAloud = (text: string) => {
    if (!("speechSynthesis" in window)) {
      alert("Text-to-speech is not supported in this browser.");
      return;
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    // Cancel any active or queued speech before starting
    window.speechSynthesis.cancel();

    if (!text) return;

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Auto map language code or language name to the appropriate speechSynthesis locale
    let langCode = "en-US";
    if (selectedLanguage && selectedLanguage !== "auto") {
      langCode = selectedLanguage;
    } else if (translationResult) {
      const detected = translationResult.detectedLanguage || "";
      const clean = detected.toLowerCase();
      if (clean.includes("es") || clean.includes("span")) langCode = "es-ES";
      else if (clean.includes("pt") || clean.includes("port")) langCode = "pt-BR";
      else if (clean.includes("fr") || clean.includes("fren")) langCode = "fr-FR";
      else if (clean.includes("de") || clean.includes("germ")) langCode = "de-DE";
      else if (clean.includes("ja") || clean.includes("japa")) langCode = "ja-JP";
      else if (clean.includes("ar") || clean.includes("arab")) langCode = "ar-SA";
      else if (clean.includes("ko") || clean.includes("kore")) langCode = "ko-KR";
      else if (clean.includes("en") || clean.includes("engl")) langCode = "en-US";
    }

    utterance.lang = langCode;
    
    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const pinnedLangs = recentLanguages
    .map((code) => ALL_SPECIFIC_LANGUAGES.find((l) => l.code === code))
    .filter(Boolean) as typeof ALL_SPECIFIC_LANGUAGES;

  const currentLanguageDetails = selectedLanguage === "auto"
    ? AUTO_LANG
    : ALL_SPECIFIC_LANGUAGES.find((l) => l.code === selectedLanguage) || { code: selectedLanguage, name: selectedLanguage, flag: "🌐" };

  const dropdownLanguagesList = [AUTO_LANG, ...ALL_SPECIFIC_LANGUAGES];
  const filteredDropdownLanguages = dropdownLanguagesList.filter((lang) =>
    lang.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    lang.code.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6" id="translate-tab-container">
      {/* 1. Language Select Dropdown & Quick Presets */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4 backdrop-blur-sm space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Target Fan Language</span>
            <span className="text-[9px] bg-cyan-950/80 text-cyan-400 px-1.5 py-0.5 rounded border border-cyan-800/40 font-mono flex items-center gap-1">
              <span>⚡ ON-DEMAND TRANSLATOR</span>
            </span>
          </div>
        </div>

        {/* Custom Searchable Dropdown */}
        <div className="relative" ref={dropdownRef} id="target-language-dropdown-wrapper">
          <button
            type="button"
            onClick={() => {
              setIsDropdownOpen(!isDropdownOpen);
              setSearchQuery(""); // Clear search on open
            }}
            className="w-full flex items-center justify-between gap-3 bg-slate-950 hover:bg-slate-900/80 border border-slate-800 focus:border-cyan-500 rounded-xl px-4 py-3.5 text-sm text-slate-200 transition-all cursor-pointer shadow-lg"
            id="language-dropdown-trigger"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-lg leading-none">{currentLanguageDetails.flag}</span>
              <span className="font-bold text-slate-100">{currentLanguageDetails.name}</span>
              <span className="text-xs text-slate-500 font-mono uppercase">({currentLanguageDetails.code})</span>
            </div>
            <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${isDropdownOpen ? "rotate-180 text-cyan-400" : ""}`} />
          </button>

          <AnimatePresence>
            {isDropdownOpen && (
              <motion.div
                initial={{ opacity: 0, y: -8, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8, scale: 0.98 }}
                transition={{ duration: 0.15 }}
                className="absolute left-0 right-0 mt-2 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl p-2 z-50 overflow-hidden backdrop-blur-lg"
                id="language-dropdown-menu"
              >
                {/* Search Bar */}
                <div className="relative mb-2">
                  <Search className="absolute left-3 top-3 w-4 h-4 text-slate-500" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search languages..."
                    className="w-full bg-slate-900 border border-slate-800/80 focus:border-cyan-500/80 focus:outline-none rounded-lg pl-9 pr-4 py-2 text-xs text-slate-200 placeholder-slate-500"
                    id="language-search-input"
                    autoFocus
                  />
                  {searchQuery && (
                    <button
                      type="button"
                      onClick={() => setSearchQuery("")}
                      className="absolute right-3 top-2.5 text-[10px] text-slate-500 hover:text-slate-300 font-bold uppercase"
                    >
                      Clear
                    </button>
                  )}
                </div>

                {/* Options List */}
                <div className="max-h-48 overflow-y-auto space-y-0.5 custom-scrollbar">
                  {filteredDropdownLanguages.length > 0 ? (
                    filteredDropdownLanguages.map((lang) => (
                      <button
                        key={lang.code}
                        type="button"
                        onClick={() => {
                          handleSelectLanguage(lang.code);
                          setIsDropdownOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-semibold text-left transition-all cursor-pointer ${
                          selectedLanguage === lang.code
                            ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 font-bold"
                            : "bg-transparent border border-transparent hover:bg-slate-900 text-slate-300 hover:text-slate-100"
                        }`}
                        id={`dropdown-lang-${lang.code}`}
                      >
                        <div className="flex items-center gap-2">
                          <span className="text-base leading-none">{lang.flag}</span>
                          <span>{lang.name}</span>
                          <span className="text-[10px] text-slate-500 font-mono">({lang.code})</span>
                        </div>
                        {selectedLanguage === lang.code && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                      </button>
                    ))
                  ) : (
                    <div className="text-center py-4 text-xs text-slate-500">
                      No languages found for "{searchQuery}"
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Quick presets row */}
        <div className="space-y-1.5 pt-1 border-t border-slate-800/40">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Quick Presets</span>
          <div className="flex flex-wrap gap-1.5">
            {/* Auto Detect */}
            <button
              key={AUTO_LANG.code}
              type="button"
              onClick={() => handleSelectLanguage(AUTO_LANG.code)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                selectedLanguage === AUTO_LANG.code
                  ? "bg-cyan-500 border-cyan-400 text-black shadow-[0_0_8px_rgba(6,182,212,0.2)]"
                  : "bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200"
              }`}
              id={`quick-lang-pick-${AUTO_LANG.code}`}
            >
              <span>{AUTO_LANG.flag}</span>
              <span>{AUTO_LANG.name}</span>
            </button>

            {/* Recent Languages */}
            {pinnedLangs.map((lang) => (
              <button
                key={lang.code}
                type="button"
                onClick={() => handleSelectLanguage(lang.code)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border cursor-pointer ${
                  selectedLanguage === lang.code
                    ? "bg-cyan-500 border-cyan-400 text-black shadow-[0_0_8px_rgba(6,182,212,0.2)]"
                    : "bg-slate-950/60 border-slate-800/80 text-slate-400 hover:border-slate-700 hover:text-slate-200"
                }`}
                id={`quick-lang-pick-${lang.code}`}
              >
                <span>{lang.flag}</span>
                <span>{lang.name}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 2. Interactive Simulator Fallback (Only shown for ease of testing or sandbox environments) */}
      {showDemoSimulator && (
        <div className="bg-slate-950 border border-slate-900 rounded-xl p-3.5 space-y-2">
          <div className="flex items-center gap-1.5 text-slate-500">
            <HelpCircle className="w-3.5 h-3.5 text-cyan-500" />
            <span className="text-[10px] font-bold uppercase tracking-wider">Iframe Sandbox Test Prompts</span>
          </div>
          <div className="grid grid-cols-1 gap-1.5 max-h-[140px] overflow-y-auto">
            {DEMO_SPEAK_TEMPLATES.map((tpl, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setInputText(tpl.text);
                  handleSelectLanguage(tpl.lang);
                  handleTranslateSubmit(tpl.text);
                }}
                className="w-full text-left bg-slate-900 hover:bg-cyan-950/20 border border-slate-800 hover:border-cyan-800/50 p-2 rounded-lg text-xs font-medium text-slate-300 hover:text-cyan-400 transition-all flex items-center justify-between"
                id={`demo-prompt-${idx}`}
              >
                <span>{tpl.label}</span>
                <span className="text-[10px] text-slate-500 font-mono italic">"{tpl.text.substring(0, 20)}..."</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 3. Input Text area & Mic Button */}
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-4.5 backdrop-blur-sm space-y-4">
        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              isListening 
                ? "Listening... Speak clearly near phone microphone." 
                : "Type what the fan said OR use quick demo prompts above..."
            }
            rows={3}
            className="w-full bg-slate-950 border border-slate-800 focus:border-cyan-500 focus:outline-none rounded-xl px-3.5 py-3 text-sm text-slate-200 placeholder-slate-500 resize-none transition-all pr-12"
            id="translate-input-area"
          />
          {inputText && (
            <button
              onClick={() => setInputText("")}
              className="absolute right-3.5 top-3 text-[11px] text-slate-500 hover:text-slate-300 uppercase font-bold"
              id="clear-input-btn"
            >
              Clear
            </button>
          )}
        </div>

        {/* Action Row */}
        <div className="flex items-center justify-between gap-3">
          {/* Audio Mic Button */}
          <button
            onClick={handleMicToggle}
            className={`w-14 h-14 rounded-full flex items-center justify-center border transition-all cursor-pointer ${
              isListening
                ? "bg-pink-600 border-pink-400 text-white animate-pulse shadow-[0_0_16px_rgba(236,72,153,0.5)]"
                : "bg-cyan-950/40 border-cyan-800/60 text-cyan-400 hover:bg-cyan-900/20 hover:border-cyan-500"
            }`}
            title="Speak as a Fan"
            id="mic-trigger-btn"
          >
            {isListening ? (
              <MicOff className="w-5.5 h-5.5" />
            ) : (
              <div className="relative flex items-center justify-center">
                <Mic className="w-5.5 h-5.5" />
                {!isListening && <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />}
              </div>
            )}
          </button>

          {/* Submit button */}
          <button
            onClick={() => handleTranslateSubmit()}
            disabled={isTranslating || !inputText.trim()}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-extrabold font-display transition-all text-sm disabled:opacity-50 cursor-pointer shadow-[0_0_12px_rgba(6,182,212,0.2)]"
            id="translate-submit-btn"
          >
            {isTranslating ? (
              <>
                <div className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>Translating & Checking Stadium Data...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Instant Translate</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 4. Display Translation Result Card */}
      {errorText && (
        <div className="bg-red-950/30 border border-red-900/60 text-red-400 p-4 rounded-xl text-xs">
          {errorText}
        </div>
      )}

      <AnimatePresence>
        {translationResult && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 15 }}
            transition={{ type: "spring", stiffness: 120, damping: 20 }}
            className="space-y-4"
            id="translation-result-display"
          >
            {/* VOLT Core Triage Block */}
            <div className="bg-slate-900/80 border border-cyan-800/50 rounded-2xl p-5 backdrop-blur-md space-y-4 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/5 rounded-full filter blur-2xl" />
              
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
                <div className="flex items-center gap-2">
                  <Globe className="w-4.5 h-4.5 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-300">
                    Detected: <strong className="text-cyan-400 font-display">{translationResult.detectedLanguage}</strong>
                  </span>
                </div>
                <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded-md bg-cyan-950 border border-cyan-900 text-cyan-400">
                  Intent: {translationResult.detectedIntent}
                </span>
              </div>

              {/* RAG English Triage Summary */}
              <motion.div 
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1, duration: 0.3 }}
                className="bg-slate-950/80 border border-slate-900 rounded-xl p-3.5 space-y-1"
              >
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Volunteer High-Speed Triage</span>
                <p className="text-sm font-semibold text-slate-200">
                  {translationResult.englishSummary}
                </p>
                <div className="text-[9px] text-cyan-400/80 font-mono pt-1">
                  Database Grounding Context: {translationResult.groundingReference}
                </div>
              </motion.div>

              {/* Translated fan response and speech */}
              <div className="space-y-3">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2, duration: 0.35 }}
                >
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">Response script in {translationResult.detectedLanguage}</span>
                  <div className="bg-slate-950/80 border border-slate-900 rounded-xl p-3.5 relative shadow-[0_4px_20px_rgba(0,0,0,0.3)]">
                    <p className="text-sm font-bold text-slate-100 font-display italic leading-relaxed pr-8">
                      "{translationResult.fanResponse}"
                    </p>
                    <button
                      onClick={() => handleSpeakAloud(translationResult.fanResponse)}
                      className={`absolute right-3.5 top-3.5 p-1.5 rounded-md transition-all duration-200 ${
                        isSpeaking 
                          ? "bg-pink-600 text-white animate-pulse shadow-[0_0_8px_rgba(236,72,153,0.3)]" 
                          : "bg-slate-900 hover:bg-slate-800 text-cyan-400 hover:text-cyan-300"
                      }`}
                      title={isSpeaking ? "Stop speaking" : "Speak script aloud"}
                      id="speak-aloud-btn"
                    >
                      <Volume2 className={`w-4 h-4 ${isSpeaking ? "animate-bounce" : ""}`} />
                    </button>
                  </div>
                </motion.div>

                {/* Phonetic transliteration spelling */}
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.35 }}
                  className="p-3.5 bg-slate-950/40 border border-slate-900 rounded-xl space-y-1"
                >
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Spoken phonetic spelling guide (for volunteer to speak)</span>
                  <p className="text-xs font-medium text-pink-400 font-mono leading-relaxed">
                    {translationResult.phoneticSpelling}
                  </p>
                </motion.div>
              </div>

              {/* Action Buttons: Speak Aloud & Show to Fan */}
              <motion.div 
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4, duration: 0.3 }}
                className="grid grid-cols-2 gap-3 pt-2"
              >
                {/* Speak Aloud Button */}
                <button
                  type="button"
                  onClick={() => handleSpeakAloud(translationResult.fanResponse)}
                  className={`flex items-center justify-center gap-2 py-3.5 rounded-xl text-xs font-black uppercase tracking-wider transition-all duration-200 cursor-pointer border ${
                    isSpeaking
                      ? "bg-pink-600 border-pink-400 text-white animate-pulse shadow-[0_0_12px_rgba(236,72,153,0.4)]"
                      : "bg-cyan-950/50 border-cyan-500/30 text-cyan-400 hover:bg-cyan-500 hover:text-black hover:border-cyan-400 shadow-[0_0_8px_rgba(6,182,212,0.1)]"
                  }`}
                  id="speak-aloud-big-btn"
                >
                  <Volume2 className={`w-4 h-4 ${isSpeaking ? "animate-bounce" : ""}`} />
                  <span>{isSpeaking ? "Stop Speaking" : "Speak Aloud"}</span>
                </button>

                {/* Launch Show to Fan Mode Button */}
                <button
                  type="button"
                  onClick={() => setShowToFanMode(true)}
                  className="flex items-center justify-center gap-2 py-3.5 rounded-xl bg-gradient-to-r from-cyan-600 to-cyan-500 text-black font-extrabold font-display text-xs uppercase tracking-wider cursor-pointer hover:shadow-[0_4px_16px_rgba(6,182,212,0.25)] transition-all border border-cyan-400/20"
                  id="show-to-fan-btn"
                >
                  <ArrowUpDown className="w-4 h-4" />
                  <span>Show to Fan</span>
                </button>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 5. Big Show to Fan Overlay Modal */}
      <ShowToFanModal
        isOpen={showToFanMode}
        onClose={() => setShowToFanMode(false)}
        text={translationResult?.fanResponse || ""}
        languageName={translationResult?.detectedLanguage || "Detected Language"}
        onSpeak={translationResult ? () => handleSpeakAloud(translationResult.fanResponse) : undefined}
      />
    </div>
  );
}
