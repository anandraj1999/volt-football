export interface TranslateRequest {
  text: string;
  languageCode?: string; // Quick pick language code (e.g., 'es', 'pt', 'fr', 'en') or 'auto'
}

export interface TranslateResponse {
  detectedLanguage: string;
  detectedIntent: "gate" | "seating" | "accessibility" | "food" | "medical" | "lost_found" | "restroom" | "general";
  englishSummary: string; // Plain-English summary of what the fan needs
  fanResponse: string; // Ready-to-read response in the fan's language
  phoneticSpelling: string; // Phonetic transliteration for the volunteer to speak
  groundingReference?: string; // The stadium database section used for this answer
}

export interface IncidentAlert {
  id: string;
  category: "medical" | "crowd" | "safety" | "aggressive_fan" | "other";
  location: string;
  who: string;
  what: string;
  urgency: "low" | "medium" | "high" | "critical";
  timestamp: string;
  status: "pending" | "dispatched" | "resolved";
}

export interface CrowdScriptRequest {
  situation: string;
}

export interface CrowdScriptResponse {
  situation: string;
  englishAnnouncement: string;
  spanishAnnouncement: string;
  portugueseAnnouncement: string;
  timestamp: string;
}

export interface VolunteerShift {
  volunteerName: string;
  role: string;
  assignedZone: string; // e.g. "Zone A"
  assignedGate: string; // e.g. "Gate A (Verizon Gate)"
  shiftStart: string;
  shiftEnd: string;
  supervisorName: string;
  supervisorContact: string;
}
