import React, { useState, useEffect } from "react";
import TranslateTab from "./components/TranslateTab";
import QuickAnswersTab from "./components/QuickAnswersTab";
import AlertTab from "./components/AlertTab";
import ShiftTab from "./components/ShiftTab";
import AnimatedFootballerLogo from "./components/AnimatedFootballerLogo";
import LoginPage from "./components/LoginPage";
// @ts-ignore
import stadiumBg from "./assets/images/stadium_bg_1784193911751.jpg";
import { STADIUM_DATA } from "./stadiumData";
import { MessageCircle, HelpCircle, AlertOctagon, User, Compass, Wifi, ShieldCheck, LogOut } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

type TabId = "translate" | "quickAnswers" | "alerts" | "shift";

export default function App() {
  const [activeTab, setActiveTab] = useState<TabId>("translate");
  const [incidentCount, setIncidentCount] = useState(2); // Start with our mock incidents
  const [isOnline, setIsOnline] = useState(typeof navigator !== "undefined" ? navigator.onLine : true);

  // Persistent Auth State
  const [isLoggedIn, setIsLoggedIn] = useState(() => {
    return localStorage.getItem("volt_is_logged_in") === "true";
  });
  const [volunteerName, setVolunteerName] = useState(() => {
    return localStorage.getItem("volt_volunteer_name") || "";
  });

  const handleLoginSuccess = (name: string) => {
    setVolunteerName(name);
    setIsLoggedIn(true);
    localStorage.setItem("volt_is_logged_in", "true");
    localStorage.setItem("volt_volunteer_name", name);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setVolunteerName("");
    localStorage.removeItem("volt_is_logged_in");
    localStorage.removeItem("volt_volunteer_name");
  };

  // Query incidents periodically to show alert badge count
  const checkIncidents = async () => {
    try {
      const res = await fetch("/api/incidents");
      if (res.ok) {
        const data = await res.json();
        // Filter those that are not resolved
        const activeCount = data.filter((inc: any) => inc.status !== "resolved").length;
        setIncidentCount(activeCount);
      }
    } catch (e) {
      // Benign fallback
    }
  };

  useEffect(() => {
    checkIncidents();
    const interval = setInterval(checkIncidents, 10000);

    // Track network connectivity
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);

    return () => {
      clearInterval(interval);
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  return (
    <div className="min-h-screen bg-[#05080e] text-slate-100 flex flex-col relative overflow-x-hidden font-sans selection:bg-cyan-500 selection:text-black">
      {/* BACKGROUND GRAPHICS: Stadium Silhouette & Pitch Lines */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
        {/* Real Dynamic Stadium Background Image */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#05080e]/90 via-[#05080e]/80 to-[#05080e]/95 z-10" />
        <img
          src={stadiumBg}
          alt="World Cup Stadium"
          className="absolute inset-0 w-full h-full object-cover opacity-25 filter blur-[1px] mix-blend-lighten scale-105"
          referrerPolicy="no-referrer"
        />

        {/* Neon light hubs */}
        <div className="absolute -top-32 left-1/2 -translate-x-1/2 w-[600px] h-[300px] bg-gradient-to-b from-cyan-500/20 to-transparent rounded-full filter blur-[120px] z-20" />
        <div className="absolute -bottom-32 left-1/3 w-[400px] h-[400px] bg-pink-500/10 rounded-full filter blur-[140px] z-20" />

        {/* Pitch Lines Grid */}
        <svg className="absolute inset-0 w-full h-full opacity-[0.03] z-20" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="currentColor" strokeWidth="1" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          {/* Pitch center circle */}
          <circle cx="50%" cy="50%" r="120" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <line x1="50%" y1="0" x2="50%" y2="100%" stroke="currentColor" strokeWidth="1.5" />
          {/* Penalty areas */}
          <rect x="calc(50% - 150px)" y="0" width="300" height="100" fill="none" stroke="currentColor" strokeWidth="1.5" />
          <rect x="calc(50% - 150px)" y="calc(100% - 100px)" width="300" height="100" fill="none" stroke="currentColor" strokeWidth="1.5" />
        </svg>
      </div>

      {!isLoggedIn ? (
        <div className="relative z-20 flex-1 flex items-center justify-center">
          <LoginPage onLoginSuccess={handleLoginSuccess} />
        </div>
      ) : (
        <>
          {/* HEADER SECTION */}
          <header className="sticky top-0 bg-[#05080e]/85 backdrop-blur-md border-b border-slate-900 z-40 px-4 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {/* Animated Footballer Logo */}
              <AnimatedFootballerLogo />
              <div>
                <div className="flex items-center gap-1.5">
                  <h1 className="text-base font-black font-display tracking-wider text-white">VOLT</h1>
                  <span className="text-[9px] font-bold bg-cyan-950 text-cyan-400 border border-cyan-900/60 px-1.5 py-0.5 rounded-md uppercase tracking-wider font-mono">
                    FIFA 2026
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-medium">Volunteer On-site Live Translator</p>
              </div>
            </div>

            {/* Tactical Indicators */}
            <div className="flex items-center gap-3">
              {/* Active Volunteer profile */}
              <div className="hidden xs:flex flex-col text-right">
                <span className="text-[9px] text-slate-500 font-black uppercase tracking-wider">ACTIVE AGENT</span>
                <span className="text-xs font-black text-cyan-400 font-display">{volunteerName}</span>
              </div>

              {/* Logout button */}
              <button
                onClick={handleLogout}
                title="Sign out from tactical post"
                className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-pink-500/50 hover:text-pink-500 transition-all cursor-pointer"
                id="header-logout-btn"
              >
                <LogOut className="w-4 h-4" />
              </button>

              {/* Network Connection Indicator */}
              <div className={`flex items-center gap-1.5 border rounded-full px-2.5 py-1 text-[10px] font-bold font-mono transition-colors ${
                isOnline 
                  ? "bg-slate-900 border-slate-800 text-slate-300" 
                  : "bg-amber-950/40 border-amber-500/30 text-amber-400"
              }`}>
                <Wifi className={`w-3 h-3 animate-pulse ${isOnline ? "text-emerald-400" : "text-amber-500"}`} />
                <span>{isOnline ? "HQ SECURE" : "OFFLINE CACHE"}</span>
              </div>
            </div>
          </header>

          {/* MAIN VIEWPORT PORTLET */}
          <main className="flex-1 max-w-lg w-full mx-auto px-4 py-6 pb-28 z-10">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
              >
                {activeTab === "translate" && <TranslateTab />}
                {activeTab === "quickAnswers" && <QuickAnswersTab />}
                {activeTab === "alerts" && <AlertTab />}
                {activeTab === "shift" && <ShiftTab />}
              </motion.div>
            </AnimatePresence>
          </main>

          {/* BOTTOM ACTION NAVIGATION */}
          <nav className="fixed bottom-0 left-0 right-0 bg-[#070b13]/90 backdrop-blur-lg border-t border-slate-900 px-3 py-2 z-40 max-w-lg mx-auto shadow-[0_-8px_30px_rgba(0,0,0,0.4)]">
            <div className="grid grid-cols-4 gap-1">
              {/* Translate */}
              <button
                onClick={() => setActiveTab("translate")}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all cursor-pointer ${
                  activeTab === "translate"
                    ? "text-cyan-400 bg-slate-900/60"
                    : "text-slate-400 hover:text-slate-200"
                }`}
                id="nav-btn-translate"
              >
                <MessageCircle className="w-5.5 h-5.5" />
                <span className="text-[10px] font-bold mt-1 tracking-wider">Translate</span>
              </button>

              {/* Quick Answers */}
              <button
                onClick={() => setActiveTab("quickAnswers")}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all cursor-pointer ${
                  activeTab === "quickAnswers"
                    ? "text-cyan-400 bg-slate-900/60"
                    : "text-slate-400 hover:text-slate-200"
                }`}
                id="nav-btn-quickAnswers"
              >
                <Compass className="w-5.5 h-5.5" />
                <span className="text-[10px] font-bold mt-1 tracking-wider whitespace-nowrap">stadium Guide</span>
              </button>

              {/* Incident Alerts */}
              <button
                onClick={() => setActiveTab("alerts")}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all cursor-pointer relative ${
                  activeTab === "alerts"
                    ? "text-pink-500 bg-slate-900/60"
                    : "text-slate-400 hover:text-slate-200"
                }`}
                id="nav-btn-alerts"
              >
                <div className="relative">
                  <AlertOctagon className="w-5.5 h-5.5" />
                  {incidentCount > 0 && (
                    <span className="absolute -top-1 -right-2 bg-red-500 text-white text-[9px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center border border-[#070b13]">
                      {incidentCount}
                    </span>
                  )}
                </div>
                <span className="text-[10px] font-bold mt-1 tracking-wider">Alerts</span>
              </button>

              {/* My Shift */}
              <button
                onClick={() => setActiveTab("shift")}
                className={`flex flex-col items-center justify-center py-2 px-1 rounded-xl transition-all cursor-pointer ${
                  activeTab === "shift"
                    ? "text-cyan-400 bg-slate-900/60"
                    : "text-slate-400 hover:text-slate-200"
                }`}
                id="nav-btn-shift"
              >
                <User className="w-5.5 h-5.5" />
                <span className="text-[10px] font-bold mt-1 tracking-wider">My Shift</span>
              </button>
            </div>
          </nav>
        </>
      )}
    </div>
  );
}
