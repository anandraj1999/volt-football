export interface Gate {
  id: string; // A–H
  name: string;
  location: string;
  waitMinutes: number;
  accessibilityNotes: string;
  nearestServices: {
    restroom: string;
    medical: string;
    elevator: string;
  };
}

export interface Concession {
  id: string;
  name: string;
  location: string;
  specialty: string;
  dietaryTags: Array<"vegetarian" | "vegan" | "gluten-free" | "halal" | "nut-free">;
  popularItems: string[];
}

export interface MedicalStation {
  id: string;
  name: string;
  location: string;
  phone: string;
  services: string[];
}

export interface RestroomLocation {
  zone: string; // e.g. "Zone A (North Gate)", etc.
  locations: string[];
  allGenderCount: number;
}

export interface StadiumKnowledgeBase {
  venueName: string;
  city: string;
  capacity: number;
  gates: Gate[];
  concessions: Concession[];
  accessibleSeating: {
    sections: string[];
    elevators: string[];
    wheelchairAssistanceProcess: string;
  };
  medicalStations: MedicalStation[];
  lostAndFound: {
    location: string;
    process: string;
    contactPhone: string;
  };
  restrooms: RestroomLocation[];
  policies: {
    bagPolicy: string;
    reEntry: string;
    prohibitedItems: string[];
  };
}

export const STADIUM_DATA: StadiumKnowledgeBase = {
  venueName: "MetLife Stadium (East Rutherford, NJ / NY Venue)",
  city: "East Rutherford, USA",
  capacity: 82500,
  gates: [
    {
      id: "A",
      name: "Gate A (Verizon Gate)",
      location: "North-West Corner, Lower Level near Section 124",
      waitMinutes: 8,
      accessibilityNotes: "Equipped with wide accessible turnstiles. Main elevator bank #1 is 50 yards to the right.",
      nearestServices: {
        restroom: "Section 124 (ADA Accessible)",
        medical: "Medical Station 1 (near Section 128)",
        elevator: "Elevator Bank #1 (Verizon Lobby)"
      }
    },
    {
      id: "B",
      name: "Gate B (Hyland Gate)",
      location: "North-East Corner, Lower Level near Section 131",
      waitMinutes: 15,
      accessibilityNotes: "Full ramp access from outer plaza. Ramps lead to mid-tier 200-level directly.",
      nearestServices: {
        restroom: "Section 133 (ADA Accessible)",
        medical: "Medical Station 1 (near Section 128)",
        elevator: "Elevator Bank #2 (Hyland Lobby)"
      }
    },
    {
      id: "C",
      name: "Gate C (Pepsi Gate)",
      location: "East Plaza, Lower Level near Section 140",
      waitMinutes: 25,
      accessibilityNotes: "Heavy bottleneck expected. Wheelchair loan desk is available just inside the gate security check.",
      nearestServices: {
        restroom: "Section 143 (ADA Accessible)",
        medical: "Medical Station 2 (near Section 144)",
        elevator: "Elevator Bank #3 (Pepsi Lobby)"
      }
    },
    {
      id: "D",
      name: "Gate D (Bud Light Gate)",
      location: "South-East Plaza, Lower Level near Section 101",
      waitMinutes: 4,
      accessibilityNotes: "Shortest wait time currently. Accessible drop-off lot is located directly outside this gate.",
      nearestServices: {
        restroom: "Section 103 (ADA Accessible)",
        medical: "Medical Station 3 (near Section 109)",
        elevator: "Elevator Bank #4 (Bud Light Lobby)"
      }
    },
    {
      id: "E",
      name: "Gate E (Corona Gate)",
      location: "South Plaza, Lower Level near Section 108",
      waitMinutes: 12,
      accessibilityNotes: "Ramp and staircase access. Wide ticketing turnstiles for wheelchairs on the far left lanes.",
      nearestServices: {
        restroom: "Section 112 (ADA Accessible)",
        medical: "Medical Station 3 (near Section 109)",
        elevator: "Elevator Bank #4 (Corona Lobby)"
      }
    },
    {
      id: "F",
      name: "Gate F (SAP Gate)",
      location: "South-West Plaza, Lower Level near Section 117",
      waitMinutes: 18,
      accessibilityNotes: "Main escalator bank access directly inside. Sensory room (quiet zone) is near Section 117A.",
      nearestServices: {
        restroom: "Section 118 (ADA Accessible)",
        medical: "Medical Station 4 (near Section 117)",
        elevator: "Elevator Bank #5 (SAP Lobby)"
      }
    },
    {
      id: "G",
      name: "Gate G (Amex Gate)",
      location: "West Plaza, Lower Level near Section 121",
      waitMinutes: 20,
      accessibilityNotes: "Assistance golf carts stop here every 3 minutes for transit to outer parking zones.",
      nearestServices: {
        restroom: "Section 122 (ADA Accessible)",
        medical: "Medical Station 4 (near Section 117)",
        elevator: "Elevator Bank #5 (Amex Lobby)"
      }
    },
    {
      id: "H",
      name: "Gate H (Executive Gate)",
      location: "North-West plaza, Lower level near VIP Section 126",
      waitMinutes: 3,
      accessibilityNotes: "Strictly for VIP, Suite-holders, and FIFA Officials. Wheelchair-friendly level thresholds.",
      nearestServices: {
        restroom: "Section 125 VIP Suite Level",
        medical: "Medical Station 1 (near Section 128)",
        elevator: "Elevator Bank #1"
      }
    }
  ],
  concessions: [
    {
      id: "C1",
      name: "Global Greens",
      location: "Concourse Section 116",
      specialty: "Fresh bowls, salads, and plant-based wraps",
      dietaryTags: ["vegetarian", "vegan", "gluten-free", "nut-free"],
      popularItems: ["Quinoa Power Salad", "Avocado Chickpea Wrap (GF)", "Vegan Berry Smoothie"]
    },
    {
      id: "C2",
      name: "Halal Corner",
      location: "Concourse Section 142",
      specialty: "Authentic Mediterranean & Middle Eastern halal plates",
      dietaryTags: ["halal", "nut-free"],
      popularItems: ["Chicken Shawarma over Rice", "Falafel Hummus Pita", "Spiced Kofta Wrap"]
    },
    {
      id: "C3",
      name: "Tacocita (GF)",
      location: "Concourse Section 104",
      specialty: "100% Gluten-Free authentic Mexican street tacos",
      dietaryTags: ["vegetarian", "gluten-free", "nut-free"],
      popularItems: ["Carne Asada Corn Tacos", "Jackfruit Carnitas Tacos (Vegan)", "Tortilla Chips & Fresh Guacamole"]
    },
    {
      id: "C4",
      name: "South Plaza Halal & Vegan",
      location: "Concourse Section 109",
      specialty: "Fast-casual plant-based certified halal snack station",
      dietaryTags: ["vegetarian", "vegan", "halal", "nut-free"],
      popularItems: ["Plant-Based Beyond Burger", "Loaded Vegan Nachos", "Seasoned French Fries"]
    },
    {
      id: "C5",
      name: "The Stadium Grill",
      location: "Concourse Section 126",
      specialty: "Classic stadium hot dogs, burgers, and draft beers",
      dietaryTags: ["nut-free"],
      popularItems: ["MetLife Footlong Hot Dog", "Double Cheeseburger", "Soft Pretzel with Cheese"]
    },
    {
      id: "C6",
      name: "Gluten-Free Oasis",
      location: "Concourse Section 130",
      specialty: "Certified gluten-free and allergen-friendly bakes",
      dietaryTags: ["vegetarian", "gluten-free"],
      popularItems: ["Gluten-Free Hot Dog Bun Combo", "GF Chocolate Chip Cookie", "Crispy Rice Squares"]
    },
    {
      id: "C7",
      name: "Rio Carnival Skewers",
      location: "Concourse Section 120",
      specialty: "Brazilian BBQ skewers & grilled pineapple",
      dietaryTags: ["gluten-free", "nut-free", "halal"],
      popularItems: ["Picanha Beef Skewers", "Glazed Grilled Cinnamon Pineapple", "Chicken Coxinha"]
    },
    {
      id: "C8",
      name: "Marseille French Bakery",
      location: "Concourse Section 138",
      specialty: "Gourmet French pastries and espresso bar",
      dietaryTags: ["vegetarian"],
      popularItems: ["Warm Butter Croissant", "Pain au Chocolat", "Iced Vanilla Latte"]
    },
    {
      id: "C9",
      name: "Noodle Bowls",
      location: "Concourse Section 122",
      specialty: "Warm Asian ramen & noodle plates",
      dietaryTags: ["vegetarian", "nut-free"],
      popularItems: ["Sesame Tofu Noodles", "Shoyu Chicken Ramen", "Steamed Veggie Gyoza"]
    },
    {
      id: "C10",
      name: "Tiki Fruit Bar",
      location: "Concourse Section 102",
      specialty: "Fresh carved fruits, juices, and organic coconut water",
      dietaryTags: ["vegetarian", "vegan", "gluten-free", "nut-free"],
      popularItems: ["Fresh Whole Young Coconut", "Pineapple Mango Spear Cup", "Chilled Watermelon Slice"]
    },
    {
      id: "C11",
      name: "Jersey Pizza Co.",
      location: "Concourse Section 112",
      specialty: "Giant thin-crust cheese and pepperoni slices",
      dietaryTags: ["vegetarian", "nut-free"],
      popularItems: ["Classic Cheese Slice", "Double Pepperoni Slice", "Garlic Knots (4pc)"]
    },
    {
      id: "C12",
      name: "El Rincon Latino",
      location: "Concourse Section 128",
      specialty: "Empanadas, pupusas, and refreshing horchata",
      dietaryTags: ["nut-free"],
      popularItems: ["Beef & Potato Empanada", "Cheese Pupusa (GF)", "Traditional Ice-Cold Horchata"]
    }
  ],
  accessibleSeating: {
    sections: ["Section 101-102 ADA Platform", "Section 116-118 Row WC", "Section 124 Row ADA", "Section 140 ADA Terrace", "Section 201 Row WC", "Section 218 Row WC", "Section 301 Row WC"],
    elevators: [
      "Elevator #1 (Verizon Lobby, servicing levels L1, Suite, L2, L3)",
      "Elevator #2 (Hyland Lobby, servicing levels L1, Suite, L2)",
      "Elevator #3 (Pepsi Lobby, servicing levels L1, Suite, L2)",
      "Elevator #4 (Bud Light Lobby, servicing levels L1, Suite, L2, L3)",
      "Elevator #5 (Amex Lobby, servicing levels L1, Suite, L2)"
    ],
    wheelchairAssistanceProcess: "Fans requiring wheelchair escort can request assistance at any Gate Plaza or Guest Services desk (near Sections 117, 124, 142). A volunteer/staff member with a designated stadium wheelchair will escort them to their exact seat. The stadium wheelchair cannot be kept, but loaner wheelchairs are available for the duration of the match on a first-come, first-served basis at Guest Services."
  },
  medicalStations: [
    {
      id: "M1",
      name: "First Aid Station 1 (North)",
      location: "Concourse Section 128 (next to Verizon Gate elevator bank)",
      phone: "+1 (201) 555-0911 (Ext. 1)",
      services: ["Primary triage", "Paramedics team", "Oxygen therapy", "Ice packs", "Emergency cardiac equipment"]
    },
    {
      id: "M2",
      name: "First Aid Station 2 (East)",
      location: "Concourse Section 144 (near Pepsi Gate)",
      phone: "+1 (201) 555-0911 (Ext. 2)",
      services: ["Primary triage", "Stretcher dispatch", "Dehydration treatment", "Minor cuts & bandages"]
    },
    {
      id: "M3",
      name: "First Aid Station 3 (South)",
      location: "Concourse Section 109 (near Corona/Bud Light Gate)",
      phone: "+1 (201) 555-0911 (Ext. 3)",
      services: ["Primary triage", "Cardiac care", "Allergy/EpiPen deployment", "Quiet assessment cot"]
    },
    {
      id: "M4",
      name: "First Aid Station 4 (West)",
      location: "Concourse Section 117 (near SAP Gate & Guest Services)",
      phone: "+1 (201) 555-0911 (Ext. 4)",
      services: ["Full service clinic", "Physician on-duty", "Ambulance transfer staging", "Sensory relief station integration"]
    }
  ],
  lostAndFound: {
    location: "Guest Services Plaza Headquarters near Concourse Section 124 (West)",
    process: "All items found must be brought to the Guest Services desk at Section 124. Fans looking for lost items can register their claim digitally in the stadium's Lost & Found system at the desk or online. Unclaimed items are held for 30 days after the tournament ends, then donated to local charity. If a child or companion is separated, volunteers must immediately flag the incident to 'Control Room' and accompany the remaining guardian to Guest Services Section 124, which serves as the safe-custody meeting point.",
    contactPhone: "+1 (201) 555-FIND (3463)"
  },
  restrooms: [
    {
      zone: "Zone 100 North (Sections 124 - 134)",
      locations: ["Men's & Women's at Sec 124", "Men's & Women's at Sec 128 (ADA)", "Family / All-Gender Restroom at Sec 129"],
      allGenderCount: 1
    },
    {
      zone: "Zone 100 East (Sections 135 - 149)",
      locations: ["Men's & Women's at Sec 139", "Men's & Women's at Sec 143 (ADA)", "Family / All-Gender Restroom at Sec 144"],
      allGenderCount: 1
    },
    {
      zone: "Zone 100 South (Sections 101 - 109)",
      locations: ["Men's & Women's at Sec 103 (ADA)", "Men's & Women's at Sec 107", "Family / All-Gender Restroom at Sec 108"],
      allGenderCount: 1
    },
    {
      zone: "Zone 100 West (Sections 110 - 123)",
      locations: ["Men's & Women's at Sec 112", "Men's & Women's at Sec 118 (ADA)", "Family / All-Gender Restroom at Sec 120", "All-Gender / ADA Suite corridor 116"],
      allGenderCount: 2
    },
    {
      zone: "Zone 200 Level",
      locations: ["Men's & Women's restrooms located near every third section: 201, 207, 215, 222, 230, 238, 245", "All-Gender Restrooms available near Elevator Bank #2 and #4"],
      allGenderCount: 2
    },
    {
      zone: "Zone 300 Level",
      locations: ["Men's & Women's restrooms located near sections: 301, 308, 315, 322, 330, 338, 345 (all ADA compliant)"],
      allGenderCount: 0
    }
  ],
  policies: {
    bagPolicy: "ONLY clear plastic, vinyl, or PVC bags that do NOT exceed 12\" x 6\" x 12\" are permitted. Alternatively, fans can bring a one-gallon clear plastic freezer bag (Ziploc or similar). Small clutch bags/purses, approximately 4.5\" x 6.5\" (the size of a hand), are allowed with or without a handle or strap. Medical bags/equipment and diaper bags are permitted but will undergo secondary detailed x-ray security screening at Gate Verizon (A) or Pepsi (C).",
    reEntry: "Re-entry is strictly PROHIBITED for all World Cup 2026 matches. Once a fan exits through any gate turnstile, their digital ticket is permanently deactivated, and they will not be allowed back into the stadium under any circumstances. In extreme emergency situations, contact a Security Supervisor or the Gate Captain.",
    prohibitedItems: [
      "Professional cameras with detachable lenses longer than 6 inches",
      "Umbrellas (ponchos are encouraged and sold at merch hubs)",
      "Banners, signs, or flags larger than 3 feet x 5 feet, or anything containing political, commercial, or offensive text",
      "Strollers (must be checked at the Stroller Staging Plaza outside Gate B)",
      "Bottles, cans, or metal thermoses (unopened soft plastic water bottles under 20oz are allowed, 1 per person)",
      "Noisemakers including vuvuzelas, megaphones, airhorns, and whistles",
      "Laser pointers and drones"
    ]
  }
};
