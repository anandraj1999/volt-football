// VOLT (Volunteer On-site Live Translator) Service Worker
// Caching and Offline Database Operations for crowded stadium conditions

const CACHE_NAME = "volt-stadium-cache-v1";
const API_CACHE_NAME = "volt-api-cache-v1";

const STATIC_ASSETS = [
  "/",
  "/index.html",
  "/src/main.tsx",
  "/src/index.css"
];

// Offline translation database
const OFFLINE_STADIUM_DATA = {
  venueName: "MetLife Stadium (East Rutherford, NJ / NY Venue)",
  city: "East Rutherford, USA",
  gates: {
    A: "Gate A (Verizon Gate) is at the North-West Corner. Near Section 124. Nearest ADA restroom at Section 124, Medical Station 1 near Section 128, Elevator Bank 1 in Verizon Lobby.",
    B: "Gate B (Hyland Gate) is at the North-East Corner. Near Section 131. Ramp access to 200-level. Nearest restrooms Section 133, Elevator Bank 2 in Hyland Lobby.",
    C: "Gate C (Pepsi Gate) is at the East Plaza. Near Section 140. Wheelchair loan desk is inside. Restrooms at Section 143, Medical Station 2 near Section 144, Elevator Bank 3 in Pepsi Lobby.",
    D: "Gate D (Bud Light Gate) is at the South-East Plaza. Near Section 101. Shortest wait times. Restrooms at Section 103, Medical 3 near Section 109, Elevator Bank 4 in Bud Light Lobby.",
    E: "Gate E (Corona Gate) is at the South Plaza. Near Section 108. Wide turnstiles for wheelchairs on far left. Restrooms at Section 112, Medical 3 near Section 109.",
    F: "Gate F (SAP Gate) is at the South-West Plaza. Near Section 117. Sensory quiet room is near Section 117A. Restrooms at Section 118, Medical Station 4 near Section 117.",
    G: "Gate G (Amex Gate) is at the West Plaza. Near Section 121. Assistance golf carts stop here every 3 minutes. Restrooms at Section 122, Medical Station 4 near Section 117.",
    H: "Gate H (Executive Gate) is at the North-West VIP Plaza. VIP, suite-holders, and FIFA Officials only. Restrooms Section 125 VIP Suite Level."
  },
  concessions: [
    { name: "Global Greens", sec: "116", tags: "vegetarian, vegan, gluten-free", items: "Quinoa Power Salad, Avocado Wrap, Berry Smoothie" },
    { name: "Halal Corner", sec: "142", tags: "halal, mediterranean", items: "Chicken Shawarma, Falafel, Kofta Wrap" },
    { name: "Tacocita", sec: "104", tags: "gluten-free, tacos, mexican", items: "Carne Asada Tacos, Jackfruit Carnitas, Chips & Guac" },
    { name: "South Plaza Halal & Vegan", sec: "109", tags: "vegetarian, vegan, halal", items: "Plant-Based Beyond Burger, Loaded Vegan Nachos, Fries" },
    { name: "The Stadium Grill", sec: "126", tags: "hot dogs, burgers, beer", items: "MetLife Footlong, Cheeseburger, Soft Pretzel" },
    { name: "Gluten-Free Oasis", sec: "130", tags: "vegetarian, gluten-free, bakes", items: "GF Hot Dog Bun, GF Cookie, Crispy Rice Squares" },
    { name: "Rio Carnival Skewers", sec: "120", tags: "halal, skewers, brazilian, bbq", items: "Picanha Beef, Grilled Pineapple, Chicken Coxinha" },
    { name: "Marseille French Bakery", sec: "138", tags: "vegetarian, pastries", items: "Warm Butter Croissant, Pain au Chocolat, Latte" },
    { name: "Noodle Bowls", sec: "122", tags: "vegetarian, asian, noodles", items: "Sesame Tofu Noodles, Chicken Ramen, Veggie Gyoza" },
    { name: "Tiki Fruit Bar", sec: "102", tags: "vegetarian, vegan, gluten-free", items: "Young Coconut, Pineapple Mango Spears, Watermelon" },
    { name: "Jersey Pizza Co.", sec: "112", tags: "vegetarian, pizza", items: "Classic Cheese Slice, Pepperoni Slice, Garlic Knots" },
    { name: "El Rincon Latino", sec: "128", tags: "empanadas, pupusas, horchata", items: "Beef Empanada, Cheese Pupusa, Horchata" }
  ],
  firstAid: "Medical stations are at Section 128 (M1 North, next to Verizon Gate), Section 144 (M2 East, Pepsi Gate), Section 109 (M3 South, Bud Light Gate), and Section 117 (M4 West, full service clinic).",
  restrooms: "Restrooms are located in all zones: North (Sections 124-134), East (Sections 135-149), South (Sections 101-109), and West (Sections 110-123). All zones include ADA-compliant accessible cabins.",
  policies: {
    bag: "ONLY clear plastic bags under 12\"x6\"x12\" are permitted. Small clutches under 4.5\"x6.5\" are allowed. Medical bags go through detailed x-ray screening at Gates A (Verizon) or C (Pepsi).",
    reentry: "Re-entry is strictly PROHIBITED for all World Cup 2026 matches. Once you exit, your digital ticket is permanently deactivated.",
    prohibited: "Prohibited items include: professional cameras (lens > 6\"), umbrellas, banners larger than 3'x5', strollers (must check at Gate B), bottles, vuvuzelas, airhorns, whistles, and laser pointers."
  },
  lostAndFound: "Lost & Found is located at Guest Services Plaza Headquarters near Concourse Section 124 (West Gate F/G). Items are held for 30 days, then donated. If a child is lost, immediately report to Control Room."
};

// Install Event
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("[VOLT Service Worker] Pre-caching critical offline app assets...");
      return cache.addAll(STATIC_ASSETS);
    })
  );
  self.skipWaiting();
});

// Activate Event
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME && key !== API_CACHE_NAME) {
            console.log("[VOLT Service Worker] Removing stale cache:", key);
            return caches.delete(key);
          }
        })
      );
    })
  );
  self.clients.claim();
});

// Fetch Event Router
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // 1. Intercept API Endpoints
  if (url.pathname.startsWith("/api/")) {
    
    // For translation requests, we execute Network-First or custom Offline Fallback
    if (url.pathname === "/api/translate") {
      event.respondWith(
        fetch(event.request)
          .then((response) => {
            // Cache successful translations if we want, or just pass through
            return response;
          })
          .catch((err) => {
            console.warn("[VOLT Service Worker] Offline translation trigger intercepted! Processing offline...");
            return handleOfflineTranslation(event.request.clone());
          })
      );
      return;
    }

    // For health and incidents, use Network-First and fallback to cache
    event.respondWith(
      fetch(event.request)
        .then((response) => {
          if (response.ok && event.request.method === "GET") {
            const responseClone = response.clone();
            caches.open(API_CACHE_NAME).then((cache) => {
              cache.put(event.request, responseClone);
            });
          }
          return response;
        })
        .catch(() => {
          return caches.match(event.request).then((cachedResponse) => {
            if (cachedResponse) {
              return cachedResponse;
            }
            // Return safe fallback if both fail
            if (url.pathname === "/api/health") {
              return new Response(
                JSON.stringify({
                  status: "offline-cached",
                  venue: OFFLINE_STADIUM_DATA.venueName,
                  timestamp: new Date().toISOString(),
                  apiConfigured: true
                }),
                { headers: { "Content-Type": "application/json" } }
              );
            }
            if (url.pathname === "/api/incidents") {
              return new Response(
                JSON.stringify([
                  {
                    id: "INC-9102",
                    category: "medical",
                    location: "Section 104, Tacocita Stand",
                    who: "Male fan, ~45 years old",
                    what: "[OFFLINE CACHED] Slipped on wet floor, holding right ankle, unable to stand.",
                    urgency: "medium",
                    timestamp: new Date().toISOString(),
                    status: "dispatched"
                  }
                ]),
                { headers: { "Content-Type": "application/json" } }
              );
            }
            return new Response(JSON.stringify({ error: "Network unavailable" }), { status: 503 });
          });
        })
    );
    return;
  }

  // 2. Static Assets (Stale-While-Revalidate)
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        // Fetch in background to update cache
        fetch(event.request)
          .then((networkResponse) => {
            if (networkResponse.ok) {
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, networkResponse));
            }
          })
          .catch(() => {/* Ignore background sync failures */});
        return cachedResponse;
      }

      return fetch(event.request).then((response) => {
        // Cache newly discovered assets
        if (response.ok && event.request.method === "GET" && !url.pathname.includes("hot-update")) {
          const responseClone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseClone));
        }
        return response;
      });
    })
  );
});

// Offline Translation Engine
async function handleOfflineTranslation(request) {
  try {
    const requestData = await request.json();
    const queryText = (requestData.text || "").toLowerCase().trim();
    const langCode = requestData.languageCode || "auto";

    // Intent detection
    let detectedIntent = "general";
    let detectedLanguage = "Spanish"; // Default offline fallback
    let englishSummary = "Wants general info";
    let fanResponse = "Hi! We are currently operating in offline stadium mode. How can I help you today?";
    let phoneticSpelling = "Hi! Wee are kur-rently op-er-ating in off-line sta-dee-um mode. How can I help you too-day?";
    let groundingReference = "Offline Stadium Knowledge Base v1";

    // Detect language simply based on words
    if (queryText.includes("hola") || queryText.includes("dónde") || queryText.includes("puerta") || queryText.includes("baño") || queryText.includes("comida")) {
      detectedLanguage = "Spanish";
    } else if (queryText.includes("oi") || queryText.includes("portão") || queryText.includes("onde") || queryText.includes("comida") || queryText.includes("por favor")) {
      detectedLanguage = "Portuguese";
    } else if (queryText.includes("excusez") || queryText.includes("où") || queryText.includes("secours") || queryText.includes("sac")) {
      detectedLanguage = "French";
    } else if (queryText.includes("hallo") || queryText.includes("ausgang") || queryText.includes("tasche")) {
      detectedLanguage = "German";
    }

    // Match keywords to construct accurate grounded answers
    if (queryText.includes("bag") || queryText.includes("backpack") || queryText.includes("bolsa") || queryText.includes("mochila") || queryText.includes("sac") || queryText.includes("tasche")) {
      detectedIntent = "accessibility";
      englishSummary = "Bag policy rules query";
      groundingReference = "Policies - Bag Policy";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] Solamente se permiten bolsas de plástico transparentes de menos de 12" x 6" x 12". Los bolsos pequeños de menos de 4.5" x 6.5" están permitidos. Los equipos médicos se examinan en la Puerta A o C.`;
        phoneticSpelling = "Soh-lah-men-teh seh per-mee-ten bohl-sahs deh plahs-tee-coh trahns-pah-ren-tehs. Bol-sohspeh-keh-nyohs per-mee-tee-dohs.";
      } else if (detectedLanguage === "Portuguese") {
        fanResponse = `[Offline Cache] Apenas bolsas plásticas transparentes de no máximo 12" x 6" x 12" são permitidas. Pequenas bolsas de até 4.5" x 6.5" são autorizadas. Bolsas médicas são revistadas nos Portões A ou C.`;
        phoneticSpelling = "Ah-peh-nahs bohl-sahs plahs-tee-cahs trahns-pah-ren-tehs sah-oh per-mee-tee-dahs.";
      } else {
        fanResponse = `[Offline Cache] Only clear plastic bags under 12" x 6" x 12" are allowed. Small clutches under 4.5" x 6.5" are permitted. Medical bags are screened at Gates A or C.`;
        phoneticSpelling = "Ohn-lee kleer plas-tik bags un-der twelve by six by twelve are al-lowed.";
      }
    } 
    else if (queryText.includes("taco") || queryText.includes("tacocita") || queryText.includes("gluten") || queryText.includes("celiac")) {
      detectedIntent = "food";
      englishSummary = "Wants gluten-free food";
      groundingReference = "Concession C3 - Tacocita (Sec 104)";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] ¡Sí! "Tacocita" en la Sección 104 del Concourse es 100% libre de gluten. Sirven tacos de carne asada y carnitas con tortillas de maíz.`;
        phoneticSpelling = "See! Tah-coh-see-tah en lah sek-see-ohn syehn-toh kwah-troh es syehn por syehn-toh lee-breh deh gloo-ten.";
      } else {
        fanResponse = `[Offline Cache] Yes! "Tacocita" at Concourse Section 104 is 100% certified gluten-free. They serve carne asada and carnitas street tacos with corn tortillas.`;
        phoneticSpelling = "Yes! Tah-co-see-tah at Con-course Sec-tion one-oh-four is one hun-dred per-cent glu-ten free.";
      }
    }
    else if (queryText.includes("food") || queryText.includes("eat") || queryText.includes("comida") || queryText.includes("vegetariana") || queryText.includes("vegan") || queryText.includes("halal") || queryText.includes("pizza") || queryText.includes("kosher")) {
      detectedIntent = "food";
      englishSummary = "Food concession directions";
      groundingReference = "Concessions Database - Sections 104/109/116/142";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] Comida vegetariana y vegana disponible en "Global Greens" (Sección 116) y "South Plaza Halal" (Sección 109). Comida Halal en Sección 142. Pizza en Sección 112.`;
        phoneticSpelling = "Coh-mee-dah veh-heh-tah-ryah-nah dee-spoh-nee-bleh en Gloh-bahl Greens, sek-see-ohn syehn-toh dyeh-see-seh-ees.";
      } else if (detectedLanguage === "Portuguese") {
        fanResponse = `[Offline Cache] Comida vegetariana e vegana está disponível em "Global Greens" (Seção 116) e "South Plaza Halal" (Seção 109). Pratos Halal estão na Seção 142.`;
        phoneticSpelling = "Coh-mee-dah veh-jeh-tah-ryah-nah eh vee-gahn-ah ehs-tah dee-spoh-nee-vel ehn Gloh-bahl Greens.";
      } else {
        fanResponse = `[Offline Cache] Vegetarian and vegan food is at "Global Greens" (Section 116) and "South Plaza Halal" (Section 109). Halal dishes are at "Halal Corner" (Section 142).`;
        phoneticSpelling = "Veh-jeh-tair-ee-an and vee-gan food is available at Glo-bal Greens, Sec-tion one-six-teen.";
      }
    }
    else if (queryText.includes("elevator") || queryText.includes("ascensor") || queryText.includes("elevador") || queryText.includes("wheelchair") || queryText.includes("silla de ruedas") || queryText.includes("cadeira de rodas")) {
      detectedIntent = "accessibility";
      englishSummary = "Wants wheelchair elevator assistance";
      groundingReference = "Accessible Seating & Elevators 1-5";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] El elevador principal más cercano es el Elevador #1 en el Vestíbulo de Verizon (Sección 124). El personal de servicios puede prestarle una silla de ruedas en la Sección 124 o 117.`;
        phoneticSpelling = "El eh-leh-vah-dor preen-see-pahl mahs ser-kah-noh es el eh-leh-vah-dor oo-noh en el ves-tee-boo-loh deh Veh-rye-zohn.";
      } else if (detectedLanguage === "Portuguese") {
        fanResponse = `[Offline Cache] O elevador mais próximo é o Elevador #1 no Saguão Verizon (Seção 124). Cadeiras de rodas de empréstimo estão disponíveis no balcão de atendimento Seção 124.`;
        phoneticSpelling = "Oo eh-leh-vah-dor mais proh-see-moh eh oo eh-leh-vah-dor oom no sah-gwah-oo Verizon.";
      } else {
        fanResponse = `[Offline Cache] The nearest main elevator is Elevator #1 inside the Verizon Lobby (Section 124). Free wheelchair escorts and loaners are at Guest Services Section 124.`;
        phoneticSpelling = "The near-est e-le-vay-tor is E-le-vay-tor one in the Ve-ri-zon Lob-by, near Sec-tion one-twen-ty-four.";
      }
    }
    else if (queryText.includes("first aid") || queryText.includes("medical") || queryText.includes("médico") || queryText.includes("enfermero") || queryText.includes("socours") || queryText.includes("sick") || queryText.includes("hurt") || queryText.includes("dolor") || queryText.includes("enfermo") || queryText.includes("ambulancia")) {
      detectedIntent = "medical";
      englishSummary = "Medical emergency / First Aid query";
      groundingReference = "Medical Station 1 / 4 (Sections 128 / 117)";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] ¡Mantenga la calma! El puesto de primeros auxilios más cercano está en la Sección 128 (junto a la Puerta A) o la clínica de servicio completo en la Sección 117.`;
        phoneticSpelling = "Mahn-ten-gah lah kahl-mah! El pwes-toh deh pree-meh-rohs ah-ooh-see-lyohs mahs ser-kah-noh es-tah en lah sek-see-ohn syehn-toh veyn-tee-oh-choh.";
      } else {
        fanResponse = `[Offline Cache] Please stay calm! The nearest First Aid station is located at Section 128 (near Gate A) and a full medical clinic is located at Section 117.`;
        phoneticSpelling = "Pleeze stay kahm! The near-est First Aid is at Sec-tion one-twen-ty-eight.";
      }
    }
    else if (queryText.includes("restroom") || queryText.includes("toilet") || queryText.includes("bathroom") || queryText.includes("wc") || queryText.includes("baño") || queryText.includes("banheiro") || queryText.includes("toilette")) {
      detectedIntent = "restroom";
      englishSummary = "Nearest restroom directions";
      groundingReference = "Restrooms Database - Zone 100 North / West";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] Los sanitarios más cercanos están en la Sección 124 y Sección 128 (ambos accesibles para silla de ruedas). Baño familiar sin género en la Sección 129.`;
        phoneticSpelling = "Lohs sah-nee-tah-ryohs mahs ser-kah-nohs es-tahn en lah sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Cache] The nearest restrooms are at Section 124 and Section 128 (ADA Accessible). Family gender-neutral restroom is at Section 129.`;
        phoneticSpelling = "The near-est rest-rooms are at Sec-tion one-twen-ty-four and one-twen-ty-eight.";
      }
    }
    else if (queryText.includes("gate") || queryText.includes("entrance") || queryText.includes("puerta") || queryText.includes("portão") || queryText.includes("entrada")) {
      detectedIntent = "gate";
      englishSummary = "Gate location & wait-time";
      groundingReference = "Gates - A/B/C/D/E/F/G/H database";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] Puerta A (Verizon) está en la Sección 124 (8 min de espera). Puerta B (Hyland) en Sec 131. Puerta D (Bud Light) en Sec 101 tiene la espera más corta (4 min).`;
        phoneticSpelling = "Pwer-tah Ah es-tah en lah sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else if (detectedLanguage === "Portuguese") {
        fanResponse = `[Offline Cache] Portão A (Verizon) está na Seção 124 (8 min de espera). Portão D (Bud Light) na Seção 101 é o mais rápido hoje (4 min).`;
        phoneticSpelling = "Por-tah-oo Ah es-tah nah seh-sah-oo syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Cache] Gate A (Verizon) is at Section 124 (8m wait). Gate D (Bud Light) at Section 101 has the shortest wait time currently (only 4 minutes).`;
        phoneticSpelling = "Gate A is at Sec-tion one-twen-ty-four, and Gate D is at Sec-tion one-oh-one.";
      }
    }
    else if (queryText.includes("lost") || queryText.includes("found") || queryText.includes("perdido") || queryText.includes("objeto") || queryText.includes("carteira") || queryText.includes("wallet")) {
      detectedIntent = "lost_found";
      englishSummary = "Lost and Found instructions";
      groundingReference = "Lost & Found Guest Services (Sec 124)";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] La oficina de objetos perdidos está en Guest Services, Sección 124. Si perdió un niño o acompañante, acompáñeme de inmediato a la Sección 124 para alertar a control.`;
        phoneticSpelling = "La oh-fee-see-nah deh ob-heh-tohs per-dee-dohs es-tah en Guest Ser-vee-ses sek-see-ohn syehn-toh veyn-tee-kwah-troh.";
      } else {
        fanResponse = `[Offline Cache] Lost & Found is located at Guest Services near Section 124. If a child or companion is separated, please come with me immediately to Section 124.`;
        phoneticSpelling = "Lost and Found is lo-cay-ted at Guest Ser-vi-ces near Sec-tion one-twen-ty-four.";
      }
    }
    else if (queryText.includes("reentry") || queryText.includes("re-entry") || queryText.includes("salir") || queryText.includes("exit") || queryText.includes("reentrar") || queryText.includes("saída")) {
      detectedIntent = "general";
      englishSummary = "Re-entry policy query";
      groundingReference = "Policies - Re-Entry Prohibited";
      if (detectedLanguage === "Spanish") {
        fanResponse = `[Offline Cache] El reingreso está estrictamente prohibido. Si sale del estadio, su boleto digital quedará inhabilitado permanentemente y no podrá volver a entrar.`;
        phoneticSpelling = "El reh-een-greh-soh es-tah es-treck-tah-men-teh proh-ee-bee-doh.";
      } else if (detectedLanguage === "Portuguese") {
        fanResponse = `[Offline Cache] A reentrada é estritamente proibida. Uma vez que sair do estádio, o seu bilhete digital será permanentemente desativado.`;
        phoneticSpelling = "Ah reh-en-trah-dah eh es-tree-tah-men-teh proh-ee-bee-dah.";
      } else {
        fanResponse = `[Offline Cache] Re-entry is strictly prohibited. Once you exit the stadium gates, your digital ticket is permanently deactivated and cannot be reused.`;
        phoneticSpelling = "Ree-en-tree is strick-ly pro-hib-i-ted.";
      }
    }

    // Build perfect JSON TranslateResponse matching expected schema
    const offlineResponse = {
      detectedLanguage: `${detectedLanguage} (On-Device Offline)`,
      detectedIntent,
      englishSummary: `[Offline Mode] ${englishSummary}`,
      fanResponse,
      phoneticSpelling,
      groundingReference: `Offline Cache: ${groundingReference}`
    };

    return new Response(JSON.stringify(offlineResponse), {
      status: 200,
      headers: { "Content-Type": "application/json" }
    });

  } catch (error) {
    console.error("[VOLT Service Worker] Offline translation generator crashed:", error);
    return new Response(
      JSON.stringify({
        detectedLanguage: "English (Offline Failback)",
        detectedIntent: "general",
        englishSummary: "Offline match failed",
        fanResponse: "We are currently offline. Please escort the fan to Guest Services near Section 124 for immediate in-person multilingual coordination.",
        phoneticSpelling: "Pleeze es-kort the fan to Guest Ser-vi-ces near Sec-tion one-twen-ty-four.",
        groundingReference: "Emergency Offline Fallback Protocol"
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  }
}
