# VOLT — Volunteer On-site Live Translator
### GenAI-Powered Real-Time Assistant for FIFA World Cup 2026 Stadium Volunteers

---

## ⚽ Concept & Persona
**Vertical:** FIFA World Cup 2026 Stadium Volunteer Operations (Verizon Plaza / MetLife Stadium).

In the midst of an 80,000+ capacity sporting crowd, volunteers stand on their feet for hours resolving high-stress situation queries from fans representing different countries. When approached with critical questions regarding stadium entry, security regulations, accessible ramps, medical post locations, or separated families, volunteers have seconds to parse language barriers and offer grounded, non-hallucinated directions.

**VOLT** (Volunteer On-site Live Translator) is designed strictly as a high-contrast, fast-parsing mobile web application that gives stadium volunteers the power to immediately triage questions in any language, retrieve grounded details, and present large-type sunlight-readable directions back to fans in under 10 seconds.

---

## 🛠️ Architecture & Tech Stack

VOLT is engineered as a secure full-stack application:

*   **Frontend (React 19 + Vite + Tailwind CSS v4 + Framer Motion):** Styled under an premium, dark neon stadium visual aesthetic with massive high-contrast 48px+ touch buttons for quick, one-handed scrolling outdoors.
*   **Speech Integration:** Incorporates standard HTML5 browser Web Speech APIs for direct microphone voice capture, coupled with pre-recorded test-query prompts so that you can verify end-to-end voice translation directly in sandbox iframe preview environments.
*   **"Show to Fan" Flip Mode:** One-tap card expansion that transitions the screen into a daylight-glare-readable off-white display card containing big-font translations.
*   **Backend Proxy (Express v4 + @google/genai SDK):** Houses all Gemini API queries safely on the server, avoiding any client-side exposure of private API keys.
*   **Cloudflare Workers Ready:** A standalone, fully deployable Cloudflare Worker port is provided in `/worker/index.ts` with a compiled `wrangler.toml` for rapid production replication.
*   **In-Memory Tactical Feed:** Holds active logged stadium alerts so that supervisors and volunteers share immediate, stateful triage updates.

---

## 🧬 How the Solution Works End-to-End

### 1. RAG-Grounded Real-Time Translation & Intent Detection
When a fan speaks or types into the volunteer's phone, the text is dispatched to `POST /api/translate`. 
The backend server injects a detailed, structured stadium database containing gate wait times, concession dietary options, restroom corridors, and clear bag policies directly into the Gemini model's system instructions.

Gemini then processes the query and outputs a validated JSON schema containing:
*   **Detected Language & Core Intent:** Categories like `gate`, `food`, `accessibility`, `medical` etc.
*   **English Triage Summary:** An ultra-short summary (e.g., *"Wants gluten-free bun near gate B"*) that the volunteer can scan instantly.
*   **Fan Response:** A complete, beautifully worded answer in the fan's native language.
*   **Phonetic Spelling:** A sound-alike transliteration spelling so that the volunteer can attempt to speak it aloud (e.g., *"Oh-lah! Para ir ah..."*).

### 2. Quick Answers Bento Lookups
Instead of typing, volunteers can tap the "Stadium Guide" bento grid. Clicking any common FAQ instantly queries our grounded local database offline for instant triage, with a option to auto-draft a Spanish/Portuguese/French translation.

### 3. Priority Control Room Escalation
If a volunteer encounters an aggressive crowd, a medical slip-and-fall, or a safety hazard, they select an urgency level (Medium/High/Critical) and location. Tapping "Transmit Alert" executes a real HTTP POST logging the issue instantly. This provides a live coordination feed of ongoing emergencies.

### 4. Megaphone Announcement Scripts
In crowd bottlenecks, volunteers can describe the bottleneck in plain text. Gemini generates brief, clear crowd control announcements in English, Spanish, and Portuguese that are action-oriented and suited for megaphones.

---

## 📖 Stadium Data Model (stadiumData.ts)
Our dataset is strictly integrated into all GenAI processing pipelines to guarantee non-hallucinated responses:
*   **8 Gates (A–H):** Live estimated wait queues, physical quadrant locations, accessibility turnstiles.
*   **12+ Concession Stands:** Tagged with dietary tags (`vegetarian`, `vegan`, `gluten-free`, `halal`, `nut-free`).
*   **4 Medical First Aid Stations:** Location, direct phone extension, cots, and physician details.
*   **Accessibility Ramps & Guest Services:** Section 117 sensory suite, Section 124 VIP wheelchair desk.
*   **Clear Bag Policy & Re-Entry Clauses:** Explicit guidelines on clear bag dimensions, disallowed items, and permanent ticket deactivation upon exit.

---

## 💡 Assumptions Made
1.  **Stadium Coordinates:** Stadium maps, elevator banks, and section numbers are mock data designed to simulate MetLife Stadium for the 2026 World Cup.
2.  **Network Access:** In extreme congestion scenarios where 5G/Wi-Fi is limited, VOLT's "Stadium Guide" bento grid remains 100% active offline because all underlying stadium coordinates are hard-compiled as local state.
3.  **Language Coverage:** Translation quality depends on the Gemini model. We support Auto-Detection for over 100+ languages, prioritizing Spanish, Portuguese, French, and English as quick-picks.

---

## 🚀 How to Run Locally

### 1. Add Environment Variables
Create a `.env` file in the root directory:
```env
GEMINI_API_KEY="YOUR_ACTUAL_GEMINI_API_KEY"
NODE_ENV="development"
```

### 2. Boot the Full-Stack Server
Run the unified server launcher:
```bash
npm run dev
```
This boots the custom Express backend on port `3000` with hot-reloading Vite assets, satisfying the AI Studio container architecture.

### 3. Build & Package for Production
Build the compiled static assets and the server bundle:
```bash
npm run build
```
This compiles the server into a bundle in `dist/server.cjs` via `esbuild`. It is ready to start with:
```bash
npm run start
```
